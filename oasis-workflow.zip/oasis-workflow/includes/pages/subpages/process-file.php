<?php
if ( isset($_GET["processid"]) && $_GET["processid"] ) {
	$Processid = intval( sanitize_text_field( $_GET["processid"] ));
	$Process = FCWorkflowBase::get_sd_step_by_id($Processid);
	$opt_files=FCWorkflowBase::get_sd_output_by_id($Processid);
	$ipt_files=FCWorkflowBase::get_sd_input_by_id($Processid);
	$opt_variables= FCProcessFlow::get_sd_output_variables_by_id($Processid);
	$ipt_variables= FCProcessFlow::get_sd_input_variables_by_id($Processid);
	$workflow=FCWorkflowBase::get_sd_workflow_by_id($Process->WorkFlowID);
	$odscp=FCWorkflowBase::get_sd_output_description_by_id($Processid);
	$idscp=FCWorkflowBase::get_sd_input_description_by_id($Processid);
}	
?>

<script type='text/javascript'>
	function setTab(n){
		var tli=document.getElementById("menu0").getElementsByTagName("li");
		//var mli=document.getElementById("main0").getElementsByTagName("ul");
		var ch=document.getElementById("main0").children;
		for(i=0;i<tli.length;i++){
			tli[i].className=(i==n)?"hover":"";
			ch[i].style.display=(i==n)?"block":"none";
		}
	}
</script>

<div class="info-setting" id="input-output-div" style="display:none;">
	<?php if($Process):?>
		<div class="dialog-title"><strong style="font-weight:bold;font-size:18px;"><?php echo __("Input & Output", "oasisworkflow");?></strong></div>
		<table>
			<tr>
				<td style="font-weight:bold;padding:5px;width:100px;"><?php echo __("Process:", "oasisworkflow")?> </td>
				<td style="padding:5px;"><?php echo $Process->Name; ?></td>
			</tr>
			<tr style="margin:5px;">
				<td style="font-weight:bold;padding:5px;width:100px;"><?php echo __("Workflow:", "oasisworkflow")?></td>
				<td style="padding:5px;"><?php echo $workflow->Name; ?></td>
			</tr>
		</table>
		<div id="message_div"></div>
		<div class="text-info" id="comments-div" style="margin-bottom:6px;margin-top:6px;">
			<div class="tabs0">
				<ul class="menu0" id="menu0">
					<li class="hover" style="height:25px;" onclick="setTab(0)">
						<label>
							<?php echo  __("Input Files", "oasisworkflow");?>
							 <a href="#" title="<?php echo $idscp;?>" class="tooltip">
								<span title=""><img src="<?php echo OASISWF_URL . '/img/help.png'; ?>" class="help-icon"/></span>
							</a>
						</label>
					</li>
					<li class="" style="height:25px;" onclick="setTab(1)">Input Variables</li>
					<li class="" onclick="setTab(2)" style="border-left:2px solid Gray;height:25px;">
						<label>
							<?php echo  __("Output Files", "oasisworkflow");?>
							 <a href="#" title="<?php echo $odscp; ?>" class="tooltip">
								<span title=""><img src="<?php echo OASISWF_URL . '/img/help.png'; ?>" class="help-icon"/></span>
							</a>
						</label>
					</li>
					<li class="" style="height:25px;" onclick="setTab(3)">Output Variables</li>
				</ul>
			</div>
			<div class="main" id="main0">
				<ul class="block">
					<div style="overflow:auto;width:100%;height:450px;">
						<table class="bordered">
							<thead>
								<tr>
									<th>File Name</th>
									<th>Upload Time</th>
								</tr>
							</thead>
							<tbody>
							<?php
								if($ipt_files)
								{
									foreach($ipt_files as $iptf)
									{
										echo "<tr><td><a href='#' class='quick_download' fileid=".$iptf->ID.">".$iptf->file_name."</a></td><td>".$iptf->upload_datetime."</td></tr>";
									}
								}
								else
								{
									$msg = "<label style='width:100%;'>" . __("You don't have any input file.", "oasisworkflow") . "</label>";
									echo "<tr>" ;
									echo "<td colspan='2' class='no-found-lbl'>$msg</td>" ;
									echo "</tr>" ;
								}
							?>
							</tbody>
						</table>
					</div>
				</ul>
				<ul class="">
					<div style="overflow:auto;width:100%;height:450px;">
						<table class="bordered">
							<thead>
								<tr>
									<th>Variable</th>
									<th>Value</th>
									<th>Update Time</th>
								</tr>
							</thead>
							<tbody>
							<?php
								if($ipt_variables)
								{
									foreach($ipt_variables as $iptv)
									{
										echo "<tr><td>".$iptv->Name."</td><td>".$iptv->Content."</td><td>".$iptv->Updatetime."</td></tr>";
									}
								}
								else
								{
									$msg = "<label style='width:100%;'>" . __("You don't have any input variable.", "oasisworkflow") . "</label>";
									echo "<tr>" ;
									echo "<td colspan='3' class='no-found-lbl'>$msg</td>" ;
									echo "</tr>" ;
								}
							?>
							</tbody>
						</table>
					</div>
				</ul>
				<ul class="">
					<div style="overflow:auto;width:100%;height:450px;">
						<table class="bordered">
							<thead>
								<tr>
									<th>File name</th>
									<th>Upload time</th>
								</tr>
							</thead>
							<tbody>
							<?php
								if($opt_files)
								{
									foreach($opt_files as $optf)
									{
										echo "<tr><td><a href='#' class='quick_download' fileid=".$optf->ID.">".$optf->file_name."</a></td><td>".$optf->upload_datetime."</td></tr>";
									}
								}
								else
								{
									$msg = "<label style='width:100%;'>" . __("You don't have any output file.", "oasisworkflow") . "</label>";
									echo "<tr>";
									echo "<td colspan='2' class='no-found-lbl'>$msg</td>" ;
									echo "</tr>";
								}
							?>
							</tbody>
						</table>
					</div>
				</ul>
				<ul class="">
					<div style="text-align:center;margin:5px;">
						<span style="display:inline-block;">Variable:</span><input id="vname" type="text" style="display:inline-block;">
						<span style="display:inline-block;">Value:</span><input id="vvalue" type="text" style="display:inline-block;">
						<input type="button" id="btnAdd" value="Add" class="button-primary" style="width:50px;display:inline-block;" processid="<?php echo $Processid; ?>">
					</div>
					<hr>
					<div style="overflow:auto;width:100%;height:400px;">
						<table class="bordered" id="ovtable">
							<thead>
								<tr>
									<th>Variable</th>
									<th>Value</th>
									<th>Update Time</th>
								</tr>
							</thead>
							<tbody>
							<?php
								if($opt_variables)
								{
									foreach($opt_variables as $optv)
									{
										echo "<tr><td>".$optv->Name."</td><td>".$optv->Content."</td><td>".$optv->Updatetime."</td></tr>";
									}
								}
								else
								{
									$msg = "<label style='width:100%;'>" . __("You don't have any output variable.", "oasisworkflow") . "</label>";
									echo "<tr>" ;
									echo "<td id='tr_output_variable' colspan='3' class='no-found-lbl'>$msg</td>" ;
									echo "</tr>" ;
								}
							?>
							</tbody>
						</table>
					</div>
				</ul>
			</div>
		</div>
	<?php else: ?>
		<div id="div_msg" class="dialog-title"><strong><?php echo "Can not locate the process you selected.";?></strong></div>
	<?php endif; ?>
</div>