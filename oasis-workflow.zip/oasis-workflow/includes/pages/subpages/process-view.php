<?php
if ( isset($_GET["processid"]) && $_GET["processid"] ) {
	$Processid = intval( sanitize_text_field( $_GET["processid"] ));
	$Process = FCWorkflowBase::get_sd_step_by_id($Processid);
	$workflow_id = $Process->WorkFlowID;
	$workflow=FCWorkflowBase::get_sd_workflow_by_id($Process->WorkFlowID);
}	
?>

<div class="info-setting" id="input-output-div" style="display:none;">
	<input type="hidden" id="process_id" name="process_id" value='<?php echo esc_attr( $Processid); ?>' />
	<input type="hidden" id="workflow_id" name="workflow_id" value='<?php echo esc_attr( $workflow_id ); ?>' />
	<?php if($Process):?>
		<div class="dialog-title"><strong style="font-weight:bold;font-size:18px;"><?php echo __("Submit Process", "oasisworkflow");?></strong></div>
		<table>
			<tr>
				<td style="font-weight:bold;padding:5px;width:100px;"><?php echo __("Process:", "oasisworkflow")?> </td>
				<td style="padding:5px;"><?php echo $Process->Name; ?></td>
			</tr>
			<tr style="margin:5px;">
				<td style="font-weight:bold;padding:5px;width:100px;"><?php echo __("Workflow:", "oasisworkflow")?></td>
				<td style="padding:5px;"><?php echo $workflow->Name; ?></td>
			</tr>
		</table>
		<div id="message_div"></div>
		<div class="text-info" id="comments-current-div" style="margin-bottom:6px;margin-top:15px;">
			<div class="step-assignee-list">
				<label style="float:left;"><?php echo __("Current Status:", "oasisworkflow") ;?></label>
				<select id="step-status-current-list" name="step-status-current-list" style="float:left;" disabled>
				<?php
					foreach(FCInitialization::$process_status as $sk => $sv)
					{				
						if($Process->Status == $sk)
						{
							echo "<option value='".$sk."' selected>{$sv}</option>";
						}
						else
						{
							echo "<option value='".$sk."'>{$sv}</option>";
						}
					}
				?>
				</select>
				<br class="clear">
			</div>
		</div>
		<div class="text-info" id="comments-div" style="margin-bottom:6px;margin-top:15px;">
			<div class="step-assignee-list">
				<label style="float:left;"><?php echo __("Set Status To:", "oasisworkflow") ;?></label>
				<select id="step-status-set-list" name="step-status-set-list" style="float:left;">
				<?php
					foreach(FCInitialization::$process_status as $sk => $sv)
					{
						if($Process->Status != "Gray" && $sk =="Gray")
							continue;
							
						if($Process->Status == "Black" && $sk !="Black")
							continue;
							
						if($Process->Status == $sk)
						{
							echo "<option value='".$sk."' selected>{$sv}</option>";
						}
						else
						{
							echo "<option value='".$sk."'>{$sv}</option>";
						}
					}
				?>
				</select>
				<input id='btnSubmit' type='button' value='Submit' style="float:right;width:100px;margin-right:20px;" class="button button-primary button-large"/>
				<br class="clear">
			</div>
		</div>
	<?php else: ?>
		<div class="dialog-title"><strong><?php echo "Can not locate the process you selected.";?></strong></div>
	<?php endif; ?>
</div>
