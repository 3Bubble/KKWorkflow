<?php
if ( isset($_GET["processid"]) && $_GET["processid"] ) {
	$Processid = intval( sanitize_text_field( $_GET["processid"] ));
	$Process = FCWorkflowBase::get_sd_step_by_id($Processid);
	$opt_files=FCWorkflowBase::get_sd_output_by_id($Processid);
	//$ipt_files=FCWorkflowBase::get_sd_input_by_id($Processid);
	$opt_variables= FCProcessFlow::get_sd_output_variables_by_id($Processid);
	//$ipt_variables= FCProcessFlow::get_sd_input_variables_by_id($Processid);
	$workflow=FCWorkflowBase::get_sd_workflow_by_id($Process->WorkFlowID);
	$odscp=FCWorkflowBase::get_sd_output_description_by_id($Processid);
	//$idscp=FCWorkflowBase::get_sd_input_description_by_id($Processid);
}	
?>

<script type='text/javascript'>
	function setTab(n){
		var tli=document.getElementById("menu0").getElementsByTagName("li");
		//var mli=document.getElementById("main0").getElementsByTagName("ul");
		var ch=document.getElementById("main0").children;
		for(i=0;i<tli.length;i++){
			tli[i].className=(i==n)?"hover":"";
			ch[i].style.display=(i==n)?"block":"none";
		}
	}
</script>
<style type="text/css">

.main{
clear:both;
padding:4px;
border: 1px solid #E2E2E2;
height:450px;
}

ul,li{
padding:0px;
margin:0px;
}

.menu0 li{
display:block;
float:left;
padding:4px;
width:120px;
text-align:center;
vertical-align:middle;
cursor:pointer;
color:gray;
background-color:#dce9f9;
border:1px solid #dce9f9;
border-left:1px solid #cccccc;
}

.menu0 li.hover{
background-color:#cccccc;
border:1px solid #cccccc;
color:blue;
}

#main0 ul{
display:none;
}
#main0 ul.block{
display:block;
}

table {
*border-collapse: collapse; /* IE7 and lower */
border-spacing: 0;
width: 100%;
}

.bordered {
border: solid #ccc 1px;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
-webkit-box-shadow: 0 1px 1px #ccc;
-moz-box-shadow: 0 1px 1px #ccc;
box-shadow: 0 1px 1px #ccc;
}

.bordered tr:hover {
background: #fbf8e9;
-o-transition: all 0.1s ease-in-out;
-webkit-transition: all 0.1s ease-in-out;
-moz-transition: all 0.1s ease-in-out;
-ms-transition: all 0.1s ease-in-out;
transition: all 0.1s ease-in-out;
}

.bordered td, .bordered th {
border-left: 1px solid #ccc;
border-top: 1px solid #ccc;
padding: 5px;
text-align: left;
}

.bordered th {
background-color: #dce9f9;
background-image: -webkit-gradient(linear, left top, left bottom, from(#ebf3fc), to(#dce9f9));
background-image: -webkit-linear-gradient(top, #ebf3fc, #dce9f9);
background-image: -moz-linear-gradient(top, #ebf3fc, #dce9f9);
background-image: -ms-linear-gradient(top, #ebf3fc, #dce9f9);
background-image: -o-linear-gradient(top, #ebf3fc, #dce9f9);
background-image: linear-gradient(top, #ebf3fc, #dce9f9);
-webkit-box-shadow: 0 1px 0 rgba(255,255,255,.8) inset;
-moz-box-shadow:0 1px 0 rgba(255,255,255,.8) inset;
box-shadow: 0 1px 0 rgba(255,255,255,.8) inset;
border-top: none;
text-shadow: 0 1px 0 rgba(255,255,255,.5);
}

.bordered td:first-child, .bordered th:first-child {
border-left: none;
}

.bordered th:first-child {
-moz-border-radius: 6px 0 0 0;
-webkit-border-radius: 6px 0 0 0;
border-radius: 6px 0 0 0;
}

.bordered th:last-child {
-moz-border-radius: 0 6px 0 0;
-webkit-border-radius: 0 6px 0 0;
border-radius: 0 6px 0 0;
}

.bordered th:only-child{
-moz-border-radius: 6px 6px 0 0;
-webkit-border-radius: 6px 6px 0 0;
border-radius: 6px 6px 0 0;
}

.bordered tr:last-child td:first-child {
-moz-border-radius: 0 0 0 6px;
-webkit-border-radius: 0 0 0 6px;
border-radius: 0 0 0 6px;
}

.bordered tr:last-child td:last-child {
-moz-border-radius: 0 0 6px 0;
-webkit-border-radius: 0 0 6px 0;
border-radius: 0 0 6px 0;
}

</style>

<div class="info-setting" id="input-output-div" style="display:none;">
	<?php if($Process):?>
		<div class="dialog-title"><strong style="font-weight:bold;font-size:18px;"><?php echo __("Output", "oasisworkflow");?></strong></div>
		<table>
			<tr>
				<td style="font-weight:bold;padding:5px;width:100px;"><?php echo __("Process:", "oasisworkflow")?> </td>
				<td style="padding:5px;"><?php echo $Process->Name; ?></td>
			</tr>
			<tr style="margin:5px;">
				<td style="font-weight:bold;padding:5px;width:100px;"><?php echo __("Workflow:", "oasisworkflow")?></td>
				<td style="padding:5px;"><?php echo $workflow->Name; ?></td>
			</tr>
			<tr>
				<td style="font-weight:bold;padding:5px;width:100px;"><?php echo __("Requirement:", "oasisworkflow")?></td>
				<td style="padding:5px;"><?php echo $odscp==''?'null':$odscp; ?></td>
			</tr>
		</table>

		<hr style="height:1px;border:none;border-top:1px dotted grey;"/>
		<div class="text-info" id="comments-div" style="margin-bottom:6px;margin-top:6px;">
			<div class="tabs0">
				<ul class="menu0" id="menu0">
					<li class="hover" onclick="setTab(0)">Output Files</li>
					<li class="" onclick="setTab(1)">Output Variables</li>
				</ul>
			</div>
			<div class="main" id="main0">
				<ul class="block">
					<div style="overflow:auto;width:100%;height:450px;">
						<table class="bordered">
							<thead>
								<tr>
									<th>File name</th>
									<th>Upload time</th>
								</tr>
							</thead>
							<tbody>
							<?php
								if($opt_files)
								{
									foreach($opt_files as $optf)
									{
										echo "<tr><td><a href='#' class='quick_download' fileid=".$optf->ID.">".$optf->file_name."</a></td><td>".$optf->upload_datetime."</td></tr>";
									}
								}
								else
								{
									$msg = "<label style='width:100%;'>" . __("You don't have any output file.", "oasisworkflow") . "</label>";
									echo "<tr>";
									echo "<td colspan='2' class='no-found-lbl'>$msg</td>" ;
									echo "</tr>";
								}
							?>
							</tbody>
						</table>
					</div>
				</ul>
				<ul class="">
					<div style="text-align:center;margin:5px;">
						<span style="display:inline-block;">Variable:</span><input id="vname" type="text" style="display:inline-block;">
						<span style="display:inline-block;">Value:</span><input id="vvalue" type="text" style="display:inline-block;">
						<input type="button" id="btnAdd" value="Add" class="button-primary" style="width:50px;display:inline-block;" processid="<?php echo $Processid; ?>">
					</div>
					<hr>
					<div style="overflow:auto;width:100%;height:400px;">
						<table class="bordered" id="ovtable">
							<thead>
								<tr>
									<th>Variable</th>
									<th>Value</th>
									<th>Update Time</th>
								</tr>
							</thead>
							<tbody>
							<?php
								if($opt_variables)
								{
									foreach($opt_variables as $optv)
									{
										echo "<tr><td>".$optv->Name."</td><td>".$optv->Content."</td><td>".$optv->Updatetime."</td></tr>";
									}
								}
								else
								{
									$msg = "<label style='width:100%;'>" . __("You don't have any output variable.", "oasisworkflow") . "</label>";
									echo "<tr>" ;
									echo "<td id='tr_output_variable' colspan='3' class='no-found-lbl'>$msg</td>" ;
									echo "</tr>" ;
								}
							?>
							</tbody>
						</table>
					</div>
				</ul>
			</div>
		</div>
	<?php else: ?>
		<div id="div_msg" class="dialog-title"><strong><?php echo "Can not locate the process you selected.";?></strong></div>
	<?php endif; ?>
</div>