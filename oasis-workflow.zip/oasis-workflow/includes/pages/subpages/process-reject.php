<?php
if ( isset($_GET["processid"]) && $_GET["processid"] ) {
	$Processid = intval( sanitize_text_field( $_GET["processid"] ));
	$Process = FCWorkflowBase::get_sd_step_by_id($Processid);
	$ipt_files=FCWorkflowBase::get_sd_input_by_id($Processid);
	$ipt_variables= FCProcessFlow::get_sd_input_variables_by_id($Processid);
	$workflow_id = $Process->WorkFlowID;
	$workflow=FCWorkflowBase::get_sd_workflow_by_id($Process->WorkFlowID);
	$idscp=FCWorkflowBase::get_sd_input_description_by_id($Processid);
}	
?>

<script type='text/javascript'>
	function setTab(n){
		var tli=document.getElementById("menu0").getElementsByTagName("li");
		//var mli=document.getElementById("main0").getElementsByTagName("ul");
		var ch=document.getElementById("main0").children;
		for(i=0;i<tli.length;i++){
			tli[i].className=(i==n)?"hover":"";
			ch[i].style.display=(i==n)?"block":"none";
		}
	}
</script>
<style type="text/css">

.main{
clear:both;
padding:4px;
border: 1px solid #E2E2E2;
height:450px;
}

ul,li{
padding:0px;
margin:0px;
}

.menu0 li{
display:block;
float:left;
padding:4px;
width:120px;
text-align:center;
vertical-align:middle;
cursor:pointer;
color:gray;
background-color:#dce9f9;
border:1px solid #dce9f9;
border-left:1px solid #cccccc;
}

.menu0 li.hover{
background-color:#cccccc;
border:1px solid #cccccc;
color:blue;
}

#main0 ul{
display:none;
}
#main0 ul.block{
display:block;
}

table {
*border-collapse: collapse; /* IE7 and lower */
border-spacing: 0;
width: 100%;
}

.bordered {
border: solid #ccc 1px;
-moz-border-radius: 6px;
-webkit-border-radius: 6px;
border-radius: 6px;
-webkit-box-shadow: 0 1px 1px #ccc;
-moz-box-shadow: 0 1px 1px #ccc;
box-shadow: 0 1px 1px #ccc;
}

.bordered tr:hover {
background: #fbf8e9;
-o-transition: all 0.1s ease-in-out;
-webkit-transition: all 0.1s ease-in-out;
-moz-transition: all 0.1s ease-in-out;
-ms-transition: all 0.1s ease-in-out;
transition: all 0.1s ease-in-out;
}

.bordered td, .bordered th {
border-left: 1px solid #ccc;
border-top: 1px solid #ccc;
padding: 5px;
text-align: left;
}

.bordered th {
background-color: #dce9f9;
background-image: -webkit-gradient(linear, left top, left bottom, from(#ebf3fc), to(#dce9f9));
background-image: -webkit-linear-gradient(top, #ebf3fc, #dce9f9);
background-image: -moz-linear-gradient(top, #ebf3fc, #dce9f9);
background-image: -ms-linear-gradient(top, #ebf3fc, #dce9f9);
background-image: -o-linear-gradient(top, #ebf3fc, #dce9f9);
background-image: linear-gradient(top, #ebf3fc, #dce9f9);
-webkit-box-shadow: 0 1px 0 rgba(255,255,255,.8) inset;
-moz-box-shadow:0 1px 0 rgba(255,255,255,.8) inset;
box-shadow: 0 1px 0 rgba(255,255,255,.8) inset;
border-top: none;
text-shadow: 0 1px 0 rgba(255,255,255,.5);
}

.bordered td:first-child, .bordered th:first-child {
border-left: none;
}

.bordered th:first-child {
-moz-border-radius: 6px 0 0 0;
-webkit-border-radius: 6px 0 0 0;
border-radius: 6px 0 0 0;
}

.bordered th:last-child {
-moz-border-radius: 0 6px 0 0;
-webkit-border-radius: 0 6px 0 0;
border-radius: 0 6px 0 0;
}

.bordered th:only-child{
-moz-border-radius: 6px 6px 0 0;
-webkit-border-radius: 6px 6px 0 0;
border-radius: 6px 6px 0 0;
}

.bordered tr:last-child td:first-child {
-moz-border-radius: 0 0 0 6px;
-webkit-border-radius: 0 0 0 6px;
border-radius: 0 0 0 6px;
}

.bordered tr:last-child td:last-child {
-moz-border-radius: 0 0 6px 0;
-webkit-border-radius: 0 0 6px 0;
border-radius: 0 0 6px 0;
}

</style>

<div class="info-setting" id="input-output-div" style="display:none;">
	<input type="hidden" id="process_id" name="process_id" value='<?php echo esc_attr( $Processid); ?>' />
	<input type="hidden" id="workflow_id" name="workflow_id" value='<?php echo esc_attr( $workflow_id ); ?>' />
	<?php if($Process):?>
		<div class="dialog-title"><strong style="font-weight:bold;font-size:18px;"><?php echo __("Appeal", "oasisworkflow");?></strong></div>
		<table>
			<tr>
				<td style="font-weight:bold;padding:5px;width:100px;"><?php echo __("Process:", "oasisworkflow")?> </td>
				<td style="padding:5px;"><?php echo $Process->Name; ?></td>
			</tr>
			<tr style="margin:5px;">
				<td style="font-weight:bold;padding:5px;width:100px;"><?php echo __("Workflow:", "oasisworkflow")?></td>
				<td style="padding:5px;"><?php echo $workflow->Name; ?></td>
			</tr>
		</table>
		<hr style="height:1px;border:none;border-top:1px dotted grey;"/>
		<div class="text-info" id="comments-div" style="margin-bottom:6px;margin-top:6px;">
			<div class="select-part">
				<div class="text-info left" id="comments-div">
					<div class="left">
						<label><?php echo __("Comments : ", "oasisworkflow") ;?></label>
					</div>
					<div class="left">
						<textarea id="appealComments" style="height:100px;width:400px;margin-top:10px;" ></textarea>
					</div>
					<br class="clear">
				</div>
				<label><?php echo __("Action : ", "oasisworkflow") ;?></label>
				<select id="decision-select" style="width:200px;">
					<option value="unable"><?php echo ( $process == "review" ) ? __("Appeal", "oasisworkflow") :  __("Unable to Complete", "oasisworkflow") ;?></option>
				</select>
				<input id='appealSubmit' type='button' value='Confirm' style="float:right;width:100px;margin-right:20px;" class="button button-primary button-large"/>
				<br class="clear">
			</div>
			
		</div>
		
	<?php else: ?>
		<div id="div_msg" class="dialog-title"><strong><?php echo "Can not locate the process you selected.";?></strong></div>
	<?php endif; ?>
</div>