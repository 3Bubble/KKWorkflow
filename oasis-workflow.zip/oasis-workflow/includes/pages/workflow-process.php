<style>
.goo-collapsible{	
	list-style: none;
	position:absolute;
	right:10px;
    font-family: 'HelveticaNeue', Arial, Helvetica, sans-serif;
    font-size:14px;}
/*header line style and border*/
.goo-collapsible li.header{
	color: #666;
    padding:4px 12px;
	font-weight:bold;
    border: 1px solid #bbb;}
/*set border for every line of menu nad remove top border becouse we dont want double border with header border. */
.goo-collapsible li { 
	border: 1px solid #bbb;
    border-top:0;
    margin: 0;
    background:#F0F0F0;}
/*remove decoration from text links and treat it as a block.*/
.goo-collapsible li a {
	text-decoration:none;
    color:#666;
    display:block;
    padding:8px 12px;}
/*we dont want text to be underline as regular link*/
.goo-collapsible li a:hover {
	background: #F8F8F8;
    text-decoration:none;}
/*remove list style (circles) for submenu*/    
.goo-collapsible li ul {
	list-style: none;
    background: #d3d3d3;
    display: none;
    margin:0;
    padding:0;}
/*remove border and set only bottom border for submenu*/    
.goo-collapsible li ul li {
	margin:0; 
    border:0; 
    border-bottom:1px solid #bbb;}
/*remove bottom border from last element in submenu*/    
.goo-collapsible li ul li:last-child {
	border-bottom:0;}
/*set padding for submenu to be inline with maimenu*/    
.goo-collapsible li ul li a {
	padding: 5px 10px; 
    display: block; 
    padding-left: 33px;
    background: #d3d3d3; }
/*remove text decoration for links*/
.goo-collapsible li ul li a:hover {
text-decoration: none;
background: #d9d9d9; }
/*for menu witch have a submenu display some icom*/
.goo-collapsible .dropdown > a { 
	background: url(/images/arrowdown.png) no-repeat right center; }
/*set some hover color on drop down menu*/
.goo-collapsible .dropdown > a:hover { background: #F8F8F8 url(/images/arrowdown.png) no-repeat right center !important; }
</style>
<script src="/wordpress/wp-content/plugins/oasis-workflow/js/lib/navigationbar.js"></script>

<div id="nav-menu" style="width:200px;">
	<ul class="goo-collapsible ">
		<li class="header" >MAIN NAVIGATION</li>
		
		<li class="dropdown"><a class="" href="#">Workflow</a>
			<ul>
				<li><a href="?page=oasiswf-dot">Import Workflow</a></li>
				<li><a href="?page=oasiswf-workflowsetup">Workflow Setup</a></li>
				<li><a href="?page=oasiswf-workflowfine2">Workflow Fine tuning</a></li>
			</ul>
		</li>
		<li class="dropdown"><a class="" href="#">Tools</a>
			<ul>
				<li><a href="?page=oasiswf-taskassign">Task Assign</a></li>
				<li><a href="?page=oasiswf-monitor">Monitor Tool</a></li>
				<li><a href="?page=oasiswf-workflowactionhistory">User Activity</a></li>
			</ul>
		</li>
	</ul>
</div>
<?php
	session_start();  
	$current_user_id = get_current_user_id();
	$workflows = FCWorkflowList::get_sd_workflow_list( "all" ) ;
	$selected_wf = isset( $_GET['wf'] ) ? intval( sanitize_text_field( $_GET["wf"] )) : null;
	$pstatus= isset( $_GET['status'] ) ? sanitize_text_field( $_GET["status"] ) : null;
	$processes = FCWorkflowList::get_all_sd_processes($selected_wf,$current_user_id, $pstatus);
	
	function set_token() {  
		$_SESSION['token'] = md5(microtime(true));  
	}  
	function valid_token() {  
		$return = $_REQUEST['token'] === $_SESSION['token'] ? true : false;  
		set_token();  
		return $return;  
	}  
 
	if(!isset($_SESSION['token']) || $_SESSION['token']=='') {  
		set_token();  
	}  
	   
	if(valid_token()){  
		$fileArray=$_FILES['file_upload'];
		if(!empty($fileArray))
		{
			foreach($fileArray['error'] as $key => $error)
			{
				if($error == 0)
				{	
					$tmp_file = $fileArray['tmp_name'][$key];
					$pname=$fileArray['name'][$key];
					$file_types = explode ( ".", $pname);
					$file_type = $file_types [count ( $file_types ) - 1];

					$savePath = OASISWF_ROOT . '/temp/';
					date_default_timezone_set('Asia/Shanghai');
					$wfstr = date ( 'Ymdhis' ); 
					$file_name = $wfstr . "." . $file_type;
					if ( copy ( $tmp_file, $savePath . $file_name )) 
					{
						$tablename = FCUtility::get_dnt_documents_table_name();
						$data=array('workflow_id' => $processes[$key]->WorkFlowID, 'step_id' => $processes[$key]->ID, 'file_path' => $savePath . $file_name ,'file_version' => 1,'file_name' =>$pname, 'upload_datetime' => date('y-m-d h:i:s' , time()));
						$result=FCProcessFlow::insert_to_table($tablename,$data);
						if($result)
						{
						    FCWorkflowBase::save_action_to_mysql("SubmitOutput",$processes[$key]->WorkFlowID,$processes[$key]->ID,"");//add by huyq
							echo "<script>alert('Upload Successfully!');</script>";
						}
						else
						{
							echo "<script>alert('Failed to upload file!');</script>";
						}
					}
					else
					{
						echo "<script>alert('Failed to upload file!');</script>";
					}
				}
			}
		}
	}
?>

<style type="text/css">

.a-upload {
   padding: 4px 10px;
   height: 15px;
   line-height: 15px;
   position: relative;
   cursor: pointer;
   color: #888;
   background: #fafafa;
   border: 1px solid #ddd;
   border-radius: 4px;
   overflow: hidden;
   display: inline-block;
   *display: inline;
   *zoom: 1
}

.a-upload  input {
   position: absolute;
   font-size: 100px;
   right: 0;
   top: 0;
   opacity: 0;
   filter: alpha(opacity=0);
   cursor: pointer
}

.a-upload:hover {
   color: #444;
   background: #eee;
   border-color: #ccc;
   text-decoration: none
}
</style>

<div class="wrap">
	<form id="dot-form" method="post" enctype="multipart/form-data" action="#">
		<input type="hidden" name="token" value="<?php echo $_SESSION['token']?>">  
		<h2><?php echo __("MY TASK", "oasisworkflow"); ?></h2>
		<hr style="height:1px;margin:10px;" >
		<div class="alignleft actions">
			<select id="workflow_filter" style="width:150px;">
				<option selected="selected"><?php echo __("All", "oasisworkflow")?></option>
				<?php
					if( $workflows )
					{
						foreach ($workflows as $wf) {
							if($selected_wf == $wf->ID)
							{
								echo "<option value='".$wf->ID."' selected>{$wf->Name}_{$wf->ID}</option>" ;
							}
							else
							{
								echo "<option value='".$wf->ID."'>{$wf->Name}_{$wf->ID}</option>" ;
							}
						}
					}
				?>
			</select>
			<select id="process_status_filter" style="width:150px;">
				<option selected="selected"><?php echo __("All", "oasisworkflow")?></option>
			<?php
				foreach(FCInitialization::$process_status as $sk => $sv)
				{
					if($pstatus == $sk)
					{
						echo "<option value='".$sk."' selected>{$sv}</option>" ;
					}
					else
					{
						echo "<option value='".$sk."'>{$sv}</option>" ;
					}
				}
			?>
			</select>
			<a href="javascript:window.open('<?php echo admin_url('admin.php?page=oasiswf-inbox&wf=')?>' + jQuery('#workflow_filter').val() +'&status=' +jQuery('#process_status_filter').val(), '_self')">
				<input type="button" class="button-secondary action" value="<?php echo __("Show", "oasisworkflow"); ?>" />
			</a>
		</div>
		
		<table class="wp-list-table widefat fixed posts" cellspacing="0" border=0>
			<thead>
				<?php FCProcessFlow::get_table_header();?>
			</thead>
			<tfoot>
				<?php FCProcessFlow::get_table_header();?>
			</tfoot>
			<tbody id="coupon-list">
				<?php
					if($processes):
						$index=0;
						$sspace = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" ;
						foreach ($processes as $process){
								echo "<tr class='alternate author-self status-publish format-default iedit'>";
								echo "<th scope='row' class='check-column'><input type='checkbox' name='linkcheck[]' value=".$index."></th>";
	
								echo "<td style='color:".$process->Status.";'>
										<strong>{$process->Name}</strong>
										<div class='row-actions'>
											<span><a href='#' processid='".$process->ID."' class='quick_view'>" . __("Submit", "oasisworkflow") . "</a></span>&nbsp;|&nbsp;".
											"<span><a href='#' processid='".$process->ID."' class='quick_input'>" . __("View", "oasisworkflow") . "</a></span>&nbsp;|&nbsp;".
											"<span><a href='#' processid='".$process->ID."' class='quick_reject'>" . __("Appeal", "oasisworkflow") . "</a></span>&nbsp;|&nbsp;".
											"<span><a href='#' processid='".$process->ID."' class='quick_output'>" . __("Output", "oasisworkflow") . 
											"</a></span><span class='loading' style='display:none;'>$sspace</span></div></td>";											
								echo "<td style='color:".$process->Status.";'>
										<strong>{$process->WorkFlowName}_{$process->WorkFlowID}</strong></td>";
								echo "<td style='color:".$process->Status.";'>".FCWorkflowList::format_date_for_display ( $process->PlanStartDate )."</td>";
								echo "<td style='color:".$process->Status.";'>{$process->PlanEffort}</td>";
								echo "<td style='color:".$process->Status.";'>".FCWorkflowList::format_date_for_display( date("Y-M-d",strtotime($process->PlanStartDate."+".$process->PlanEffort." day")))."</td>";
								echo "<td style='color:".$process->Status.";'>".FCInitialization::$process_status[$process->Status]."</td>";
								echo "<td style='width:500px;'><div>
										<a class='a-upload' href='#'>+<input type='file' name='file_upload[]' processid='".$process->ID."' class='file_input'/></a>
									</div></td>";
								echo "</tr>";
								$index++;
							}
					else:
						$msg = "<label>" . __("You don't have any process.", "oasisworkflow") . "</label>";
						echo "<tr>" ;
						echo "<td colspan='6' class='no-found-lbl'>$msg</td>" ;
						echo "</tr>" ;
					endif;
				?>
			</tbody>
		</table>
	</form>
</div>
<span id="wfeditlinecontent"></span>
<div id ="step_submit_content"></div>
<div id="reassign-div"></div>
<div id="post_com_count_content"></div>


<?php
	
	/*function set_token() {  
		$_SESSION['token'] = md5(microtime(true));  
	}  
	  
	function valid_token() {  
		$return = $_REQUEST['token'] === $_SESSION['token'] ? true : false;  
		set_token();  
		return $return;  
	}  
	  
	//���tokenΪ��������һ��token  
	if(!isset($_SESSION['token']) || $_SESSION['token']=='') {  
		set_token();  
	}  
	  
	if(isset($_POST['test'])){  
		if(valid_token()){  
			$fileArray=$_FILES['file_upload'];
			if(!empty($fileArray))
			{
				foreach($fileArray['error'] as $key => $error)
				{
					if($error == 0)
					{	
						$tmp_file = $fileArray['tmp_name'][$key];
						$pname=$fileArray['name'][$key];
						$file_types = explode ( ".", $pname);
						$file_type = $file_types [count ( $file_types ) - 1];

						$savePath = OASISWF_ROOT . '/temp/';
						date_default_timezone_set('Asia/Shanghai');
						$wfstr = date ( 'Ymdhis' ); 
						$file_name = $wfstr . "." . $file_type;
						if ( copy ( $tmp_file, $savePath . $file_name )) 
						{
							$tablename = FCUtility::get_dnt_documents_table_name();
							$data=array('workflow_id' => $processes[$key]->WorkFlowID, 'step_id' => $processes[$key]->ID, 'file_path' => $savePath . $file_name ,'file_version' => 1,'file_name' =>$pname, 'upload_datetime' => date('y-m-d h:i:s' , time()));
							$result=FCProcessFlow::insert_to_table($tablename,$data);
							if($result)
							{
								print_r("Upload Successfully!");
							}
							else
							{
								print_r("Failed to upload file!");
							}
						}
						else
						{
							print_r("Failed to upload file!");
						}
					}
				}
			}
		}
	}*/
?>