<?php
$current_user_id = get_current_user_id();
$processes = FCProcessFlow::get_all_sd_not_start_processes(null,$current_user_id);
?>

<div class="wrap">
	<form id="dot-form" method="post" enctype="multipart/form-data" action="#">
		<div id="icon-edit" class="icon32 icon32-posts-post"><br></div>
		<h2><?php echo __("Inbox", "oasisworkflow"); ?></h2>
		<div id="workflow-inbox">
			<table class="wp-list-table widefat fixed posts" cellspacing="0" border=0>
				<thead>
					<?php FCProcessFlow::get_table_header();?>
				</thead>
				<tfoot>
					<?php FCProcessFlow::get_table_header();?>
				</tfoot>
				<tbody id="coupon-list">
					<?php
						if($processes):
							$sspace = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" ;
							$index=0;
							foreach ($processes as $process){
									echo "<tr class='alternate author-self status-publish format-default iedit'>";
									echo "<th scope='row' class='check-column'><input type='checkbox' name='linkcheck[]' value=".$index."></th>";
									echo "<td >
											<strong>{$process->Name}</strong>
											<div class='row-actions'>
												<span><a href='#' processid='".$process->ID."' class='quick_view'>" . __("View", "oasisworkflow") . "</a></span>&nbsp;|&nbsp;
												<span><a href='#' processid='".$process->ID."' class='quick_input_output'>" . __("Input &amp; Output", "oasisworkflow") . "</a><span class='loading' style='display:none;'>$sspace</span></span>";											
									echo "</div></td>";
									echo "<td style='color:#cccccc;'>".FCWorkflowList::format_date_for_display ( $process->PlanStartDate )."</td>";
									echo "<td style='color:#cccccc;'>{$process->PlanEffort}</td>";
									echo "<td style='color:#cccccc;'>".FCWorkflowList::format_date_for_display( date("Y-M-d",strtotime($process->PlanStartDate."+".$process->planeffort." day")))."</td>";
									echo "<td style='color:#cccccc;'>{$process->Status}</td>";
									echo "</tr>";
									$index++;
								}
						else:
							$msg = "<label>" . __("You don't have any process.", "oasisworkflow") . "</label>";
							echo "<tr>" ;
							echo "<td colspan='8' class='no-found-lbl'>$msg</td>" ;
							echo "</tr>" ;
						endif;
					?>
				</tbody>
			</table>
		</div>
		<hr>
		<div style="padding:4px;">
			<input id="txtPath" type="file" name="file_upload" style="width:400px;float:left;"/>
			<input type="Submit" id="btnUpload" class="button-primary" value="Upload" style="float:left;width:70px;margin-left:5px;"/>
		<div class="clear"/>
	</form>
</div>
</div>
<span id="wfeditlinecontent"></span>
<div id ="step_submit_content"></div>
<div id="reassign-div"></div>
<div id="post_com_count_content"></div>


<?php
	if (! empty( $_FILES ['file_upload'] ['name'] )) 
	{
		if(isset($_POST['linkcheck']))
		{
			$array = $_POST['linkcheck'];
			if(count($array)!=1)
			{
				echo "<script>alert('You should only select one process once!')</script>";
				return;
			}
		}
		else
		{
			echo "<script>alert('No process selected!')</script>";
			return;
		}
		$i=$array[0];
		
		$tmp_file = $_FILES ['file_upload'] ['tmp_name'];
		$file_types = explode ( ".", $_FILES ['file_upload'] ['name'] );
		$file_type = $file_types [count ( $file_types ) - 1];

		$savePath = OASISWF_ROOT . '/temp/';
		date_default_timezone_set('Asia/Shanghai');
		$wfstr = date ( 'Ymdhis' ); 
		$file_name = $wfstr . "." . $file_type;
		$wfname=$_FILES ['file_upload'] ['name'];
		if ( copy ( $tmp_file, $savePath . $file_name )) 
		{
			$tablename = FCUtility::get_sd_documents_table_name();
			$data=array('workflowid' => $processes[$i]->workflowid, 'processid' => $processes[$i]->ID, 'filepath' => $savePath . $file_name ,'version' => 1,'filename' =>$wfname, 'uploaddate' => date('y-m-d h:i:s' , time()));
			FCProcessFlow::insert_to_table($tablename,$data);
			if($b===false)
			{
				echo "<script>alert('Failed to upload file!')</script>";
			}
		}
		else
		{
			echo "<script>alert('Failed to upload file!')</script>";
		}
	}
?>
