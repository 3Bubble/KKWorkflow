<style>
.goo-collapsible{	
	list-style: none;
	position:absolute;
	right:10px;
    font-family: 'HelveticaNeue', Arial, Helvetica, sans-serif;
    font-size:14px;}
/*header line style and border*/
.goo-collapsible li.header{
	color: #666;
    padding:4px 12px;
	font-weight:bold;
    border: 1px solid #bbb;}
/*set border for every line of menu nad remove top border becouse we dont want double border with header border. */
.goo-collapsible li { 
	border: 1px solid #bbb;
    border-top:0;
    margin: 0;
    background:#F0F0F0;}
/*remove decoration from text links and treat it as a block.*/
.goo-collapsible li a {
	text-decoration:none;
    color:#666;
    display:block;
    padding:8px 12px;}
/*we dont want text to be underline as regular link*/
.goo-collapsible li a:hover {
	background: #F8F8F8;
    text-decoration:none;}
/*remove list style (circles) for submenu*/    
.goo-collapsible li ul {
	list-style: none;
    background: #d3d3d3;
    display: none;
    margin:0;
    padding:0;}
/*remove border and set only bottom border for submenu*/    
.goo-collapsible li ul li {
	margin:0; 
    border:0; 
    border-bottom:1px solid #bbb;}
/*remove bottom border from last element in submenu*/    
.goo-collapsible li ul li:last-child {
	border-bottom:0;}
/*set padding for submenu to be inline with maimenu*/    
.goo-collapsible li ul li a {
	padding: 5px 10px; 
    display: block; 
    padding-left: 33px;
    background: #d3d3d3; }
/*remove text decoration for links*/
.goo-collapsible li ul li a:hover {
text-decoration: none;
background: #d9d9d9; }
/*for menu witch have a submenu display some icom*/
.goo-collapsible .dropdown > a { 
	background: url(/images/arrowdown.png) no-repeat right center; }
/*set some hover color on drop down menu*/
.goo-collapsible .dropdown > a:hover { background: #F8F8F8 url(/images/arrowdown.png) no-repeat right center !important; }
</style>
<script src="/wordpress/wp-content/plugins/oasis-workflow/js/lib/navigationbar.js"></script>

<div id="nav-menu" style="width:200px;">
	<ul class="goo-collapsible ">
		<li class="header" >MAIN NAVIGATION</li>
		
		<li class="dropdown"><a class="" href="#">Workflow</a>
			<ul>
				<li><a href="?page=oasiswf-dot">Import Workflow</a></li>
				<li><a href="?page=oasiswf-workflowsetup">Workflow Setup</a></li>
				<li><a href="?page=oasiswf-workflowfine2">Workflow Fine tuning</a></li>
			</ul>
		</li>
		<li class="dropdown"><a class="" href="#">Tools</a>
			<ul>
				<li><a href="?page=oasiswf-taskassign">Task Assign</a></li>
				<li><a href="?page=oasiswf-monitor">Monitor Tool</a></li>
				<li><a href="?page=oasiswf-workflowactionhistory">User Activity</a></li>
			</ul>
		</li>
	</ul>
</div>
<?php
	/*$conn = FCWorkflowSetup::connect_sql_server();
	if ($conn) {
		//echo "DB Connected successfully";
		//echo "<br>";
	} 
	else{
		die("DB Connection failed: " . $conn->connect_error);
		echo "<br>";
	}
	$sql = "SELECT * FROM Workflow";
	$workflow = sqlsrv_query($conn,$sql);
	if($workflow){
		sqlsrv_commit($conn);
	}
	else{
		echo "Cannot get the result!";
	}
	echo "<header><h2>Workflow Setup <h2></header>";
	
	$publish_date = current_time(OASISWF_EDIT_DATE_FORMAT);*/
	
	$workflows = FCWorkflowSetup::get_workflow_dropdownlist();
?>
<div id="workflow-setup-submit-div">
	<div >
		<div style="width:100%;float:left;">
			<h2 style="display:inline-block;width:auto;float:left;">WORKFLOW SETUP /</h2>
			<h4 style="display:inline-block;width:auto;float:left;"><a href="admin.php?page=oasiswf-workflowfine2">FINE TUNING</a></h4>
		</div>
		<hr style="height:1px;margin:10px;width:100%" >
		<label><?php echo __("Workflow Design Model: ", "oasisworkflow") ;?></label>
		<select id="workflow-select-in-setup" style="width:200px;">
			<?php
			$count = count($workflow);
			if( $workflows ){
				$ary_sel = array();
				foreach($workflows as $workflow)
				{
					$ary_sel[] = $workflow->ID;
					echo "<option value='".esc_attr( $workflow->ID )."'>" . $workflow->Name . "</option>" ;
				}
			}		
			?>
			
		</select>
		<br class="clear">
	</div>

	<?php
		   /*if(count($ary_sel) == 1) {
			  echo <<<TRIGGER_EVENT
				<script>
				   jQuery(document).ready(function() {
					  jQuery("#workflow-select-in-setup option[value='$ary_sel[0]']").prop("selected", true);
				   });
				</script>
TRIGGER_EVENT;
		   } else {*/
			  echo <<<ADD_BLANK_OPTION
				<script>
				   jQuery(document).ready(function() {
					  jQuery('#workflow-select-in-setup').prepend('<option selected="selected"></option>');
				   });
				</script>
ADD_BLANK_OPTION;
		   //}
	?>	

	<!--<div class="workflow-plan-start-end-date postbox" style="margin:20px">
		<div class="left">
			<label><?php echo __("Workflow Plan StartDate:","oasisworkflow");?></label>
		</div>
		<div class="left">
			<input name="workflow-plan-start-date" id="workflow-plan-start-date" class="date_input" type="text" real="publish-date-loading-span" value="">
			<span class="publish-date-loading-span">&nbsp;</span>
		</div>
		<div class="left">
			<label><?php echo __("Workflow Plan EndDate:","oasisworkflow");?></label>
		</div>
		<div class="left">
			<input name="workflow-plan-end-date" id="workflow-plan-end-date" class="date_input" type="text" real="publish-date-loading-span" value="">
			<span class="publish-date-loading-span">&nbsp;</span>
		</div>
		
		<div class="left">
			<input name="workflow-plan-effort" id="workflow-plan-effort" class="date_input" type="text" real="publish-date-loading-span" value="">
			<span class="publish-date-loading-span">&nbsp;</span>
		</div>	
	</div>-->
	<div class="div-line" style="margin:10px"></div>
	<div class="workflow-date-part wrap">
		<label><?php echo __("Workflow Dates:","oasisworkflow");?></label>
		<table class="wp-list-table widefat fixed posts" id="date-list-table" cellspacing="0" border="0" >
			<thead >
				<tr style="background-color: #FFF;">
					<th class="sortable desc"><a><span style="cursor:text;color:black">Workflow Start Date</span></a></th>
					<th class="sortable desc"><a><span style="cursor:text;color:black">Workflow End Date</span></a></th>
					<th class="sortable desc"><a><span style="cursor:text;color:black">Workflow Plan Effort</span></a></th>
				</tr>
				<tr style="background-color: #FFF">
					<td>
						<input name="workflow-plan-start-date" id="workflow-plan-start-date" class="date_input" type="text" real="publish-date-loading-span" readonly value="">
					</td>
					<td>
						<input name="workflow-plan-end-date" id="workflow-plan-end-date" class="date_input" type="text" real="publish-date-loading-span" value="" disabled >
					</td>
					<td name="workflow-plan-effort" id="workflow-plan-effort" class="date_input" real="publish-date-loading-span">
					</td>
				</tr>
			</thead>
		   <?php 
				
		   ?>
		</table>
	</div>
	
	<br class="clear">
	<div class="div-line" style="margin:10px"></div>
	<div class="group-part wrap">
		<label><?php echo __("Group List:","oasisworkflow");?></label>
		<table class="wp-list-table widefat fixed posts" id="group-list-table">
			<thead>
				<tr style="background-color: #FFF;">
					<th id="sort-groupname" class="sortable desc"><a><span style="color:black">Group Name</span></a></th>
					<th id="sort-group-assignee" class="sortable desc"><a><span style="color:black">Group Leader</span></a></th>
				</tr>
			</thead>
		   <?php 
				
		   ?>
		</table>
	</div>
	<br class="clear">
	<div class="div-line" style="margin:10px"></div>
	<div class="process-part wrap">
		<label><?php echo __("Process List:","oasisworkflow");?></label>
		<table class="wp-list-table widefat fixed posts" id="process-list-table">
			<thead>
				<tr style="background-color: #FFF;">
					<th id="sort-process-name" class="sortable desc"><a><span style="color:black">Process Name</span></a></th>
					<th style='display:none' >Process ID</th>
					<th id="sort-process-groupname" class="sortable desc"><a><span style="color:black">Group Name</span></a></th>
					<th id="sort-process-assignee" class="sortable desc"><a><span style="color:black">PIC</span></a></th>
					<th id="sort-plan-effort" class="sortable desc"><a><span style="color:black">Plan Effort</span></a></th>
					<th id="sort-plan-start" class="sortable desc"><a><span style="color:black">Plan Start Date</span></a></th>
					<th id="sort-plan-end" class="sortable desc"><a><span style="color:black">Plan End Date</span></a></th>
					<th style='display:none'></th>
				</tr>
			</thead>
		</table>	
	</div>
	<br class="clear">
	<div class="div-line" style="margin:10px"></div>
	<div class = "critical-path-part wrap">
		<label><?php echo __("Critical Path:","oasisworkflow");?></label>
		<table class="wp-list-table widefat fixed posts" id="critical-path-table">
			<thead>
				<tr style="background-color: #FFF;">
					<th style="width:10%;" id="sort-path-index" class="sortable desc"><a><span style="cursor:text;color:black">Path Index</span></a></th>
					<th id="sort-path-process-name" class="sortable desc"><a><span style="cursor:text;color:black">Process Name</span></a></th>
					<th id="sort-path-process-id" style="display:none">Process ID</th>
					<th id="sort-path-plan-effort" class="sortable desc"><a><span style="cursor:text;color:black">Plan Effort</span></a></th>
					<th id="sort-path-plan-start" class="sortable desc"><a><span style="cursor:text;color:black">Plan Start Date</span></a></th>
				</tr>
			</thead>
		</table>
	</div>
	<br class="clear">
	<div class="div-line" style="margin:10px"></div>
	<div class="workflow-setup-submit-part wrap">
		<input type="button" id="undo-workflow-setup" class="button-primary" value="<?php echo __("Undo", "oasisworkflow") ;?>" />
		<input type="button" id="redo-workflow-setup" class="button-primary" value="<?php echo __("Redo", "oasisworkflow") ;?>" />
		<input type="button" id="reset-workflow-setup" class="button-primary" value="<?php echo __("Reset", "oasisworkflow") ;?>" />
		<input type="button" id="submit-workflow-setup" class="button-primary" value="<?php echo __("Execute", "oasisworkflow") ;?>" />
	</div>
	<br class="clear">


	
</div>