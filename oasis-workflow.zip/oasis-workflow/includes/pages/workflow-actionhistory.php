<style>
.goo-collapsible{	
	list-style: none;
	position:absolute;
	right:10px;
    font-family: 'HelveticaNeue', Arial, Helvetica, sans-serif;
    font-size:14px;}
/*header line style and border*/
.goo-collapsible li.header{
	color: #666;
    padding:4px 12px;
	font-weight:bold;
    border: 1px solid #bbb;}
/*set border for every line of menu nad remove top border becouse we dont want double border with header border. */
.goo-collapsible li { 
	border: 1px solid #bbb;
    border-top:0;
    margin: 0;
    background:#F0F0F0;}
/*remove decoration from text links and treat it as a block.*/
.goo-collapsible li a {
	text-decoration:none;
    color:#666;
    display:block;
    padding:8px 12px;}
/*we dont want text to be underline as regular link*/
.goo-collapsible li a:hover {
	background: #F8F8F8;
    text-decoration:none;}
/*remove list style (circles) for submenu*/    
.goo-collapsible li ul {
	list-style: none;
    background: #d3d3d3;
    display: none;
    margin:0;
    padding:0;}
/*remove border and set only bottom border for submenu*/    
.goo-collapsible li ul li {
	margin:0; 
    border:0; 
    border-bottom:1px solid #bbb;}
/*remove bottom border from last element in submenu*/    
.goo-collapsible li ul li:last-child {
	border-bottom:0;}
/*set padding for submenu to be inline with maimenu*/    
.goo-collapsible li ul li a {
	padding: 5px 10px; 
    display: block; 
    padding-left: 33px;
    background: #d3d3d3; }
/*remove text decoration for links*/
.goo-collapsible li ul li a:hover {
text-decoration: none;
background: #d9d9d9; }
/*for menu witch have a submenu display some icom*/
.goo-collapsible .dropdown > a { 
	background: url(/images/arrowdown.png) no-repeat right center; }
/*set some hover color on drop down menu*/
.goo-collapsible .dropdown > a:hover { background: #F8F8F8 url(/images/arrowdown.png) no-repeat right center !important; }
</style>
<script src="/wordpress/wp-content/plugins/oasis-workflow/js/lib/navigationbar.js"></script>

<div id="nav-menu" style="width:200px;">
	<ul class="goo-collapsible ">
		<li class="header" >MAIN NAVIGATION</li>
		
		<li class="dropdown"><a class="" href="#">Workflow</a>
			<ul>
				<li><a href="?page=oasiswf-dot">Import Workflow</a></li>
				<li><a href="?page=oasiswf-workflowsetup">Workflow Setup</a></li>
				<li><a href="?page=oasiswf-workflowfine2">Workflow Fine tuning</a></li>
			</ul>
		</li>
		<li class="dropdown"><a class="" href="#">Tools</a>
			<ul>
				<li><a href="?page=oasiswf-taskassign">Task Assign</a></li>
				<li><a href="?page=oasiswf-monitor">Monitor Tool</a></li>
				<li><a href="?page=oasiswf-workflowactionhistory">User Activity</a></li>
			</ul>
		</li>
	</ul>
</div>

<?php
	//$workflow_actions = FCWorkflowActionHistory::get_workflow_aciton_history();
	$workflow_aciton_types = FCWorkflowActionHistory::get_workflow_aciton_type();
?>
<div id="workflow-action-history-div">
	<div class="select-part">
		<h2>USER ACTIVITY</h2>
		<hr style="height:1px;margin:10px;width:100%" >
		<label><?php echo __("Activity Type: ", "oasisworkflow") ;?></label>
		<select id="action-select-in-history" style="width:200px;">
			<?php
			$count = count($workflow_aciton_types);
			echo "<option value='All'>" . All. "</option>" ;
			if( $workflow_aciton_types ){
				$ary_sel = array();				
				foreach($workflow_aciton_types as $type)
				{
					echo "<option value='".esc_attr( $type )."'>" . $type. "</option>" ;
				}
				
			}		
			?>
			
		</select>
		<br class="clear">
	</div>

	<?php
			  echo <<<ADD_BLANK_OPTION
				<script>
				   jQuery(document).ready(function() {
					  jQuery('#action-select-in-history').prepend('<option selected="selected"></option>');
				   });
				</script>
ADD_BLANK_OPTION;
	?>
	<div class="div-line" style="margin:10px"></div>
	<div class="process-part wrap">
		<table class="wp-list-table widefat fixed posts" id="action-history-list-table">
			<thead>
				<tr style="background-color: #FFF;">
					<th style='display:none' >ID</th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Activity Name</span></a></th>
					<th id="sort-action-assignee" class="sortable desc"><a><span style="color:black">PIC</span></a></th>
					<th id="sort-action-status" class="sortable desc"><a><span style="color:black">Status</span></a></th>
					<th id="sort-action-description" class="sortable desc"><a><span style="cursor:text;color:black">Description</span></a></th>
					<th id="sort-action-workflowID" class="sortable desc"><a><span style="color:black">Workflow</span></a></th>
					<th id="sort-action-processID" class="sortable desc"><a><span style="color:black">Task</span></a></th>
					<th id="sort-action-object" class="sortable desc"><a><span style="cursor:text;color:black">Object</span></a></th>
					<th id="sort-action-actionDate" class="sortable desc"><a><span style="color:black">Action Date</span></a></th>
				</tr>
			</thead>
			<!--<tbody id="action-history-list-tbody">-->
				<?php 
					/*if($workflow_actions)
					{
						$userId = get_current_user_id();
						$userRole = FCWorkflowBase::get_current_user_role();
						if(($userRole=="pm")||($userRole=="administrator"))
						{
							foreach($workflow_actions as $wa)
							{
								$actor_name = FCWorkflowBase::getAssigneeName($wa->actor_id);
								echo "<tr><td style='display:none'>".$wa->ID."</td>";
								echo "<td>".$wa->action_name."</td>";
								echo "<td>".$actor_name."</td>";
								echo "<td>".$wa->action_status."</td>";
								echo "<td>".$wa->action_description."</td>";
								echo "<td>".$wa->workflow_id."</td>";
								echo "<td>".$wa->step_id."</td>";
								echo "<td>".$wa->object."</td>";
								echo "<td>".$wa->create_datetime."</td></tr>";
							}
						}
						else
						{
							foreach($workflow_actions as $wa)
							{
								if($wa->ID==$userId)
								{
									$actor_name = FCWorkflowBase::getAssigneeName($wa->actor_id);
									echo "<tr><td style='display:none'>".$wa->ID."</td>";
									echo "<td>".$wa->action_name."</td>";
									echo "<td>".$actor_name."</td>";
									echo "<td>".$wa->action_status."</td>";
									echo "<td>".$wa->action_description."</td>";
									echo "<td>".$wa->workflow_id."</td>";
									echo "<td>".$wa->step_id."</td>";
									echo "<td>".$wa->object."</td>";
									echo "<td>".$wa->create_datetime."</td></tr>";
								}
							}
						}
					}
					else
					{
						echo "<tr><td style='display:none'>No action data!</td></tr>";
					}*/
				?>
			<!--</tbody>-->
		</table>	
	</div>


	
</div>