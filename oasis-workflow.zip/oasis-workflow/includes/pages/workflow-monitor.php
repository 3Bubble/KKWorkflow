<style>
.goo-collapsible{	
	list-style: none;
	position:absolute;
	right:10px;
    font-family: 'HelveticaNeue', Arial, Helvetica, sans-serif;
    font-size:14px;}
/*header line style and border*/
.goo-collapsible li.header{
	color: #666;
    padding:4px 12px;
	font-weight:bold;
    border: 1px solid #bbb;}
/*set border for every line of menu nad remove top border becouse we dont want double border with header border. */
.goo-collapsible li { 
	border: 1px solid #bbb;
    border-top:0;
    margin: 0;
    background:#F0F0F0;}
/*remove decoration from text links and treat it as a block.*/
.goo-collapsible li a {
	text-decoration:none;
    color:#666;
    display:block;
    padding:8px 12px;}
/*we dont want text to be underline as regular link*/
.goo-collapsible li a:hover {
	background: #F8F8F8;
    text-decoration:none;}
/*remove list style (circles) for submenu*/    
.goo-collapsible li ul {
	list-style: none;
    background: #d3d3d3;
    display: none;
    margin:0;
    padding:0;}
/*remove border and set only bottom border for submenu*/    
.goo-collapsible li ul li {
	margin:0; 
    border:0; 
    border-bottom:1px solid #bbb;}
/*remove bottom border from last element in submenu*/    
.goo-collapsible li ul li:last-child {
	border-bottom:0;}
/*set padding for submenu to be inline with maimenu*/    
.goo-collapsible li ul li a {
	padding: 5px 10px; 
    display: block; 
    padding-left: 33px;
    background: #d3d3d3; }
/*remove text decoration for links*/
.goo-collapsible li ul li a:hover {
text-decoration: none;
background: #d9d9d9; }
/*for menu witch have a submenu display some icom*/
.goo-collapsible .dropdown > a { 
	background: url(/images/arrowdown.png) no-repeat right center; }
/*set some hover color on drop down menu*/
.goo-collapsible .dropdown > a:hover { background: #F8F8F8 url(/images/arrowdown.png) no-repeat right center !important; }
</style>
<script src="/wordpress/wp-content/plugins/oasis-workflow/js/lib/navigationbar.js"></script>

<div id="nav-menu" style="width:200px;">
	<ul class="goo-collapsible ">
		<li class="header" >MAIN NAVIGATION</li>
		
		<li class="dropdown"><a class="" href="#">Workflow</a>
			<ul>
				<li><a href="?page=oasiswf-dot">Import Workflow</a></li>
				<li><a href="?page=oasiswf-workflowsetup">Workflow Setup</a></li>
				<li><a href="?page=oasiswf-workflowfine2">Workflow Fine tuning</a></li>
			</ul>
		</li>
		<li class="dropdown"><a class="" href="#">Tools</a>
			<ul>
				<li><a href="?page=oasiswf-taskassign">Task Assign</a></li>
				<li><a href="?page=oasiswf-monitor">Monitor Tool</a></li>
				<li><a href="?page=oasiswf-workflowactionhistory">User Activity</a></li>
			</ul>
		</li>
	</ul>
</div>
<?php
	wp_enqueue_style( 'jquery.dataTables.min.style',
      	                   OASISWF_URL. 'css/lib/style.css',
      	                   false,
      	                   '1.0',
                            'all');		
	wp_enqueue_script('jquery.dataTables.min',
							   OASISWF_URL. 'js/lib/jquery.dataTables.min.js',
							   array(),
							   null,
							   true);
	wp_enqueue_script( 'owf-workflow-monitor',
									   OASISWF_URL. 'js/pages/workflow-monitor.js',
									   '',
									   OASISWF_VERSION,
									   true);
	$user_id = get_current_user_id();
	$current_role = get_userdata($user_id)->roles;
	
	$currentUser = FCWorkflowTaskAssign::get_workflow_CurrentUsername();
	$workflow_select_options = FCWorkflowMonitor::get_allStatus_workflow_dropdownlist();
	$workflow_task_summary = FCWorkflowMonitor::get_allTaskStatus_workflow();
	$users_select_options = FCWorkflowMonitor::get_allusers_dropdownlist_by_allworkflow();
	$all_monitor_datas = FCWorkflowMonitor::get_all_monitor_datas();
	$current_date = date("Y-m-d", current_time('timestamp'));
	$notstart_workflow_count=0;
	$inpro_workflow_count=0;
	$delay_workflow_count=0;
	$complete_workflow_count=0;
	
	$notstart_task_count=0;
	$inpro_task_count=0;
	$delay_task_count=0;
	$complete_task_count=0;
	
	foreach($workflow_select_options as $w_s_o)
	{
		switch($w_s_o->Status)
		{	
			case "Gray":
				$notstart_workflow_count++;
				break;
			case "Green":
				$inpro_workflow_count++;
				break;
			case "Red":
				$delay_workflow_count++;
				break;
			case "Black":
				$complete_workflow_count++;
				break;
			
		}
		/*if($w_s_o->Status=="Gray")
		{
			$work_effort_yet=0;
		}*/
	}
	
	foreach($workflow_task_summary as $w_s_o)
	{
		if (in_array('pm',$current_role))
		{
			if($w_s_o->PlanEffort != '0')
			{
				switch($w_s_o->Status)
				{	
					case "Gray":
						$notstart_task_count++;
						break;
					case "Green":
						$inpro_task_count++;
						break;
					case "Red":
						$delay_task_count++;
						break;
					case "Black":
						$complete_task_count++;
						break;
					
				}
			}
			
		}
		else
		{
			if (($user_id== $w_s_o->AssigneeID) && ($w_s_o->PlanEffort != '0') )
			{
				switch($w_s_o->Status)
				{	
					case "Gray":
						$notstart_task_count++;
						break;
					case "Green":
						$inpro_task_count++;
						break;
					case "Red":
						$delay_task_count++;
						break;
					case "Black":
						$complete_task_count++;
						break;
					
				}
			}
		}
		
	}
	
	
	global $wpdb;
	$wftable = FCUtility::get_dnt_workflows_table_name();
?>
<div id="workflow-monitor-tool-div">
	<h2>MONITOR TOOL</h2>
	<hr style="height:1px;margin:10px;width:100%" >
	<?php 
		//if(in_array('pm',$current_role))
		{
			echo "<div class='workflow-summary-in-monitor' style='margin:auto;width:90%;'>
		
		<table style='width:20%; height:150px;border-collapse:collapse;margin:auto; margin-right:10px;font-size:20px;border:1px solid black;float:left' >
			<thead>
				<tr style='height:90px'>
				<th><span style='color:gray;font-weight:bold;font-size:60px;'>$notstart_workflow_count</span></th>
				</tr>
			</thead>
			<tbody style='font-size:15px;text-align:center;'>
				<tr>
					<td><span style='color:gray;font-weight:bold;font-size:18px;'> Workflows Not Start</td>
				</tr>
			</tbody>
		</table>
		<table style='width:20%; height:150px;border-collapse:collapse;margin:auto; margin-right:10px;font-size:20px;border:1px solid black;float:left' >
			<thead>
				<tr style='height:90px'>
				<th><span style='color:green;font-weight:bold;font-size:60px;'>$inpro_workflow_count</span></th>
				</tr>
			</thead>
			<tbody style='font-size:15px;text-align:center;'>
				<tr>
					<td><span style='color:green;font-weight:bold;font-size:18px;'> Workflows In Progress</td>
				</tr>
			</tbody>
		</table>
		<table style='width:20%;; height:150px;border-collapse:collapse;margin:auto; margin-right:10px;font-size:20px;border:1px solid black;float:left' >
			<thead>
				<tr style='height:90px'>
				<th><span style='color:red;font-weight:bold;font-size:60px;'>$delay_workflow_count</span></th>
				</tr>
			</thead>
			<tbody style='font-size:15px;text-align:center;'>
				<tr>
					<td><span style='color:red;font-weight:bold;font-size:18px;'> Workflows Delay</td>
				</tr>
			</tbody>
		</table>
		<table style='width:20%;; height:150px;border-collapse:collapse;margin:auto; margin-right:10px;font-size:20px;border:1px solid black;float:left' >
			<thead>
				<tr style='height:90px'>
				<th><span style='color:black;font-weight:bold;font-size:60px;'>$complete_workflow_count</span></th>
				</tr>
			</thead>
			<tbody style='font-size:15px;text-align:center;'>
				<tr>
					<td><span style='color:black;font-weight:bold;font-size:18px;'> Workflows Completed</td>
				</tr>
			</tbody>
		</table>
		
	</div>
	<div class='div-line' style='margin:10px;clear:both'></div>";
		}
		
	?>
	
	<div class="task-summary-in-monitor" style='margin:auto;width:90%;'>
		
		<table style='width:20%;; height:150px;border-collapse:collapse;margin:auto; margin-right:10px;font-size:20px;border:1px solid black;float:left' >
			<thead>
				<tr style="height:90px">
				<th><span style='color:gray;font-weight:bold;font-size:60px;'><?php echo __($notstart_task_count, "oasisworkflow")?></span></th>
				</tr>
			</thead>
			<tbody style='font-size:15px;text-align:center;'>
				<tr>
					<td><span style='color:gray;font-weight:bold;font-size:18px;'> Tasks Not Start</td>
				</tr>
			</tbody>
		</table>
		<table style='width:20%; height:150px;border-collapse:collapse;margin:auto;margin-right:10px;font-size:20px;border:1px solid black;float:left' >
			<thead>
				<tr style="height:90px">
				<th><span style='color:green;font-weight:bold;font-size:60px;'><?php echo __($inpro_task_count, "oasisworkflow")?></span></th>
				</tr>
			</thead>
			<tbody style='font-size:15px;text-align:center;'>
				<tr>
					<td><span style='color:green;font-weight:bold;font-size:18px;'> Tasks In Progress</td>
				</tr>
			</tbody>
		</table>
		<table style='width:20%; height:150px;border-collapse:collapse;margin:auto;margin-right:10px;font-size:20px;border:1px solid black;float:left' >
			<thead>
				<tr style="height:90px">
				<th><span style='color:red;font-weight:bold;font-size:60px;'><?php echo __($delay_task_count, "oasisworkflow")?></span></th>
				</tr>
			</thead>
			<tbody style='font-size:15px;text-align:center;'>
				<tr>
					<td><span style='color:red;font-weight:bold;font-size:18px;'> Tasks Delay</td>
				</tr>
			</tbody>
		</table>
		<table style='width:20%; height:150px;border-collapse:collapse;margin:auto;margin-right:10px;font-size:20px;border:1px solid black;float:left' >
			<thead>
				<tr style="height:90px">
				<th><span style='color:black;font-weight:bold;font-size:60px;'><?php echo __($complete_task_count, "oasisworkflow")?></span></th>
				</tr>
			</thead>
			<tbody style='font-size:15px;text-align:center;'>
				<tr>
					<td><span style='color:black;font-weight:bold;font-size:18px;'> Tasks Completed</td>
				</tr>
			</tbody>
		</table>
		
	</div>
	
	
	<div class="div-line" style="margin:10px;clear:both"></div>
	
	<div class="select-part;">
		<select id="workflow-status-select" hidden style="display:none;">
			<option selected="selected" value="All"><?php echo __("All Status", "oasisworkflow")?></option>
			<?php
				foreach(FCInitialization::$process_status as $sk => $sv)
				{
					if($pstatus == $sk)
					{
						echo "<option value='".$sk."' selected>{$sv}</option>" ;
					}
					else
					{
						echo "<option value='".$sk."'>{$sv}</option>" ;
					}
				}
			?>
		</select>
		<select id="workflow-select-by-status" style="width:200px;">
			<option selected="selected" value="All"><?php echo __("All Workflow", "oasisworkflow")?></option>
			<?php
				foreach($workflow_select_options as $wso)
				{
					echo "<option value='".$wso->ID."'>{$wso->Name}_{$wso->ID}</option>" ;
				}			
			?>			
		</select>
		<select id="user-select-in-workflow" <?php if(!in_array('pm',$current_role)){ echo 'disabled'; } ?> style="width:200px;" >
			<option selected="selected" value="All"><?php echo __("All User", "oasisworkflow")?></option>
			<?php
				foreach($users_select_options as $uso)
				{
					if($user_id ==$uso->ID)
					{
						echo "<option value='".$uso->ID."' selected>{$uso->user_login}</option>" ;
					}
					else
					{
						echo "<option value='".$uso->ID."'>{$uso->user_login}</option>" ;
					}
				}				
			?>			
		</select>
		<!--<input type="button" id="filter-button-in-monitor" class="button-secondary action" value="<?php //echo __("Show", "oasisworkflow"); ?>" />-->
		
	</div>
	
	<div class="process-part wrap">
		<label style='color:gray;font-weight:bold;font-size:18px;'><?php echo __("Not Start Task:","oasisworkflow");?></label>
		<table class="wp-list-table widefat fixed posts" id="notstart-process-list-table-in-monitor">
			<thead>
				<tr style="background-color: #FFF">
					<!--<th id="sort-action-name" class="sortable desc"><a><span>Not Start</span></a></th>-->
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Workflow</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Task</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">PIC</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Worked Effort (days)</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Estimate Effort (days)</span></a></th>	
					<th id="sort-DeadLine-name" class="sortable desc"><a><span style="color:black">Deadline</span></a></th>		
				</tr>
			</thead>
			<tbody id="notstart-process-list-tbody-in-monitor">
				<?php
					
					foreach($all_monitor_datas as $monitor_data)
					{
						if($monitor_data->Status=="Gray")
						{
							$work_effort_yet=0;
							$pid = $monitor_data->WorkflowID;
							$workflowname = $wpdb->get_results("select Name from ". $wftable ." where id = ".$pid ." ");
							//$deadline = date_format($monitor_data->CommitDate,"Y-m-d");
							if($currentUser ==$monitor_data->user_login && !in_array('pm',$current_role))
							{
								echo "<td>".$workflowname[0]->Name."_".$pid."</td>";
								echo "<td>".$monitor_data->Name."</td>";
								echo "<td>".$monitor_data->user_login."</td>";
								echo "<td>".$work_effort_yet."</td>";
								echo "<td>".$monitor_data->PlanEffort."</td>";
								echo "<td>".date('Y-m-d', strtotime($monitor_data->CommitDate))."</td></tr>";
							}
							else if (in_array('pm',$current_role))
							{
								echo "<td>".$workflowname[0]->Name."_".$pid."</td>";
								echo "<td>".$monitor_data->Name."</td>";
								echo "<td>".$monitor_data->user_login."</td>";
								echo "<td>".$work_effort_yet."</td>";
								echo "<td>".$monitor_data->PlanEffort."</td>";
								echo "<td>".date('Y-m-d', strtotime($monitor_data->CommitDate))."</td></tr>";
							}
						}
					}					
				?>
			</tbody>
		</table>	
	</div>
	<br class="clear">
	<div class="process-part wrap">
		<label style='color:red;font-weight:bold;font-size:18px;'><?php echo __("Delay Task:","oasisworkflow");?></label>
		<table class="wp-list-table widefat fixed posts" id="delay-process-list-table-in-monitor">
			<thead>
				<tr style="background-color: #FFF">
					<!--<th id="sort-action-name" class="sortable desc"><a><span>Delay</span></a></th>-->
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Workflow</span></a></th>
					<th id="sort-Process-name" class="sortable desc"><a><span style="color:black">Task</span></a></th>
					<th id="sort-Actor-name" class="sortable desc"><a><span style="color:black">PIC</span></a></th>
					<th id="sort-Worked-Effort-name" class="sortable desc"><a><span style="color:black">Worked Effort (days)</span></a></th>
					<th id="sort-Estimate-Effort-name" class="sortable desc"><a><span style="color:black">Estimate Effort (days)</span></a></th>	
					<th id="sort-DeadLine-name" class="sortable desc"><a><span style="color:black">Deadline</span></a></th>							
				</tr>
			</thead>
			<tbody id="delay-process-list-tbody-in-monitor">
				<?php 
					foreach($all_monitor_datas as $monitor_data)
					{
						if($monitor_data->Status=="Red")
						{
							$work_effort_yet=FCWorkflowMonitor::get_workdays($monitor_data->ActualStartDate,$current_date);
							$pid = $monitor_data->WorkflowID;
							$workflowname = $wpdb->get_results("select Name from ". $wftable ." where id = ".$pid ." ");
							if($currentUser ==$monitor_data->user_login && !in_array('pm',$current_role))
							{
								echo "<td>".$workflowname[0]->Name."_".$pid."</td>";
								echo "<td>".$monitor_data->Name."</td>";
								echo "<td>".$monitor_data->user_login."</td>";
								echo "<td>".$work_effort_yet."</td>";
								echo "<td>".$monitor_data->PlanEffort."</td>";
								echo "<td>".date('Y-m-d', strtotime($monitor_data->CommitDate))."</td></tr>";
							}
							else if (in_array('pm',$current_role))
							{
								echo "<td>".$workflowname[0]->Name."_".$pid."</td>";
								echo "<td>".$monitor_data->Name."</td>";
								echo "<td>".$monitor_data->user_login."</td>";
								echo "<td>".$work_effort_yet."</td>";
								echo "<td>".$monitor_data->PlanEffort."</td>";
								echo "<td>".date('Y-m-d', strtotime($monitor_data->CommitDate))."</td></tr>";
							}
						}
					}	
				?>
			</tbody>
		</table>	
	</div>	
	<br class="clear">
	<div class="process-part wrap">
		<label style='color:green;font-weight:bold;font-size:18px;'><?php echo __("In Progress Task:","oasisworkflow");?></label>
		<table class="wp-list-table widefat fixed posts"  id="inprogress-process-list-table-in-monitor">
			<thead>
				<tr style="background-color: #FFF">
					<!--<th id="sort-action-assignee" class="sortable desc"><a><span>In Progress</span></a></th>-->
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Workflow</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Task</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">PIC</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Worked Effort (days)</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Estimate Effort (days)</span></a></th>	
					<th id="sort-DeadLine-name" class="sortable desc"><a><span style="color:black">Deadline</span></a></th>		
				</tr>
			</thead>
			<tbody id="inprogress-process-list-tbody-in-monitor">
				<?php 
					foreach($all_monitor_datas as $monitor_data)
					{
						if($monitor_data->Status=="Green")
						{
							$work_effort_yet=FCWorkflowMonitor::get_workdays($monitor_data->ActualStartDate,$current_date);
							$pid = $monitor_data->WorkflowID;
							$workflowname = $wpdb->get_results("select Name from ". $wftable ." where id = ".$pid ." ");
							if($currentUser ==$monitor_data->user_login && !in_array('pm',$current_role))
							{
								echo "<td>".$workflowname[0]->Name."_".$pid."</td>";
								echo "<td>".$monitor_data->Name."</td>";
								echo "<td>".$monitor_data->user_login."</td>";
								echo "<td>".$work_effort_yet."</td>";
								echo "<td>".$monitor_data->PlanEffort."</td>";
								echo "<td>".date('Y-m-d', strtotime($monitor_data->CommitDate))."</td></tr>";
							}
							else if (in_array('pm',$current_role))
							{
								echo "<td>".$workflowname[0]->Name."_".$pid."</td>";
								echo "<td>".$monitor_data->Name."</td>";
								echo "<td>".$monitor_data->user_login."</td>";
								echo "<td>".$work_effort_yet."</td>";
								echo "<td>".$monitor_data->PlanEffort."</td>";
								echo "<td>".date('Y-m-d', strtotime($monitor_data->CommitDate))."</td></tr>";
							}
						}
					}	
				?>
			</tbody>
		</table>	
	</div>
	<br class="clear">
	<div class="process-part wrap">
		<label style='color:black;font-weight:bold;font-size:18px;'><?php echo __("Complete Task:","oasisworkflow");?></label>
		<table class="wp-list-table widefat fixed posts" id="complete-process-list-table-in-monitor">
			<thead>
				<tr style="background-color: #FFF">
					<!--<th id="sort-action-status" class="sortable desc"><a><span>Complete</span></a></th>-->
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Workflow</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Task</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">PIC</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Worked Effort (days)</span></a></th>
					<th id="sort-action-name" class="sortable desc"><a><span style="color:black">Estimate Effort (days)</span></a></th>	
					<th id="sort-DeadLine-name" class="sortable desc"><a><span style="color:black">Deadline</span></a></th>		
				</tr>
			</thead>
			<tbody id="complete-process-list-tbody-in-monitor">
				<?php 
					foreach($all_monitor_datas as $monitor_data)
					{
						if($monitor_data->Status=="Black")
						{
							$work_effort_yet=FCWorkflowMonitor::get_workdays($monitor_data->ActualStartDate,$monitor_data->CommitDate);
							$pid = $monitor_data->WorkflowID;
							$workflowname = $wpdb->get_results("select Name from ". $wftable ." where id = ".$pid ." ");
							if($currentUser ==$monitor_data->user_login && !in_array('pm',$current_role))
							{
								echo "<td>".$workflowname[0]->Name."_".$pid."</td>";
								echo "<td>".$monitor_data->Name."</td>";
								echo "<td>".$monitor_data->user_login."</td>";
								echo "<td>".$work_effort_yet."</td>";
								echo "<td>".$monitor_data->PlanEffort."</td>";
								echo "<td>".date('Y-m-d', strtotime($monitor_data->CommitDate))."</td></tr>";
							}
							else if (in_array('pm',$current_role))
							{
								echo "<td>".$workflowname[0]->Name."_".$pid."</td>";
								echo "<td>".$monitor_data->Name."</td>";
								echo "<td>".$monitor_data->user_login."</td>";
								echo "<td>".$work_effort_yet."</td>";
								echo "<td>".$monitor_data->PlanEffort."</td>";
								echo "<td>".date('Y-m-d', strtotime($monitor_data->CommitDate))."</td></tr>";
							}
						}
					}	
				?>
			</tbody>
		</table>	
	</div>	
	
</div>