<style>
.goo-collapsible{	
	list-style: none;
	position:absolute;
	right:10px;
    font-family: 'HelveticaNeue', Arial, Helvetica, sans-serif;
    font-size:14px;}
/*header line style and border*/
.goo-collapsible li.header{
	color: #666;
    padding:4px 12px;
	font-weight:bold;
    border: 1px solid #bbb;}
/*set border for every line of menu nad remove top border becouse we dont want double border with header border. */
.goo-collapsible li { 
	border: 1px solid #bbb;
    border-top:0;
    margin: 0;
    background:#F0F0F0;}
/*remove decoration from text links and treat it as a block.*/
.goo-collapsible li a {
	text-decoration:none;
    color:#666;
    display:block;
    padding:8px 12px;}
/*we dont want text to be underline as regular link*/
.goo-collapsible li a:hover {
	background: #F8F8F8;
    text-decoration:none;}
/*remove list style (circles) for submenu*/    
.goo-collapsible li ul {
	list-style: none;
    background: #d3d3d3;
    display: none;
    margin:0;
    padding:0;}
/*remove border and set only bottom border for submenu*/    
.goo-collapsible li ul li {
	margin:0; 
    border:0; 
    border-bottom:1px solid #bbb;}
/*remove bottom border from last element in submenu*/    
.goo-collapsible li ul li:last-child {
	border-bottom:0;}
/*set padding for submenu to be inline with maimenu*/    
.goo-collapsible li ul li a {
	padding: 5px 10px; 
    display: block; 
    padding-left: 33px;
    background: #d3d3d3; }
/*remove text decoration for links*/
.goo-collapsible li ul li a:hover {
text-decoration: none;
background: #d9d9d9; }
/*for menu witch have a submenu display some icom*/
.goo-collapsible .dropdown > a { 
	background: url(/images/arrowdown.png) no-repeat right center; }
/*set some hover color on drop down menu*/
.goo-collapsible .dropdown > a:hover { background: #F8F8F8 url(/images/arrowdown.png) no-repeat right center !important; }
</style>
<script src="/wordpress/wp-content/plugins/oasis-workflow/js/lib/navigationbar.js"></script>

<div id="nav-menu" style="width:200px;">
	<ul class="goo-collapsible ">
		<li class="header" >MAIN NAVIGATION</li>
		
		<li class="dropdown"><a class="" href="#">Workflow</a>
			<ul>
				<li><a href="?page=oasiswf-dot">Import Workflow</a></li>
				<li><a href="?page=oasiswf-workflowsetup">Workflow Setup</a></li>
				<li><a href="?page=oasiswf-workflowfine2">Workflow Fine tuning</a></li>
			</ul>
		</li>
		<li class="dropdown"><a class="" href="#">Tools</a>
			<ul>
				<li><a href="?page=oasiswf-taskassign">Task Assign</a></li>
				<li><a href="?page=oasiswf-monitor">Monitor Tool</a></li>
				<li><a href="?page=oasiswf-workflowactionhistory">User Activity</a></li>
			</ul>
		</li>
	</ul>
</div>
<div class="wrap">
	<form id="dot-form" method="post" enctype="multipart/form-data" action="#">
		<div id="icon-edit" class="icon32 icon32-posts-post"><br></div>
		<h2><?php echo __("IMPORT WORKFLOW", "oasisworkflow"); ?></h2>
		<hr style="height:1px;margin:10px;">
		<div id="workflow-new-fromdot" style="border:1px solid transparent;width:100%;height:160px;background-color:white;min-width:1120px">
			<div style="float:left;margin-left:30px;">
				<h4>Import Workflow Design</h4>
				<?php echo __("Please choose your design model(.xls) and import to Design Database.","oasisworkflow"); ?>
			</div>
			<div class="filediv" style="float:right;padding:40px 30px 0px 0px;">
				<input id="txtFile" type="file" name="file_import" style="float:left;width:600px;margin-bottom:5px;" accept=".xls,.xlsx"/>
				<div style="clear:left;" >
				<hr style="height:1px;border:none;border-top:1px dashed lightgray;"/>
				<div>
					<input type="Submit" id="importBtn" class="button button-primary button-large" style="width:60px;float:left;font-size:12px;" value="Import"/>
					<div style="clear:left;"/>
				</div>
			</div>
		</div>
	</form>
</div>

<?php  
	ob_start();
	if (! empty( $_FILES ['file_import'] ['name'] )) 
	{
		$tmp_file = $_FILES ['file_import'] ['tmp_name'];
		$file_types = explode ( ".", $_FILES ['file_import'] ['name'] );
		$file_type = $file_types [count ( $file_types ) - 1];

		$savePath = OASISWF_ROOT . '/temp/';
		date_default_timezone_set('Asia/Shanghai');
		$wfstr = date ( 'Ymdhis' ); 
		$file_name = $wfstr . "." . $file_type;
		$wfname=basename($_FILES ['file_import'] ['name'],'.'.$file_type);
		if ( copy ( $tmp_file, $savePath . $file_name )) 
		{
			//$b= FCWorkflowDot::get_post_import_workflow($savePath . $file_name ,$wfname);
			//$b=FCWorkflowDot::import_workflow_to_sqlserver($savePath . $file_name ,$wfname);
			$b=FCWorkflowDot::import_workflow_scheme_to_mysql($savePath . $file_name ,$wfname);
			if($b===false)
			{
				print_r("Failed to import workflow!");
			}
			else
			{
				FCWorkflowDot::save_action_to_mysql("Import","","","");//add by huyq
				echo '<script language="javascript">';
				echo 'window.location = "admin.php?page=oasiswf-workflowsetup"';
				echo '</script>';
				return;
			}
		}
		else
		{
			print_r("Failed to import workflow!");
		}
	}
?>