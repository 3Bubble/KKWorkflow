<?php
	$result_wf = FCWorkflowBase::get_running_workflows();
	$result_wf = explode(";",$result_wf);
?>
<div style="margin-top:20px;">
	<h1>Workflow Status</h1>
	<form method="POST" >
	<select name="workflowTitle">
		<?php for ($i=0;$i<count($result_wf)-1;$i++)
		{
			echo "<option>$result_wf[$i]</option>";
		}
		?>
	</select>
	<input type="submit" value="View" />
	</form>
	<hr style="margin-top:10px;">
	
	<p >
	
	<?php 
	if(isset($_POST["workflowTitle"]))
	{
		$wfTile = sanitize_text_field($_POST["workflowTitle"]);
	}
	$wfTile = explode(",",$wfTile);
	
	$result_process = FCWorkflowBase::get_all_processes($wfTile[1]);
	if(isset($result_process))
	{
		echo "<h3>$wfTile[0] - Working Status</h3>";
	}
	else 
	{
	}
	$result_process_trim = explode(";", $result_process);
	echo "<div style='font-weight:bold;'>
		<table style='border-collapse:collapse;' class='wp-list-table widefat fixed posts' >
			<thead>
				<tr style='background-color: #FFF;'>
					<th style='padding:10px;text-align:left;'>Process</th>
					<th style='padding:10px;text-align:left;'>Plan Effort</th>
					<th style='padding:10px;text-align:left;'>Assignee ID</th>
				</tr>
			</thead>";
	for ($i=0;$i<count($result_process_trim)-1;$i++)
	{
		$result_process_trim2 = explode(",", $result_process_trim[$i]);
		$assignee = FCWorkflowBase::getAssigneeName($result_process_trim2[4]);
		if($result_process_trim2[3]!=0)
		{
			echo "<tr style='background-color:#FFF;'>
				<td style='padding:5px;color:$result_process_trim2[2];'>$result_process_trim2[0]</td>
				<td style='padding:5px;'>$result_process_trim2[3]</td>
				<td style='padding:5px;'>$assignee </td>
			</tr>";
		}
	}
	echo "</table> </div>";	
		
	?>
	</p>
	
	
</div>