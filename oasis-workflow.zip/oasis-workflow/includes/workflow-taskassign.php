<?php
/*************************************/
/*     Workflow Task Assign          */
/*************************************/

class FCWorkflowTaskAssign extends FCWorkflowBase
{
	static function get_workflow_CurrentUsername()
	{
		$user = wp_get_current_user();
		return $user->user_login ;
	}
	static function save_workflow_taskassign()
	{   
		global $wpdb;
		$workflowobject = $_POST["workflow"];
		$processes = $_POST["processes"];
		$workflow_table = FCUtility::get_dnt_workflows_table_name();
	   	$result = $wpdb->update($workflow_table,
								array(
									'PlanStartDate' => $workflowobject["plan_start_date"],
									'PlanEffort' => $workflowobject["plan_effort"],
									'ActualStartDate' => $workflowobject["plan_start_date"],
								),
								array('ID' => $workflowobject["ID"] )
					);
		$conn = mysql_connect('localhost','root','root') or die ("connect fails");
		mysql_select_db('db_wordpress',$conn);	
		mysql_query("CREATE EVENT `workflow_fine2_event` ON SCHEDULE AT '".$workflowobject["plan_start_date"]."' ON COMPLETION PRESERVE ENABLE DO UPDATE ".$workflow_table ." set status = 'green' where ID ='".$workflowobject["ID"]."'");
		
		$process_table = FCUtility::get_dnt_workflow_steps_table_name();
		foreach($processes as $process)
		{
			$result = $wpdb->update($process_table,
								array(
									'PlanStartDate' => $process["plan_start_date"],
									'PlanEffort' => $process["plan_effort"],
									'ActualStartDate' => $process["plan_start_date"],
									'CommitDate' => $process["plan_end_date"],
									'AssigneeID'=> $process["assignee"]
								),
								array('ID' => $process["ID"] )
					);
			$mapArr[]= $process["ID"];
		}
	   
	   $result = FCWorkflowBase::save_action_to_mysql("Assignment",$workflowobject["name"],"",$mapArr);
	   echo $result;
	   exit();
	}
	static function get_workflow_leader_gpname()
	{
		global $wpdb;
		$workflowid = $_POST["workflowid"];
		$currentUserID = wp_get_current_user()->ID;
		$result = $wpdb->get_results( "SELECT * FROM " . FCUtility::get_dnt_workflow_StakeHolder_table_name() . " where WorkFlowID =".$workflowid." and Participant = ".$currentUserID);
		echo json_encode($result) ;
		exit();
	}
	static function get_workflow_dropdownlist_taskassign()
	{     
	   global $wpdb;
	   $workflowTable = FCUtility::get_dnt_workflows_table_name();
	   $stakeholderTable = FCUtility::get_dnt_workflow_StakeHolder_table_name() ;
	   $userid = wp_get_current_user()->ID;
	   $result = $wpdb->get_results( "SELECT * FROM  ".$stakeholderTable." inner join ".$workflowTable." on ".$workflowTable.".ID = ".$stakeholderTable.".workflowid where Status!='black' and Participant = ".$userid." ORDER BY name desc" );
	   return $result;
	}
    
	static function get_selected_workflow_taskassign()
	{   
	   global $wpdb;
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));  
	   $result = $wpdb->get_results( "SELECT * FROM " . FCUtility::get_dnt_workflows_table_name() . " where ID =".$id);
	   echo json_encode($result) ;
	   exit();
	}
	
	static function get_process_list_in_workflow_taskassign()
	{   
	   global $wpdb;
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	   $result = $wpdb->get_results( "SELECT * FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " where WorkflowID =".$id);
	   echo json_encode($result);
	   exit();
	}
	

	static function get_process_connections_taskassign()
	{   
	   global $wpdb;
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	   $result = $wpdb->get_results( "SELECT * FROM " . FCUtility::get_dnt_workflow_edge_table_name() . " where WorkflowID =".$id);
	   echo json_encode($result);
	   exit();
	}
	
	// DNT - MAR,9 2016 NK Start
	static function getCriticalPath_in_workflow_taskassign()
	{
		global $wpdb;
	    $id = intval( sanitize_text_field( $_POST["workflowid"] ));
		$result = FCWorkflowBase::getCriticalPath($id);
		echo $result;
	    exit();
	}
	static function get_all_processes_in_workflow_fine2()
	{
		global $wpdb;
	    $id = intval( sanitize_text_field( $_POST["workflowid"] ));
		$result = FCWorkflowBase::get_all_processes($id);
		echo $result;
	    exit();
	}
	static function getAllPaths_in_workflow_fine2()
	{
		global $wpdb;
	    $id = intval( sanitize_text_field( $_POST["workflowid"] ));
		$result = FCWorkflowBase::getAllPaths($id);
		echo $result;
	    exit();
	}
	// DNT - MAR,9 End
	
	static function get_group_by_user_taskassign()
	{   
	   $userName = sanitize_text_field( $_POST["username"] );
	   
	   $conn =FCWorkflowFine2::connect_sql_server();   
	   $sql = "SELECT * FROM SystemUser where Name = '$userName'";
	   $query = sqlsrv_query($conn,$sql);
	   
	   $groupObjects =array();
	   while($rows= sqlsrv_fetch_object($query))
	   {
			$groupObjects[] = $rows; 
	   }

	   sqlsrv_close($conn);
	   echo json_encode($groupObjects);
	   exit();
	}
	
	static function get_first_process_taskassign()
	{   
	   global $wpdb;
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	   $result = $wpdb->get_results( "SELECT * FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " where IsFirstStep='Yes' and WorkflowID =".$id);    
	   echo json_encode($result);
	   exit();
	}
	
	static function get_groups_in_workflow_taskassign()
	{   
	   global $wpdb;
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	   $result = $wpdb->get_results( "SELECT distinct GroupName FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " where WorkflowID =".$id);  
	   echo json_encode($result);
	   exit();
	}
	
	static function get_users_by_group_taskassign()
	{   
	   global $wpdb;
	   $groupname = sanitize_text_field( $_POST["groupname"] );
	   $groupname = '%' . $groupname . '%';
       $users = $wpdb->get_results( $wpdb->prepare( "SELECT users_1.ID, users_1.user_login FROM {$wpdb->base_prefix}users users_1
   				INNER JOIN {$wpdb->base_prefix}usermeta usermeta_1 ON ( users_1.ID = usermeta_1.user_id )
   				WHERE (usermeta_1.meta_key = '{$wpdb->prefix}capabilities' AND CAST( usermeta_1.meta_value AS CHAR ) LIKE %s)", $groupname ) );
	   echo json_encode($users);
	   exit();
	}
	
	static function get_workflow_effort_by_criticalpath_taskassign()
    {
		global $wpdb;
	    $id = intval( sanitize_text_field( $_POST["workflowid"] ));
		$result = FCWorkflowBase::getCriticalPathEffort($id);
		echo $result;
	    exit();
	} 
	
	static function save_workflow_fine2()
	{   
		global $wpdb;
		$workflowobject = $_POST["workflow"];
		$processes = $_POST["processes"];
		$workflow_table = FCUtility::get_dnt_workflows_table_name();
	   	$result = $wpdb->update($workflow_table,
								array(
									'PlanStartDate' => $workflowobject["plan_start_date"],
									'PlanEffort' => $workflowobject["plan_effort"],
									'ActualStartDate' => $workflowobject["plan_start_date"],
								),
								array('ID' => $workflowobject["ID"] )
					);
		$conn = mysql_connect('localhost','root','root') or die ("connect fails");
		mysql_select_db('db_wordpress',$conn);	
		mysql_query("CREATE EVENT `workflow_fine2_event` ON SCHEDULE AT '".$workflowobject["plan_start_date"]."' ON COMPLETION PRESERVE ENABLE DO UPDATE ".$workflow_table ." set status = 'green' where ID ='".$workflowobject["ID"]."'");
		
		$process_table = FCUtility::get_dnt_workflow_steps_table_name();
		foreach($processes as $process)
		{
			$result = $wpdb->update($process_table,
								array(
									'PlanStartDate' => $process["plan_start_date"],
									'PlanEffort' => $process["plan_effort"],
									'ActualStartDate' => $process["plan_start_date"],
									'CommitDate' => $process["plan_end_date"],
									'AssigneeID'=> $process["assignee"]
								),
								array('ID' => $process["ID"] )
					);
			$mapArr[]= $process["ID"];//add by huyq
		}
	   
	   $result = FCWorkflowBase::save_action_to_mysql("FineTune","","",$mapArr);//add by huyq
	   echo $result;
	   exit();
	}
	
	static function get_table_header()
	{
		$sortby = ( isset($_GET['order']) && sanitize_text_field( $_GET["order"] ) == "desc" ) ? "asc" : "desc" ;
      $author_class = $workflow_class = $due_date_class = $post_order_class = $post_type_class = '';
      if( isset($_GET['orderby']) && isset($_GET['order']) ) {
      	$orderby = sanitize_text_field( $_GET['orderby'] );
         switch ($orderby) {
	         case 'author':
	            $author_class = $sortby;
	            break;
	         case 'due_date':
	            $due_date_class = $sortby;
	            break;
	         case 'post_title':
	         	$post_order_class = $sortby;
	         	break;
	         case 'post_type':
	         	$post_order_class = $sortby;
	         	break;	         	
	      }
      }
				
		echo "<tr>";
		//echo "<th scope='col' class='manage-column check-column' ><input type='checkbox'></th>";
		echo "<th width='300px' scope='col' class='sorted $post_order_class'>
				<a href='admin.php?page=oasiswf-workflowfine2&orderby=post_title&order=$sortby" . "'>
					<span>". __("Process Name", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
				</a>				
				</th>";
		echo "<th scope='col' class='sorted $author_class'>
			<a href='admin.php?page=oasiswf-workflowfine2&orderby=post_author&order=$sortby" . "'>
					<span>" . __("Group Name", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "<th scope='col' class='sorted $author_class'>
			<a href='admin.php?page=oasiswf-workflowfine2&orderby=post_author&order=$sortby" . "'>
					<span>" . __("Assignee", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "<th scope='col' class='sorted $due_date_class'>
			<a href='admin.php?oasiswf-workflowfine2&orderby=due_date&order=$sortby" . "'>
					<span>" .  __("Plan Effort", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";	
		echo "<th scope='col' class='sorted $due_date_class'>
			<a href='admin.php?page=oasiswf-workflowfine2&orderby=due_date&order=$sortby" . "'>
					<span>" .  __("Plan Start Date", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "<th scope='col' class='sorted $due_date_class'>
			<a href='admin.php?page=oasiswf-workflowfine2&orderby=due_date&order=$sortby" . "'>
					<span>" .  __("Plan End Date", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "</tr>";
	}
	
}

?>