<?php
class FCWorkflowDot extends FCWorkflowBase
{
   static function import_workflow_to_sqlserver($filepath,$wfname)
   {
		error_reporting(E_ALL);
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		date_default_timezone_set('Asia/ShangHai');
		
		require_once dirname(__File__).'/../Classes/PHPExcel/IOFactory.php';
		
		$objPHPExcel = PHPExcel_IOFactory::load($filepath);

		$sheet = $objPHPExcel->getSheet(0); 
		$highestRow = $sheet->getHighestRow(); 
		$highestColumm = $sheet->getHighestColumn(); 
		$colunmNum=PHPExcel_Cell::columnIndexFromString($highestColumm);
		$one=1;
		$two=2;
		
		SqlsrvDB::connect();
		$tableName='WorkFlow';
		$data=array(
			'Name' => $wfname,
			'SetupDate' => date("Y-m-d"),
			'PlanStartDate' => date("Y-m-d"),
			'PlanEffort' => $colunmNum-2,
			'ActualStartDate' => date("Y-m-d"),
			'CommitDate' => null,
			'WorkFlowSchemeID' => 1,
			'Status' => 'Red'
			);
		$wfid=SqlsrvDB::autoIdAdd($tableName,$data);
		
		if($wfid===false)
		{
			return false;
		}
		$tableName='Process';
		$stepIdList=array();
		for($icol=0;$icol<$colunmNum-2;$icol++)
		{
			$column= PHPExcel_Cell::stringFromColumnIndex($icol+2);
			$stepName = $sheet->getCell($column.$one)->getValue();
			$PIC = $sheet->getCell($column.$two)->getValue();
			$data=array(
				'Name' => $stepName,
				'WorkFlowID' => $wfid, 
				'PlanStartDate' => date("Y-m-d", strtotime("+".$icol." day")),
				'PlanEffort' => 1,
				'ActualStartDate' => date("Y-m-d", strtotime("+".$icol." day")),
				'CommitDate' => null,
				'GroupName' => $PIC, 
				'Assignee' => '',
				'Status' => 'Red', 
				'IsFirstStep' => $icol===0?'Yes':'No',
				'Input' => '',
				'Output' => ''
			);
			$stepid=SqlsrvDB::autoIdAdd($tableName,$data);
			if($stepid===false)
			{
				return false;
			}
			array_push($stepIdList,$stepid);
		}
		$tableName='ProcessConnection';
		$carriercolumn=PHPExcel_Cell::stringFromColumnIndex(1);
		for ($row = 7; $row <= $highestRow; $row++){
			$create=0;
			$use=0;
			$carrier=$sheet->getCell($carriercolumn.$row)->getValue();
			for($icol=2;$icol<$colunmNum;$icol++)
			{
				$column= PHPExcel_Cell::stringFromColumnIndex($icol);
				$val = $sheet->getCell($column.$row)->getValue();
				if( strcmp($val,"Create")==0)
				{
					$create=$icol-2;
				}
				else if(strcmp($val,"Use")==0)
				{
					$use=$icol-2;
				}
			}
			$data=array(
				'WorkflowID' => $wfid, 
				'CreateProcessID' => $stepIdList[$create], 
				'UseProcessID' => $stepIdList[$use], 
				'Status' => 'Red', 
				'Carrier' => $carrier
			);
			$connectionid=SqlsrvDB::autoIdAdd($tableName,$data);
			if($connectionid===false)
			{
				return false;
			}
		}
		SqlsrvDB::close();
		return $wfid;
   }
   
   static function import_workflow_to_mysql($filepath,$wfname)
   {
		global $wpdb;
		error_reporting(E_ALL);
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		date_default_timezone_set('Asia/ShangHai');
		
		require_once dirname(__File__).'/../Classes/PHPExcel/IOFactory.php';
		
		$objPHPExcel = PHPExcel_IOFactory::load($filepath);

		$sheet = $objPHPExcel->getSheet(0); 
		$highestRow = $sheet->getHighestRow(); 
		$highestColumm = $sheet->getHighestColumn(); 
		$colunmNum=PHPExcel_Cell::columnIndexFromString($highestColumm);
		$one=1;
		$two=2;
		$four=4;
		$isIntact=true;
		for($icol=0;$icol<$colunmNum-2;$icol++)
		{
			$column= PHPExcel_Cell::stringFromColumnIndex($icol+2);
			$stepName = $sheet->getCell($column.$one)->getValue();
			if(empty($stepName))
				break;
			$PIC = $sheet->getCell($column.$two)->getValue();
			if($PIC===NULL)
			{
				$isIntact=false;
				print_r($stepName."(column ".($icol+3)."), PIC is empty!</br>");
			}
			$effort = $sheet->getCell($column.$four)->getValue();
			if($effort===NULL || !is_numeric($effort))
			{
				$isIntact=false;
				print_r($stepName."(column ".($icol+3)."), effort is empty or not a number!</br>");
			}
		}
		if($isIntact==false)
		{
			return false;
		}
		
		$tableName=FCUtility::get_workflows_table_name();
		$data=array(
			'Name' => $wfname,
			'SetupDate' => date("Y-m-d"),
			'PlanEffort' => $colunmNum-2,
			'WorkFlowSchemeID' => 1,
			'Status' => 'Gray',
			'version' => 1
			);
		
		$result = $wpdb->insert($tableName, $data);
		if($result)
			$wfrow = $wpdb->get_row("SELECT max(ID) as maxid FROM $tableName");
		else
			return false;
			
		if($wfrow)
			$wfid = $wfrow->maxid ;
		else
			return false;
		$tableName=FCUtility::get_workflow_steps_table_name();
		$stepIdList=array();
		for($icol=0;$icol<$colunmNum-2;$icol++)
		{
			$column= PHPExcel_Cell::stringFromColumnIndex($icol+2);
			$stepName = $sheet->getCell($column.$one)->getValue();
			if(empty($stepName))
				break;
			$PIC = $sheet->getCell($column.$two)->getValue();
			$effort = $sheet->getCell($column.$four)->getValue();
			$data=array(
				'Name' => $stepName,
				'WorkFlowID' => $wfid, 
				'PlanEffort' => $effort,
				'GroupName' => $PIC, 
				'Status' => 'Gray', 
				'IsFirstStep' => $icol===0?'Yes':'No',
				'Input' => '',
				'Output' => ''
			);
			$result = $wpdb->insert($tableName, $data);
			if($result)
				$wfrow = $wpdb->get_row("SELECT max(ID) as maxid FROM $tableName");
			else
				return false;
				
			if($wfrow)
				$stepid = $wfrow->maxid ;
			else
				return false;
			
			array_push($stepIdList,$stepid);
		}
		$tableName=FCUtility::get_workflow_edge_table_name();
		$carriercolumn=PHPExcel_Cell::stringFromColumnIndex(1);
		for ($row = 7; $row <= $highestRow; $row++){
			$create=0;
			$use=0;
			$carrier=$sheet->getCell($carriercolumn.$row)->getValue();
			for($icol=2;$icol<$colunmNum;$icol++)
			{
				$column= PHPExcel_Cell::stringFromColumnIndex($icol);
				$val = $sheet->getCell($column.$row)->getValue();
				if( strcmp($val,"Create")==0)
				{
					$create=$icol-2;
				}
				else if(strcmp($val,"Use")==0)
				{
					$use=$icol-2;
				}
			}
			$data=array(
				'WorkflowID' => $wfid, 
				'CreateProcessID' => $stepIdList[$create], 
				'UseProcessID' => $stepIdList[$use], 
				'Status' => 'Red', 
				'Carrier' => $carrier
			);
			$result = $wpdb->insert($tableName, $data);
			if(!$result)
				return false;
		}
		return $wfid;
   }
   
   static function import_workflow_scheme_to_mysql($filepath,$wfname)
   {
		global $wpdb;
		error_reporting(E_ALL);
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		date_default_timezone_set('Asia/ShangHai');
		
		require_once dirname(__File__).'/../Classes/PHPExcel/IOFactory.php';
		
		$objPHPExcel = PHPExcel_IOFactory::load($filepath);

		$sheet = $objPHPExcel->getSheet(0); 
		$highestRow = $sheet->getHighestRow(); 
		$highestColumm = $sheet->getHighestColumn(); 
		$colunmNum=PHPExcel_Cell::columnIndexFromString($highestColumm);
		$one=1;
		$two=2;
		$four=4;
		$isIntact=true;
		for($icol=0;$icol<$colunmNum-2;$icol++)
		{
			$column= PHPExcel_Cell::stringFromColumnIndex($icol+2);
			$stepName = $sheet->getCell($column.$one)->getValue();
			if(empty($stepName))
				break;
			$PIC = $sheet->getCell($column.$two)->getValue();
			if($PIC===NULL)
			{
				$isIntact=false;
				print_r($stepName."(column ".($icol+3)."), PIC is empty!</br>");
			}
			$effort = $sheet->getCell($column.$four)->getValue();
			if($effort===NULL || !is_numeric($effort))
			{
				$isIntact=false;
				print_r($stepName."(column ".($icol+3)."), effort is empty or not a number!</br>");
			}
		}
		if($isIntact==false)
		{
			return false;
		}
		
		$tableName=FCUtility::get_dnt_workflowscheme_table_name();
		$data=array(
			'Name' => $wfname,
			'CreateDate' => date("Y-m-d h:i:s", time()),
			'version' => 1
			);
		
		$result = $wpdb->insert($tableName, $data);
		if($result)
			$wfrow = $wpdb->get_row("SELECT max(ID) as maxid FROM $tableName");
		else
			return false;
			
		if($wfrow)
			$wfid = $wfrow->maxid ;
		else
			return false;
		$tableName=FCUtility::get_dnt_workflow_stepsScheme_table_name();
		$stepIdList=array();
		for($icol=0;$icol<$colunmNum-2;$icol++)
		{
			$column= PHPExcel_Cell::stringFromColumnIndex($icol+2);
			$stepName = $sheet->getCell($column.$one)->getValue();
			if(empty($stepName))
				break;
			$PIC = $sheet->getCell($column.$two)->getValue();
			$effort = $sheet->getCell($column.$four)->getValue();
			$data=array(
				'Name' => $stepName,
				'WorkFlowSchemeID' => $wfid, 
				'PlanEffort' => $effort,
				'GroupName' => $PIC, 
				'IsFirstStep' => $icol===0?'Yes':'No',
				'Version' => 1,
				'CreateDate' => date("Y-m-d h:i:s", time())
			);
			$result = $wpdb->insert($tableName, $data);
			if($result)
				$wfrow = $wpdb->get_row("SELECT max(ID) as maxid FROM $tableName");
			else
				return false;
				
			if($wfrow)
				$stepid = $wfrow->maxid ;
			else
				return false;
			
			array_push($stepIdList,$stepid);
		}
		$tableName=FCUtility::get_dnt_workflow_edgeScheme_table_name();
		$carriercolumn=PHPExcel_Cell::stringFromColumnIndex(1);
		for ($row = 7; $row <= $highestRow; $row++){
			$create=0;
			$use=0;
			$carrier=$sheet->getCell($carriercolumn.$row)->getValue();
			for($icol=2;$icol<$colunmNum;$icol++)
			{
				$column= PHPExcel_Cell::stringFromColumnIndex($icol);
				$val = $sheet->getCell($column.$row)->getValue();
				if( strcmp($val,"Create")==0)
				{
					$create=$icol-2;
				}
				else if(strcmp($val,"Use")==0)
				{
					$use=$icol-2;
				}
			}
			$data=array(
				'WorkflowSchemeID' => $wfid, 
				'CreateProcessID' => $stepIdList[$create], 
				'UseProcessID' => $stepIdList[$use], 
				'Discription' => $carrier
			);
			$result = $wpdb->insert($tableName, $data);
			if(!$result)
				return false;
		}
		return $wfid;
   }

   static function get_post_import_workflow($filepath,$wfname)
   {
		global $wpdb;
		error_reporting(E_ALL);
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		date_default_timezone_set('Asia/ShangHai');
		
		require_once dirname(__File__).'/../Classes/PHPExcel/IOFactory.php';

		if (!file_exists(dirname(__File__).'/../Classes/ss.xlsx')) {
			return false;;
		}
		$objPHPExcel = PHPExcel_IOFactory::load($filepath);

		$sheet = $objPHPExcel->getSheet(0); 
		$highestRow = $sheet->getHighestRow(); 
		$highestColumm = $sheet->getHighestColumn(); 
		$colunmNum=PHPExcel_Cell::columnIndexFromString($highestColumm);
		$one=1;
		$two=2;
		
		$step_id=0;
		$wf_id=0;
		$step_table_name = FCUtility::get_workflow_steps_table_name();
		$row = $wpdb->get_row("SELECT max(ID) as maxid FROM $step_table_name");
		if($row)
			$step_id = $row->maxid ;
		else
			return false;
			
		$wf_table_name = FCUtility::get_workflows_table_name();

		$workflow='{"steps":{';
		for($icol=0;$icol<$colunmNum-2;$icol++)
		{
			$column= PHPExcel_Cell::stringFromColumnIndex($icol+2);
			$val1 = $sheet->getCell($column.$one)->getValue();
			$val2 = $sheet->getCell($column.$two)->getValue();
			if(strcmp($val2,'')!=0)
				$val2='<br>PIC:'.$val2;
			$workflow.='"step'.$icol.'":{"fc_addid":"step'.$icol.'","fc_label":"'.$val1.$val2.'","fc_dbid":"'.($step_id+$icol+1).'","fc_process":"assignment","fc_position":["'.($icol*10).'px","'.($icol*10).'px"]}';
			if($icol<$colunmNum-3)
			{
				$workflow.=",";
			}
			//$workflow.="<br/>";
		}
		$workflow.='},"conns":{';

		for ($row = 7; $row <= $highestRow; $row++){
			$create=0;
			$use=0;
			$source='"sourceId":"",';
			$target='"targetId":"",';
			for($icol=2;$icol<$colunmNum;$icol++)
			{
				$column= PHPExcel_Cell::stringFromColumnIndex($icol);
				$val = $sheet->getCell($column.$row)->getValue();
				if( strcmp($val,"Create")==0)
				{
					$source='"sourceId":"step'.($icol-2).'",';
					$create=$icol;
				}
				else if(strcmp($val,"Use")==0)
				{
					$target='"targetId":"step'.($icol-2).'",';
					$use=$icol;
				}
			}
			$color="blue";
			if($create>$use)
			{
				$color="red";
			}
			$workflow.='"'.($row-7).'":{'.$source.$target.'"connset":{"connector":"StateMachine","paintStyle":{"lineWidth":3,"strokeStyle":"'.$color.'"}}}';
			if($row < $highestRow)
				$workflow.=",";
				
			//$workflow.="<br/>";
		}
		$workflow.='},"first_step":["step0"]}';

		$additional_info = stripcslashes( 'a:2:{s:16:"wf_for_new_posts";i:1;s:20:"wf_for_revised_posts";i:1;}' );
		$data = array(
					'name' => $wfname,
					'description' => 'import workflow',
					'wf_info' => $workflow,
					'start_date' => date("Y-m-d", current_time('timestamp')),
					'end_date' => date("Y-m-d", current_time('timestamp') + YEAR_IN_SECONDS),
					'is_valid' => 1,
					'create_datetime' => current_time('mysql'),
		 			'update_datetime' => current_time('mysql'),
		 		   'wf_additional_info' => $additional_info
				);
		$result = $wpdb->insert($wf_table_name, $data);

		$wfrow = $wpdb->get_row("SELECT max(ID) as maxid FROM $wf_table_name");
		if($wfrow)
			$wf_id = $wfrow->maxid ;
		else
			return false;

		for($icol=0;$icol<$colunmNum-2;$icol++)
		{
			if($icol==0)
			{
				$review_step_info = '{"process":"review","step_name":"review","assignee":{"editor":"Editor"},"status":"pending","failure_status":"draft"}';
				$review_process_info = '{"assign_subject":"","assign_content":"","reminder_subject":"","reminder_content":""}';
				$result = $wpdb->insert(
					  $step_table_name,
					  array(
						 'step_info' => stripcslashes( $review_step_info ),
						 'process_info' => stripcslashes( $review_process_info ),
						 'create_datetime' => current_time('mysql'),
						 'update_datetime' => current_time('mysql'),
						 'workflow_id' => $wf_id
					 )
			   );
			}
			else if($icol==$colunmNum-3)
			{
				// step 3 - publish
				$publish_step_info = '{"process":"publish","step_name":"publish","assignee":{"administrator":"Administrator"},"status":"publish","failure_status":"draft"}';
				$publish_process_info = '{"assign_subject":"","assign_content":"","reminder_subject":"","reminder_content":""}';
				$result = $wpdb->insert(
							  $step_table_name,
							  array(
								 'step_info' => stripcslashes( $publish_step_info ),
								 'process_info' => stripcslashes( $publish_process_info ),
								 'create_datetime' => current_time('mysql'),
								 'update_datetime' => current_time('mysql'),
								 'workflow_id' => $wf_id
							 )
					   );
			}
			else
			{
				// step 2 - assignment
				$assignment_step_info = '{"process":"assignment","step_name":"assignment","assignee":{"author":"Author"},"status":"pending","failure_status":"draft"}';
				$assignment_process_info = '{"assign_subject":"","assign_content":"","reminder_subject":"","reminder_content":""}';
				$result = $wpdb->insert(
					  $step_table_name,
					  array(
						 'step_info' => stripcslashes( $assignment_step_info ),
						 'process_info' => stripcslashes( $assignment_process_info ),
						 'create_datetime' => current_time('mysql'),
						 'update_datetime' => current_time('mysql'),
						 'workflow_id' => $wf_id
					 )
			   );
			}
		}
		 
		return true;
   } 
}
?>