<?php
	if($_SESSION['file'])
	{
		$file = $_SESSION['file'];
		if(!file_exists($file->file_path))
		{
			echo "Can not find file";
			exit();
		}
		else
		{
			$f=fopen($file->file_path,"r");
			Header("Content-type:application/octet-stream");
			Header("Accept-Ranges:bytes");
			Header("Accept-Length:".filesize($file->file_path));
			Header("Content-Disposition:attachment;filename=".$file->file_name);
			echo fread($f,filesize($file->file_path));
			fclose($f);
			exit();
		}
	}
?>