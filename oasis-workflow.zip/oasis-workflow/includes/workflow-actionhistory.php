<?php
/*************************************/
/*     Workflow Action History              */
/*************************************/

class FCWorkflowActionHistory extends FCWorkflowBase
{  
	static function get_workflow_aciton_history()
	{   
	   global $wpdb;
	   $action_type = sanitize_text_field( $_POST["action_type"] );
	   $userId = get_current_user_id();
	   $userRole = FCWorkflowBase::get_current_user_role();
	   
		switch ($action_type)
		{
			case "All":
			   if(($userRole=="pm")||($userRole=="administrator"))
			   {
					$result = $wpdb->get_results( "SELECT action_1.ID,action_1.action_name,action_1.workflow_id,action_1.step_id,action_1.actor_id,action_1.action_status,action_1.action_description,action_1.object,action_1.create_datetime,users_1.user_login as actor_name FROM ".FCUtility::get_dnt_action_history_table_name()." action_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( action_1.actor_id = users_1.id )" );				
			   }
			   else
			   {
					$result = $wpdb->get_results( "SELECT action_1.ID,action_1.action_name,action_1.workflow_id,action_1.step_id,action_1.actor_id,action_1.action_status,action_1.action_description,action_1.object,action_1.create_datetime,users_1.user_login as actor_name FROM ".FCUtility::get_dnt_action_history_table_name()." action_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( action_1.actor_id = users_1.id ) WHERE action_1.actor_id=".$userId);
			   }

				echo json_encode($result) ;
				exit();
				break;
			case "Import":
				$actionName = "Import";
				break;
			case "Setup":
				$actionName = "Setup";
				break;
			case "FineTune":
				$actionName = "FineTune";
				break;
			case "SubmitOutput":
				$actionName = "SubmitOutput";
				break;
			case "Assignment":
				$actionName = "Assignment";
				break;
			case "Delay":
				$actionName = "Delay";
				break;
			case "Complete":
				$actionName= "Complete";
				break;			
		}
	   
	   if(($userRole=="pm")||($userRole=="administrator"))
	   {
			$result = $wpdb->get_results( "SELECT action_1.ID,action_1.action_name,action_1.workflow_id,action_1.step_id,action_1.actor_id,action_1.action_status,action_1.action_description,action_1.object,action_1.create_datetime,users_1.user_login as actor_name FROM ".FCUtility::get_dnt_action_history_table_name()." action_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( action_1.actor_id = users_1.id ) WHERE action_1.action_name ='".$actionName."'" );
	   }
	   else
	   {
			$result = $wpdb->get_results( "SELECT action_1.ID,action_1.action_name,action_1.workflow_id,action_1.step_id,action_1.actor_id,action_1.action_status,action_1.action_description,action_1.object,action_1.create_datetime,users_1.user_login as actor_name FROM ".FCUtility::get_dnt_action_history_table_name()." action_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( action_1.actor_id = users_1.id ) WHERE action_1. action_name ='".$actionName."' and action_1.actor_id=".$userId);
	   }

	    echo json_encode($result) ;
	   //return $result;
	   exit();
	}
	
	static function get_workflow_aciton_type()
	{
		$action_types = array("Import","Setup","FineTune","SubmitOutput","Assignment","Delay","Complete");
		return $action_types;
	}
	
}


?>