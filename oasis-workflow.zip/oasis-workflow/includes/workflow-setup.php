<?php
/*************************************/
/*     Workflow Setup              */
/*************************************/

class FCWorkflowSetup extends FCWorkflowBase
{
    //******* sql server funcion api**********//
	/*static function connect_sql_server()
	{
	   $serverName = "tcloud,4902";
	   $connectionInfo = array("Database"=>"SmartWorkFlowDB", "UID"=>"infocloud", "PWD"=>"123456");
	   $conn = sqlsrv_connect($serverName, $connectionInfo);
	   return $conn;
	}
	static function get_selected_workflow()
	{   
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	     
	   $conn =FCWorkflowSetup::connect_sql_server();	   
	   $sql = "SELECT * FROM Workflow where ID=".$id;
	   $query = sqlsrv_query($conn,$sql);
	   
	   $workflow=sqlsrv_fetch_object($query);
	   
	   sqlsrv_close($conn);
	   echo json_encode($workflow) ;
	   exit();
	}
	
	static function get_process_list_in_workflow()
	{   
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	   
	   $conn =FCWorkflowSetup::connect_sql_server();   
	   //$sql = "SELECT *,SystemUser.GroupName FROM Process INNER JOIN SystemUser On Process.Assignee = SystemUser.Assignee where WorkflowID=".$id;
	   $sql = "SELECT * FROM Process where WorkflowID=".$id;
	   $query = sqlsrv_query($conn,$sql);
	   
	   $processObjects =array();
	   while($rows=sqlsrv_fetch_object($query))
	   {
		  $processObjects[] = $rows;  
	   }
	   sqlsrv_close($conn);
	   echo json_encode($processObjects);
	   exit();
	}
	
	static function get_group_by_user()
	{   
	   $userName = sanitize_text_field( $_POST["username"] );
	  
	   $conn =FCWorkflowSetup::connect_sql_server();   
	   $sql = "SELECT * FROM SystemUser where Name = '$userName'";
	   $query = sqlsrv_query($conn,$sql);
	   
	   $groupObjects =array();
	   while($rows= sqlsrv_fetch_object($query))
	   {
			$groupObjects[] = $rows; 
	   }

	   sqlsrv_close($conn);
	   echo json_encode($groupObjects);
	   exit();
	}
	
	static function get_first_process()
	{   
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	   
	   $conn =FCWorkflowSetup::connect_sql_server();   
	   $sql = "SELECT * FROM Process where IsFirstStep='Yes' and WorkflowID=".$id;
	   $query = sqlsrv_query($conn,$sql);
	   
	   $processObjects =array();
	   while($rows=sqlsrv_fetch_object($query))
	   {
		  $processObjects[] = $rows;  
	   }
	   sqlsrv_close($conn);
	   echo json_encode($processObjects);
	   exit();
	}
	
	static function get_groups_in_workflow()
	{   
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	   
	   $conn =FCWorkflowSetup::connect_sql_server();   
	   $sql = "SELECT distinct GroupName FROM Process where WorkflowID= ".$id;
	   $query = sqlsrv_query($conn,$sql);
	   
	   $groups = array();
	   while($rows=sqlsrv_fetch_object($query))
	   {
		  $groups[] = $rows;  
	   }   
	   sqlsrv_close($conn);
	   echo json_encode($groups);
	   exit();
	}
	
	
	
	static function get_users_by_group()
	{   
	   $groupname = sanitize_text_field( $_POST["groupname"] );
	   
	   $conn =FCWorkflowSetup::connect_sql_server();
	   $sql = "SELECT * FROM SystemUser where GroupName = '$groupname'";
	   $query = sqlsrv_query($conn,$sql);
	   
	   $userObjects =array();
	   while($rows= sqlsrv_fetch_object($query))
	   {
			$userObjects[] = $rows; 
	   }

	   sqlsrv_close($conn);
	   echo json_encode($userObjects);
	   exit();
	}
	
	static function submit_workflow_setup()
	{   
	   $groupname = sanitize_text_field( $_POST["groupname"] );
	   
	   $conn =FCWorkflowSetup::connect_sql_server();
	   $sql = "SELECT * FROM SystemUser where GroupName = '$groupname'";
	   $query = sqlsrv_query($conn,$sql);
	   
	   $userObjects =array();
	   while($rows= sqlsrv_fetch_object($query))
	   {
			$userObjects[] = $rows; 
	   }

	   sqlsrv_close($conn);
	   echo json_encode($userObjects);
	   exit();
	}
	
	
	static function get_table_header()
	{
		$sortby = ( isset($_GET['order']) && sanitize_text_field( $_GET["order"] ) == "desc" ) ? "asc" : "desc" ;
		
      // sorting the inbox page via Author, Due Date, Post title and Post Type
      $author_class = $workflow_class = $due_date_class = $post_order_class = $post_type_class = '';
      if( isset($_GET['orderby']) && isset($_GET['order']) ) {
      	$orderby = sanitize_text_field( $_GET['orderby'] );
         switch ($orderby) {
	         case 'author':
	            $author_class = $sortby;
	            break;
	         case 'due_date':
	            $due_date_class = $sortby;
	            break;
	         case 'post_title':
	         	$post_order_class = $sortby;
	         	break;
	         case 'post_type':
	         	$post_order_class = $sortby;
	         	break;	         	
	      }
      }
				
		echo "<tr>";
		//echo "<th scope='col' class='manage-column check-column' ><input type='checkbox'></th>";
		echo "<th width='300px' scope='col' class='sorted $post_order_class'>
				<a href='admin.php?page=oasiswf-workflowsetup&orderby=post_title&order=$sortby" . "'>
					<span>". __("Process Name", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
				</a>				
				</th>";
		echo "<th scope='col' class='sorted $post_type_class'>
		<a href='admin.php?page=oasiswf-workflowsetup&orderby=post_type&order=$sortby" . "'>
					<span>" . __("Process ID", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";		
		echo "<th scope='col' class='sorted $author_class'>
			<a href='admin.php?page=oasiswf-workflowsetup&orderby=post_author&order=$sortby" . "'>
					<span>" . __("Group Name", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "<th scope='col' class='sorted $author_class'>
			<a href='admin.php?page=oasiswf-workflowsetup&orderby=post_author&order=$sortby" . "'>
					<span>" . __("Assignee", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "<th scope='col' class='sorted $due_date_class'>
			<a href='admin.php?oasiswf-workflowsetup&orderby=due_date&order=$sortby" . "'>
					<span>" .  __("Plan Effort", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";	
		echo "<th scope='col' class='sorted $due_date_class'>
			<a href='admin.php?page=oasiswf-workflowsetup&orderby=due_date&order=$sortby" . "'>
					<span>" .  __("Plan Start Date", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "<th scope='col' class='sorted $due_date_class'>
			<a href='admin.php?page=oasiswf-workflowsetup&orderby=due_date&order=$sortby" . "'>
					<span>" .  __("Plan End Date", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "</tr>";
	}*/
	
   //******* mysql funcion api**********//
   
    static function get_workflow_dropdownlist()
	{     
	   global $wpdb;
	   $result = $wpdb->get_results( "SELECT * FROM " . FCUtility::get_dnt_workflowscheme_table_name() . " ORDER BY name desc" );

	   return $result;
	}
    
	static function get_selected_workflow()
	{   
	   global $wpdb;
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));  
	   $result = $wpdb->get_results( "SELECT * FROM " . FCUtility::get_dnt_workflowscheme_table_name() . " where ID =".$id);
	   echo json_encode($result) ;
	   exit();
	}
	
	static function get_process_list_in_workflow()
	{   
	   global $wpdb;
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	   $result = $wpdb->get_results( "SELECT * FROM " . FCUtility::get_dnt_workflow_stepsScheme_table_name() . " where WorkflowSchemeID =".$id);
	   /*$result = $wpdb->get_results( "SELECT process_1.ID,process_1.Name,process_1.WorkflowID,process_1.PlanStartDate,process_1.PlanEffort,process_1.ActualStartDate,process_1.CommitDate,process_1.GroupName,process_1.AssigneeID,process_1.Status,process_1.IsFirstStep,process_1.Input,process_1.Output,users_1.display_name FROM ".FCUtility::get_dnt_workflow_steps_table_name()." process_1
   				INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id )
   				WHERE process_1. WorkflowID =".$id );	*/
	   echo json_encode($result);
	   exit();
	}
	
	static function get_process_connections()
	{   
	   global $wpdb;
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	   $result = $wpdb->get_results( "SELECT * FROM " . FCUtility::get_dnt_workflow_edgeScheme_table_name() . " where WorkflowSchemeID =".$id);
	   echo json_encode($result);
	   exit();
	}
	
	// DNT - MAR,9 2016 NK
	static function getCriticalPath_in_workflow()
	{
		global $wpdb;
	    $id = intval( sanitize_text_field( $_POST["workflowid"] ));
		$result = FCWorkflowBase::getCriticalPath($id);
		echo $result;
	    //echo json_encode($result);
	    exit();
	}
	
	static function get_group_by_user()
	{   
	   $userName = sanitize_text_field( $_POST["username"] );
	   
	   $conn =FCWorkflowSetup::connect_sql_server();   
	   $sql = "SELECT * FROM SystemUser where Name = '$userName'";
	   $query = sqlsrv_query($conn,$sql);
	   
	   $groupObjects =array();
	   while($rows= sqlsrv_fetch_object($query))
	   {
			$groupObjects[] = $rows; 
	   }

	   sqlsrv_close($conn);
	   echo json_encode($groupObjects);
	   exit();
	}
	
	static function get_first_process()
	{   
	   global $wpdb;
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	   $result = $wpdb->get_results( "SELECT * FROM " . FCUtility::get_dnt_workflow_stepsScheme_table_name() . " where IsFirstStep='Yes' and WorkflowSchemeID =".$id);    
	   echo json_encode($result);
	   exit();
	}
	
	static function get_groups_in_workflow()
	{   
	   global $wpdb;
	   $id = intval( sanitize_text_field( $_POST["workflowid"] ));
	   $result = $wpdb->get_results( "SELECT distinct GroupName FROM " . FCUtility::get_dnt_workflow_stepsScheme_table_name() . " where WorkflowSchemeID =".$id);  
	   echo json_encode($result);
	   exit();
	}
	
	
	
	static function get_users_by_group()
	{   
	   global $wpdb;
	   $groupname = sanitize_text_field( $_POST["groupname"] );
	   $groupname = '%' . $groupname . '%';
       $users = $wpdb->get_results( $wpdb->prepare( "SELECT users_1.ID, users_1.user_login FROM {$wpdb->base_prefix}users users_1
   				INNER JOIN {$wpdb->base_prefix}usermeta usermeta_1 ON ( users_1.ID = usermeta_1.user_id )
   				WHERE (usermeta_1.meta_key = '{$wpdb->prefix}capabilities' AND CAST( usermeta_1.meta_value AS CHAR ) LIKE %s)", $groupname ) );
	   echo json_encode($users);
	   exit();
	}
	
	static function get_workflow_effort_by_criticalpath()
    {
		global $wpdb;
	    $id = intval( sanitize_text_field( $_POST["workflowid"] ));
		$result = FCWorkflowBase::getCriticalPathEffort($id);
		echo $result;
	    exit();
	} 


	
	static function save_workflow_setup()
	{   
		global $wpdb;
		$workflowobject = $_POST["workflow"];
		$processes = $_POST["processes"];
		$workflow_table = FCUtility::get_dnt_workflows_table_name();
		$data=array(
				'Name'=>$workflowobject["name"],
				'SetupDate'=>$workflowobject["setup_date"],
				'PlanStartDate' => $workflowobject["plan_start_date"],
				'PlanEffort' => $workflowobject["plan_effort"],
				'ActualStartDate' => $workflowobject["plan_start_date"],
				'WorkflowSchemeID' => $workflowobject["ID"],
				'Status' => $workflowobject["status"]
		);
		$result = $wpdb->insert($workflow_table, $data);
		if($result)
			$wfrow = $wpdb->get_row("SELECT max(ID) as maxid FROM $workflow_table");
		else
			return false;
			
		if($wfrow)
			$workflowid = $wfrow->maxid ;
		else
			return false;
		
		$conn = mysql_connect('localhost','root','root') or die ("connect fails");
		mysql_select_db('db_wordpress',$conn);	
		mysql_query("CREATE EVENT `workflow_setup_event` ON SCHEDULE AT '".$workflowobject["plan_start_date"]."' ON COMPLETION PRESERVE ENABLE DO UPDATE ".$workflow_table ." set status = 'green' where ID ='".$workflowid."'");
		
		$process_table = FCUtility::get_dnt_workflow_steps_table_name();
		$workflowUser_table = FCUtility::get_dnt_workflow_StakeHolder_table_name(); 
		$mapArr=array();
		$useridArray = array();
		foreach($processes as $process)
		{
			$data=array(
				'Name'=>$process["name"],
				'AssigneeID'=>$process["assignee"],
				'WorkflowID' => $workflowid,
				'PlanEffort' => $process["plan_effort"],
				'PlanStartDate' => $process["plan_start_date"],
				'ActualStartDate' => $process["plan_start_date"],
				'CommitDate' => $process["plan_end_date"],
				'GroupName' => $process["groupName"],
				'Status' => $process["status"],
				'IsFirstStep' => $process["isfirst"]
			);
			$userid = $process["assignee"];
			
			if(in_array($userid,$useridArray))
			{
			}
			else
			{
				if($userid==wp_get_current_user()->ID)
				{
					array_push($useridArray,$userid);
					$pminfo_data=array(
						'WorkflowID' => $workflowid,
						'Participant'=>$userid,
						'GroupName' => $process["groupName"],
						'IsPM'=>'Yes',
						'IsDelegatePM'=>'No',
						'IsGroupLeader'=>'Yes',
					);
					$result_pminfo = $wpdb->insert($workflowUser_table, $pminfo_data);	
				}
				else
				{
					array_push($useridArray,$userid);
					$userinfo_data=array(
						'WorkflowID' => $workflowid,
						'Participant'=>$userid,
						'GroupName' => $process["groupName"],
						'IsPM'=>'No',
						'IsDelegatePM'=>'No',
						'IsGroupLeader'=>'Yes',
					);
					$result_userinfo = $wpdb->insert($workflowUser_table, $userinfo_data);
				}
			}
			
			
			$result = $wpdb->insert($process_table, $data);
			if($result)
			{
				$wfrow = $wpdb->get_row("SELECT max(ID) as maxid FROM $process_table");
			}
			else
			{
				return false;
			}
			
			if($wfrow){
				$new_process_id = $wfrow->maxid ;
				$key = $process["ID"];
				$mapArr[$key]=$new_process_id;
			}
			else
			{
				return false;
			}
			
		}
		
		$processesConn = $_POST["processCnn"];
		$processConn_table = FCUtility::get_dnt_workflow_edge_table_name();
		foreach($processesConn as $conn)
		{
			$data=array(
				'WorkflowID' => $workflowid,
				'CreateProcessID' => $mapArr[$conn["CreateProcessID"]],
				'UseProcessID' => $mapArr[$conn["UseProcessID"]],
				'Carrier' => $conn["Discription"]
			);
			$result = $wpdb->insert($processConn_table, $data);
			if($result)
				$wfrow = $wpdb->get_row("SELECT max(ID) as maxid FROM $processConn_table");
			else
				return false;
		}
		
		$result = FCWorkflowBase::save_action_to_mysql("Setup","","",$mapArr);//add by huyq
		 
	   echo $result;
	   exit();
	}
	
	
	static function get_table_header()
	{
		$sortby = ( isset($_GET['order']) && sanitize_text_field( $_GET["order"] ) == "desc" ) ? "asc" : "desc" ;
		
      // sorting the inbox page via Author, Due Date, Post title and Post Type
      $author_class = $workflow_class = $due_date_class = $post_order_class = $post_type_class = '';
      if( isset($_GET['orderby']) && isset($_GET['order']) ) {
      	$orderby = sanitize_text_field( $_GET['orderby'] );
         switch ($orderby) {
	         case 'author':
	            $author_class = $sortby;
	            break;
	         case 'due_date':
	            $due_date_class = $sortby;
	            break;
	         case 'post_title':
	         	$post_order_class = $sortby;
	         	break;
	         case 'post_type':
	         	$post_order_class = $sortby;
	         	break;	         	
	      }
      }
				
		echo "<tr>";
		//echo "<th scope='col' class='manage-column check-column' ><input type='checkbox'></th>";
		echo "<th width='300px' scope='col' class='sorted $post_order_class'>
				<a href='admin.php?page=oasiswf-workflowsetup&orderby=post_title&order=$sortby" . "'>
					<span>". __("Process Name", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
				</a>				
				</th>";
		 echo "<th scope='col' class='sorted $post_type_class'>
		<a href='admin.php?page=oasiswf-workflowsetup&orderby=post_type&order=$sortby" . "'>
					<span>" . __("Process ID", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";	
		echo "<th scope='col' class='sorted $author_class'>
			<a href='admin.php?page=oasiswf-workflowsetup&orderby=post_author&order=$sortby" . "'>
					<span>" . __("Group Name", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "<th scope='col' class='sorted $author_class'>
			<a href='admin.php?page=oasiswf-workflowsetup&orderby=post_author&order=$sortby" . "'>
					<span>" . __("Assignee", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "<th scope='col' class='sorted $due_date_class'>
			<a href='admin.php?oasiswf-workflowsetup&orderby=due_date&order=$sortby" . "'>
					<span>" .  __("Plan Effort", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";	
		echo "<th scope='col' class='sorted $due_date_class'>
			<a href='admin.php?page=oasiswf-workflowsetup&orderby=due_date&order=$sortby" . "'>
					<span>" .  __("Plan Start Date", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "<th scope='col' class='sorted $due_date_class'>
			<a href='admin.php?page=oasiswf-workflowsetup&orderby=due_date&order=$sortby" . "'>
					<span>" .  __("Plan End Date", "oasisworkflow") . "</span>
					<span class='sorting-indicator'></span>
			</a>
			</th>";
		echo "</tr>";
	}
	
}


?>