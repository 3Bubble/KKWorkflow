<?php
global $wp_roles, $wpdb ;
$process_info = "";
$step_info = "";
$step_dbid = "";
$step_gpid = "";
$users="";//add by huyq
if( isset($_POST['step_gpid']) && sanitize_text_field( $_POST["step_gpid"] )) {
	$step_gpid = sanitize_text_field( $_POST["step_gpid"] );
	$users = $wpdb->get_results($wpdb->prepare("SELECT user_login From wp_tableusers",null));//add by huyq
}
if( isset($_POST['step_dbid']) && sanitize_text_field( $_POST["step_dbid"] ) != "nodefine" )
{
   $step_dbid = sanitize_text_field( $_POST["step_dbid"] );
	$step_row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . FCUtility::get_workflow_steps_table_name() . " WHERE ID = %d" , $step_dbid ) );
	$users = $wpdb->get_results($wpdb->prepare("SELECT user_login From wp_tableusers",null));//add by huyq
	$step_info = json_decode($step_row->step_info);
	$process_info = json_decode($step_row->process_info);
}
?>

<script type='text/javascript'>
	//added by HJ
	jQuery( "#process-start-date" ).datepicker({
		autoSize: true,
		dateFormat: owf_workflow_step_info_vars.editDateFormat,			
		onSelect: function(dateText, inst) {
			jQuery(this).css("background-color", "white");
		}
	});
	
	jQuery( "#process-end-date" ).datepicker({
		autoSize: true,
		dateFormat: owf_workflow_step_info_vars.editDateFormat,			
		onSelect: function(dateText, inst) {
			jQuery(this).css("background-color", "white");		
		}
	});
	
	jQuery(".date-clear").click(function(){
			jQuery(this).parent().children(".date_input").val("");
			return false;
	});
	//end add
</script>

<div id="step-setting">
	<div class="dialog-title"><strong><?php echo __("Step Information", "oasisworkflow");?></strong></div>
	<div id="step-setting-content" style="overflow:auto;" >
		<p class="step-name">
			<label><?php echo __("Step Name :", "oasisworkflow")?> </label><input type="text" id="step-name" name="step-name" /></span>
		</p>
		<div class="step-assignee" style="height:120px;">
			<div style="margin-left:0px;">
				<label><?php echo __("Assignee(s) :", "oasisworkflow") ;?> </label>
			</div>
			<div class="step-assignee-list" >
				<label><?php echo __("Available", "oasisworkflow"); ?></label><br class="clear">
				<p>
					<select id="step-role-list" name="step-role-list" size=10>
						<?php
						//FCUtility::owf_dropdown_roles_multi();//comment by huyq
						
						foreach ($users as $user) {
							echo "<option value='".esc_attr( $user->user_login )."'>$user->user_login</option>" ;
						}
						//echo "<option value='owfpostauthor'>";//comment by huyq
						//echo __("Post Author", "oasisworkflow") ;
						//echo "</option>";
						?>
					</select>
				</p>
			</div>
			<div class="step-assignee-point">
				<a href="#" id="step-assignee-set-point"><img src="<?php echo OASISWF_URL . "img/role-set.png";?>" style="border:0px;" /></a><br>
				<a href="#" id="step-assignee-unset-point"><img src="<?php echo OASISWF_URL . "img/role-unset.png";?>" style="border:0px;" /></a>
			</div>
			<div class="step-assignee-list">
				<label><?php echo __("Assigned", "oasisworkflow") ;?></label><br class="clear">
				<p>
					<select id="step-role-set-list" name="step-role-set-list" size=10>
						<?php
						if( is_object( $step_info ) && $step_info->assignee ){
							foreach ( $step_info->assignee as $role => $name ) {
								echo "<option value='".esc_attr( $role )."'>$name</option>";
							}
						}
						?>
					</select>
				</p>
			</div>
		</div>
		<br class="clear">
		<p class="step-status">
			<label><?php echo __("Status :", "oasisworkflow") ;?></label>
			<div style="float:left;margin-top:-15px;">
				<div style="float:left;text-align:center;">
					<label><?php echo __("On Success", "oasisworkflow"); ?></label><br><br>
					<?php
					if (isset($_POST['process_name']) && $_POST['process_name'] != "publish")
					{
					?>
   					<select id="step-status-select" style="width:150px;margin-top:-5px;">
   						<option value=""></option>
   						<?php
   						foreach ( get_post_stati(array('show_in_admin_status_list' => true)) as $status ) {
   							$chk = "" ;
   							if( is_object( $step_info ) && ($status == $step_info->status) ){
   								$chk = "selected" ;
   							}
   							echo "<option value='".esc_attr( $status )."' $chk>{$status}</option>" ;
   						}
   						?>
   					</select>
   				<?php
					}
   				else // if step is publish, then success step has to be "publish"
   				{
   				?>
						<div id="step_status_publish">publish</div>
					<?php
   				}
					?>
				</div>
				<div style="float:left;margin-left:50px;text-align:center;">
					<label><?php echo __("On Failure", "oasisworkflow"); ?></label><br><br>
					<select id="step-failure-status-select" style="width:150px;margin-top:-5px;">
						<option value=""></option>
						<?php
						foreach ( get_post_stati(array('show_in_admin_status_list' => true)) as $status ) {
							$chk = "" ;
							if( is_object( $step_info ) && ($status == $step_info->failure_status )){
								$chk = "selected" ;
							}
							echo "<option value='".esc_attr( $status )."' $chk>{$status}</option>" ;
						}
						?>
					</select>
				</div>
			</div>
			<br class="clear">
		</p>
		<div class="step-review" style="display:none;">
			<div class="step-review-lb">
				<label><?php echo __("Review Decision : ", "oasisworkflow") ;?></label>
			</div>
			<div class="step-review-chk">
				<?php
					$oasiswf_review_decision = get_site_option( "oasiswf_review" ) ;
					if( $oasiswf_review_decision ) {
						$stl = "style='margin-top:5px;'" ;
						foreach ( $oasiswf_review_decision as $k => $v ) {
							//$chk = "" ;
							//$chk = ($step_info->decision == $k) ? "checked=true" : "" ;
							$chk = ("everyone" == $k) ? "checked=true" : "" ;
							echo "<div $stl><input type='radio' id='rdo-{$k}' name='review-opt' value='{$k}' ".checked( 'everyone', $k )." /> $v</div>" ;
							$stl = "";
						}
					}
				?>
			</div>
			<br class="clear">
		</div>
		
		<!--added by HJ at 01/27/2016--start-->
		<p class="step-status" style="margin-top:25px;">
			<label><?php echo __("Schedule :", "oasisworkflow") ;?></label>
			<div style="float:left;margin-top:-15px;">
				<div style="float:left;text-align:left;">
					<label>
						<?php echo  __("Start Date :", "oasisworkflow");?>
						<span class="required-color">*</span>
						<a href="#" title="<?php echo __('Specify a date from which this process will become available for use.', "oasisworkflow") ;?>" class=	"tooltip">
							<span title="">
							<img src="<?php echo OASISWF_URL . '/img/help.png'; ?>" class="help-icon"/></span>
						</a>
						</label><br>
						<div style="width:220px;margin-top:10px;">
						<input class="date_input" id="process-start-date" name="process-start-date" type="text" real="publish-date-loading-span" readonly value="<?php echo esc_attr( $process_info->plan_start_date ); ?>"/>
						<button class="date-clear"><?php echo __("clear", "oasisworkflow") ;?></button>
					</div>
				</div>
				<div style="float:left;text-align:left;">
					<label>
						<?php echo  __("End Date :", "oasisworkflow");?>
						<span class="required-color">*</span>
						 <a href="#" title="<?php echo __('End date is not required. If not specified, the process is valid for ever. Specify an end date, if you want to retire the process.', "oasisworkflow") ;?>" class="tooltip">
							<span title="">
							<img src="<?php echo OASISWF_URL . '/img/help.png'; ?>" class="help-icon"/></span>
						</a>
					</label><br>
					<div style="width:220px;margin-top:10px;">
						<input class="date_input" id="process-end-date" name="process-end-date" type="text" real="publish-date-loading-span" readonly value="<?php echo esc_attr( $process_info->plan_end_date ); ?>"/>
						<button class="date-clear"><?php echo __("clear", "oasisworkflow") ;?></button>
					</div>
				</div>
			</div>
			<br class="clear">
		</p>
		<!--added by HJ at 01/27/2016--end-->
		
		<div class="first_step" >
			<label><?php echo __("Is first step? : ", "oasisworkflow") ;?></label>
			<span><input type="checkbox" id="first_step_check" /></span>
			<br class="clear">
		</div>
		<a href="#" class="more-show" id="more-show" style="color:blue;"><?php echo __("Advanced details", "oasisworkflow");?></a>
		<form>
			<div id="wf-email-define" style="display:none;margin-top:40px;">
				<h3 style="margin:10px 0 20px 0;"><?php echo __("Assignment Email", "oasisworkflow") ;?></h3>
				<div>
					<div style="float:left;width:130px;"><label><?php echo __("Placeholder : ", "oasisworkflow") ;?></label></div>
					<div style="float:left;">
						<select id="assign-placeholder" style="width:150px;">
							<option value=""><?php echo __("--Select--", "oasisworkflow") ;?></option>
							<?php
							$placeholders = get_site_option( "oasiswf_placeholders" ) ;
							if( $placeholders ){
								foreach ($placeholders as $k => $v ) {
									echo "<option value='". esc_attr( $k )."'>{$v}</option>" ;
								}
							}
							?>
						</select>
						<input type="button" id="addPlaceholderAssignmentSubj" class="button-primary placeholder-add-bt" value="<?php echo __("Add to subject", "oasisworkflow") ;?>" style="margin-left:20px;" />
						<input type="button" id="addPlaceholderAssignmentMsg" class="button-primary placeholder-add-bt" value="<?php echo __("Add to message", "oasisworkflow") ;?>" style="margin-left:20px;" />
					</div>
					<br class="clear">
				</div>
				<p>
					<label ><?php echo __("Email subject : ", "oasisworkflow") ;?></label>
					<?php
					$assignment_subject = "";
					$assignment_content = "";
					$reminder_subject = "";
					$reminder_content = "";
					if (is_object($process_info) )
					{
					   $assignment_subject = $process_info->assign_subject;
					   $assignment_content = $process_info->assign_content;
					   $reminder_subject = $process_info->reminder_subject;
					   $reminder_content = $process_info->reminder_content;
					}
					?>
					<input type="text" id="assignment-email-subject" name="assignment-email-subject" value="<?php echo esc_attr( $assignment_subject );?>" />
				</p>
				<div style="width:100%;height:250px;">
					<div style="float:left;"><label><?php echo __("Email message : ", "oasisworkflow") ;?></label></div>
					<div style="float:left;" id="assignment-email-content-div">
						<textarea id="assignment-email-content" name="assignment-email-content"
							style="width:500px;height:200px;"><?php echo esc_textarea($assignment_content);?></textarea>
					</div>
					<br class="clear">
				</div>
				<br class="clear">
				<div style="margin:30px 0 20px 0;">
					<h3><?php echo __("Reminder Email", "oasisworkflow") ;?></h3>
				</div>
				<div>
					<div style="float:left;width:130px;"><label><?php echo __("Placeholder : ", "oasisworkflow") ;?></label></div>
					<div style="float:left;">
						<select id="reminder-placeholder" style="width:150px;">
							<option value=""><?php echo __("--Select--", "oasisworkflow") ;?></option>
							<?php
							$placeholders = get_site_option( "oasiswf_placeholders" ) ;
							if( $placeholders ){
								foreach ($placeholders as $k => $v ) {
									echo "<option value='".esc_attr( $k )."'>{$v}</option>" ;
								}
							}
							?>
						</select>
						<input type="button" id="addPlaceholderReminderSubj" class="button-primary placeholder-add-bt" value="<?php echo __("Add to subject", "oasisworkflow") ;?>" style="margin-left:20px;" />
						<input type="button" id="addPlaceholderReminderMsg" class="button-primary placeholder-add-bt" value="<?php echo __("Add to message", "oasisworkflow") ;?>" style="margin-left:20px;" />
					</div>
					<br class="clear">
				</div>
				<p>
					<label><?php echo __("Email subject : ", "oasisworkflow") ;?></label>
					<input type="text" id="reminder-email-subject" name="reminder-email-subject" value="<?php echo esc_attr( $reminder_subject );?>" />
				</p>
				<div style="width:100%;height:250px;">
					<div style="float:left;"><label><?php echo __("Email message : ", "oasisworkflow") ;?></label></div>
					<div style="float:left;">
						<textarea id="reminder-email-content" name="reminder-email-content"
							style="width:500px;height:200px;"><?php echo esc_textarea($reminder_content); ?></textarea>
					</div>
					<br class="clear">
				</div>
			</div>
		</form>
		<br class="clear">
		<input type="hidden" id="step_gpid-hi" value="<?php echo esc_attr( $step_gpid ); ?>" />
		<input type="hidden" id="step_dbid-hi" value="<?php echo esc_attr( $step_dbid ); ?>" />
	</div>
	<div class="dialog-title" style="padding-bottom:0.5em"></div>
	<br class="clear">
	<p class="step-set">
		<input type="button" id="stepSave" class="button-primary" value="<?php echo __("Save", "oasisworkflow") ;?>"  />
		<span>&nbsp;</span>
		<a href="#" id="stepCancel" style="color:blue;margin-top:5px;"><?php echo __("Cancel", "oasisworkflow") ;?></a>
	</p>
	<br class="clear">
</div>