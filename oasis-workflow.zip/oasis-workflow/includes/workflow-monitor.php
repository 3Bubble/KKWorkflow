<?php
/*************************************/
/*     Workflow Monitor Tool         */
/*************************************/

class FCWorkflowMonitor extends FCWorkflowBase
{
   //******* mysql funcion api**********//
   
     static function get_allStatus_workflow_dropdownlist()
	{     
	   global $wpdb;
	   $workflowTable = FCUtility::get_dnt_workflows_table_name();
	   $stakeholderTable = FCUtility::get_dnt_workflow_StakeHolder_table_name() ;
	   $userid = wp_get_current_user()->ID;
	   $result = $wpdb->get_results( "SELECT * FROM  ".$stakeholderTable." inner join ".$workflowTable." on ".$workflowTable.".ID = ".$stakeholderTable.".workflowid where Status!='black' and Participant = ".$userid." ORDER BY name desc" );
	   return $result;
	}
	static function get_allTaskStatus_workflow()
	{
		global $wpdb;
	   $result = $wpdb->get_results( "SELECT  ID,Name,AssigneeID,Status,PlanEffort FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " ORDER BY name desc" );
	   return $result;
	}
	
	static function get_allusers_dropdownlist_by_allworkflow()
	{   
	   global $wpdb;	
		$result = $wpdb->get_results( "SELECT distinct users_1.ID,users_1.user_login FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) Where process_1.PlanEFfort!=0"); 
		return $result;
	}
   
    static function get_workflow_dropdownlist_by_status()
	{     
	   global $wpdb;
	   $workflowStatus = sanitize_text_field( $_POST["workflowstatus"] );
	   switch($workflowStatus)
	   {
			case "All":
				$result = $wpdb->get_results( "SELECT  ID,Name FROM " . FCUtility::get_dnt_workflows_table_name() . " ORDER BY name desc" );
				break;
			case "Gray":
				$result = $wpdb->get_results( "SELECT ID,Name FROM " . FCUtility::get_dnt_workflows_table_name() . " where Status='Gray' ORDER BY name desc" );
				break;
			case "Green":
				$result = $wpdb->get_results( "SELECT ID,Name FROM " . FCUtility::get_dnt_workflows_table_name() . " where Status='Green' ORDER BY name desc" );
				break;
			case "Red":
				$result = $wpdb->get_results( "SELECT ID,Name FROM " . FCUtility::get_dnt_workflows_table_name() . " where Status='Red' ORDER BY name desc" );
				break;
			case "Black":
				$result = $wpdb->get_results( "SELECT ID,Name FROM " . FCUtility::get_dnt_workflows_table_name() . " where Status='Black' ORDER BY name desc" );
				break;		
	   }
	   echo json_encode($result) ;
	   exit();
	}
	
	static function get_user_dropdownlist_by_workflow()
	{   
	   global $wpdb;
	   $id =sanitize_text_field( $_POST["workflowid"] );
	   $workflowstatus = sanitize_text_field( $_POST["worflowstatus"] );
	   if($workflowstatus=="All")
	   {
			$result = $wpdb->get_results( "SELECT distinct users_1.ID,users_1.user_login FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) Where process_1.PlanEFfort!=0"); 
	   }
	   else
	   {
		   if($id=="All")
		   {
				$result = $wpdb->get_results( "SELECT distinct users_1.ID,users_1.user_login FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) INNER JOIN ". FCUtility::get_dnt_workflows_table_name() ." worflow_1 ON(process_1.WorkflowID=worflow_1.ID) Where worflow_1.Status='$workflowstatus' and process_1.PlanEFfort!=0"); 
		   }
		   else
		   {
			   $id = intval( $id);
			   $result = $wpdb->get_results( "SELECT distinct users_1.ID,users_1.user_login FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) INNER JOIN ". FCUtility::get_dnt_workflows_table_name() ." worflow_1 ON(process_1.WorkflowID=worflow_1.ID) Where process_1.WorkflowID =".$id." AND worflow_1.Status='$workflowstatus' and process_1.PlanEFfort!=0"); 
			}	
		}		
	   echo json_encode($result);
	   exit();
	}
	
	
	static function get_monitor_datas_by_filters_workflow()
	{   
	   global $wpdb;
	   $workflowstatus =  sanitize_text_field( $_POST["worflowstatus"] );
	   $workflowid = sanitize_text_field( $_POST["workflowid"] );
	   $userid =  sanitize_text_field( $_POST["userid"] );
	   if($workflowstatus=="All")
	   {
			if($workflowid=="All")
			{
				if($userid=="All")
				{
					$result = $wpdb->get_results( "SELECT process_1.ID,process_1.Name,process_1.WorkflowID,process_1.PlanStartDate,process_1.PlanEffort,process_1.ActualStartDate,process_1.CommitDate,process_1.GroupName,process_1.AssigneeID,process_1.Status,process_1.IsFirstStep,process_1.Input,process_1.Output, users_1.ID,users_1.user_login, workflow_1.Name as wfName FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) INNER JOIN ". FCUtility::get_dnt_workflows_table_name() . " workflow_1 ON process_1.WorkFlowID = workflow_1.id WHERE process_1.PlanEFfort!=0"); 
				}
				else
				{
					$userid = intval( $userid);
					$result = $wpdb->get_results( "SELECT process_1.ID,process_1.Name,process_1.WorkflowID,process_1.PlanStartDate,process_1.PlanEffort,process_1.ActualStartDate,process_1.CommitDate,process_1.GroupName,process_1.AssigneeID,process_1.Status,process_1.IsFirstStep,process_1.Input,process_1.Output, users_1.ID,users_1.user_login, workflow_1.Name as wfName FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) INNER JOIN ". FCUtility::get_dnt_workflows_table_name() . " workflow_1 ON process_1.WorkFlowID = workflow_1.id  Where users_1.ID=".$userid." and process_1.PlanEFfort!=0"); 
				}
			}
			else
			{
				$workflowid = intval( $workflowid);
				if($userid=="All")
				{
					$result = $wpdb->get_results( "SELECT process_1.ID,process_1.Name,process_1.WorkflowID,process_1.PlanStartDate,process_1.PlanEffort,process_1.ActualStartDate,process_1.CommitDate,process_1.GroupName,process_1.AssigneeID,process_1.Status,process_1.IsFirstStep,process_1.Input,process_1.Output, users_1.ID,users_1.user_login, workflow_1.Name as wfName FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) INNER JOIN ". FCUtility::get_dnt_workflows_table_name() . " workflow_1 ON process_1.WorkFlowID = workflow_1.id  Where process_1.WorkflowID =".$workflowid." and process_1.PlanEFfort!=0"); 
				}
				else
				{
					$userid = intval( $userid);
					$result = $wpdb->get_results( "SELECT process_1.ID,process_1.Name,process_1.WorkflowID,process_1.PlanStartDate,process_1.PlanEffort,process_1.ActualStartDate,process_1.CommitDate,process_1.GroupName,process_1.AssigneeID,process_1.Status,process_1.IsFirstStep,process_1.Input,process_1.Output, users_1.ID,users_1.user_login, workflow_1.Name as wfName FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) INNER JOIN ". FCUtility::get_dnt_workflows_table_name() . " workflow_1 ON process_1.WorkFlowID = workflow_1.id  Where process_1.WorkflowID =".$workflowid." and users_1.ID=".$userid." and process_1.PlanEFfort!=0"); 
				}
			}
	   }
	   else
	   {
			if($workflowid=="All")
			{
				if($userid=="All")
				{
					$result = $wpdb->get_results( "SELECT process_1.ID,process_1.Name,process_1.WorkflowID,process_1.PlanStartDate,process_1.PlanEffort,process_1.ActualStartDate,process_1.CommitDate,process_1.GroupName,process_1.AssigneeID,process_1.Status,process_1.IsFirstStep,process_1.Input,process_1.Output, users_1.ID,users_1.user_login, workflow_1.Name as wfName FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) INNER JOIN ". FCUtility::get_dnt_workflows_table_name() ." worflow_1 ON(process_1.WorkflowID=worflow_1.ID) Where worflow_1.Status='$workflowstatus' and process_1.PlanEFfort!=0"); 
				}
				else
				{
					$userid = intval( $userid);
					$result = $wpdb->get_results( "SELECT process_1.ID,process_1.Name,process_1.WorkflowID,process_1.PlanStartDate,process_1.PlanEffort,process_1.ActualStartDate,process_1.CommitDate,process_1.GroupName,process_1.AssigneeID,process_1.Status,process_1.IsFirstStep,process_1.Input,process_1.Output, users_1.ID,users_1.user_login, workflow_1.Name as wfName FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) INNER JOIN ". FCUtility::get_dnt_workflows_table_name() ." worflow_1 ON(process_1.WorkflowID=worflow_1.ID) Where worflow_1.Status='$workflowstatus' and users_1.ID=".$userid." and process_1.PlanEFfort!=0"); 
				}
			}
			else
			{
				$workflowid = intval( $workflowid);
				if($userid=="All")
				{
					$result = $wpdb->get_results( "SELECT process_1.ID,process_1.Name,process_1.WorkflowID,process_1.PlanStartDate,process_1.PlanEffort,process_1.ActualStartDate,process_1.CommitDate,process_1.GroupName,process_1.AssigneeID,process_1.Status,process_1.IsFirstStep,process_1.Input,process_1.Output, users_1.ID,users_1.user_login, workflow_1.Name as wfName FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) INNER JOIN ". FCUtility::get_dnt_workflows_table_name() ." worflow_1 ON(process_1.WorkflowID=worflow_1.ID) Where worflow_1.Status='$workflowstatus' and process_1.WorkflowID =".$workflowid." and process_1.PlanEFfort!=0"); 
				}
				else
				{
					$userid = intval( $userid);
					$result = $wpdb->get_results( "SELECT process_1.ID,process_1.Name,process_1.WorkflowID,process_1.PlanStartDate,process_1.PlanEffort,process_1.ActualStartDate,process_1.CommitDate,process_1.GroupName,process_1.AssigneeID,process_1.Status,process_1.IsFirstStep,process_1.Input,process_1.Output, users_1.ID,users_1.user_login, workflow_1.Name as wfName FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id ) INNER JOIN ". FCUtility::get_dnt_workflows_table_name() ." worflow_1 ON(process_1.WorkflowID=worflow_1.ID) Where worflow_1.Status='$workflowstatus' and process_1.WorkflowID =".$workflowid." and users_1.ID=".$userid." and process_1.PlanEFfort!=0"); 
				}
			}
	   }  
	   echo json_encode($result);
	   exit();
	}
	
	static function get_all_monitor_datas()
	{   
	   global $wpdb;
   
	   $result = $wpdb->get_results( "SELECT process_1.ID,process_1.Name,process_1.WorkflowID,process_1.PlanStartDate,process_1.PlanEffort,process_1.ActualStartDate,process_1.CommitDate,process_1.GroupName,process_1.AssigneeID,process_1.Status,process_1.IsFirstStep,process_1.Input,process_1.Output, users_1.ID,users_1.user_login FROM " . FCUtility::get_dnt_workflow_steps_table_name() . " process_1 INNER JOIN {$wpdb->base_prefix}users users_1 ON ( process_1.AssigneeID = users_1.id )   WHERE process_1.PlanEFfort!=0"); 
	   
	   return $result ;
	}
	
	static function get_workdays($start_date,$end_date)
	{   
	
		$daysdiff=abs((strtotime($end_date)-strtotime($start_date))/86400)+1;
		$weekends= FCWorkflowMonitor::get_weekend_days($start_date,$end_date);
		return ($daysdiff-$weekends);
		
	}
	
	function get_weekend_days($start_date,$end_date){ 
		if (strtotime($start_date) > strtotime($end_date)) list($start_date, $end_date) = array($end_date, $start_date); 
		$start_reduce = $end_add = 0; 
		$start_N = date('N',strtotime($start_date)); 
		$start_reduce = ($start_N == 7) ? 1 : 0; 
		$end_N = date('N',strtotime($end_date)); 
		in_array($end_N,array(6,7)) && $end_add = ($end_N == 7) ? 2 : 1; 
		$days = abs(strtotime($end_date) - strtotime($start_date))/86400 + 1; 
		return floor(($days + $start_N - 1 - $end_N) / 7) * 2 - $start_reduce + $end_add; 
	} 

	
	

	
}


?>