jQuery(document).ready(function(){	
	function deleteTableData(tableID){
		var tableObj = document.getElementById(tableID);
		var rownum = tableObj.rows.length;
		for(var i=rownum-1;i >0;i--){
			tableObj.deleteRow(i);
		}
	}
	
	jQuery("#action-select-in-history").change(function(){
       //alert("workflow-select ="+ jQuery(this).val());
		workflow_action_select(jQuery(this).val());
		//alert(jQuery(this).val());
	});
	
	function workflow_action_select(action_type){
		deleteTableData("action-history-list-table");
		data={
			action: 'get_workflow_aciton_history',
			action_type: action_type
		};
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){	
				if(response){
					//alert("response="+response);
					var aciton_history = JSON.parse(response);
					if(aciton_history.length!=0){
						for(var i=0;i< aciton_history.length;i++){	
							jQuery("#action-history-list-table").append(
											  "<tr><td style='display:none'>"+aciton_history[i]["ID"]+"</td>"
												+ "<td>"+aciton_history[i]["action_name"]+"</td>"
												+ "<td>"+aciton_history[i]["actor_name"]+"</td>"
												+ "<td>"+aciton_history[i]["action_status"]+"</td>"
												+ "<td>"+aciton_history[i]["action_description"]+"</td>"
												+ "<td>"+aciton_history[i]["workflow_id"]+"</td>"
												+ "<td>"+aciton_history[i]["step_id"]+"</td>"
												+ "<td>"+aciton_history[i]["object"]+"</td>"
												+ "<td>"+aciton_history[i]["create_datetime"]+"</td></tr>"
								
							);						
						}
					}
					else{
						jQuery("#action-history-list-table").append("<tr><td>No Action Data!</td></tr>");
					}
				}
				
			}		
		});
	}
	
	//******sort table******//	
	//action list table
	jQuery("#sort-action-name,#sort-action-assignee,#sort-action-status,#sort-action-workflowID,#sort-action-processID").each(function(){
		var th = jQuery(this),
			thIndex = th.index(),
			inverse = false;		
		th.click(function(){
			jQuery("#action-history-list-table").find('td').filter(function(){
				return jQuery(this).index() === thIndex;
			}).sortElements(function(a, b){
				return jQuery.text([a]) > jQuery.text([b]) ?
					inverse ? -1 : 1
					: inverse ? 1 : -1;
			}, function(){
				return this.parentNode; 
			});
			inverse = !inverse;
		});
	});
	
	jQuery("#sort-action-actionDate").each(function(){
		var th = jQuery(this),
			thIndex = th.index(),
			inverse = false;		
		th.click(function(){
			jQuery("#action-history-list-table").find('td').filter(function(){
				return jQuery(this).index() === thIndex;
			}).sortElements(function(a, b){
				var tempaYMD = jQuery.text([a]).split(" ")[0];
				var tempaHMS = jQuery.text([a]).split(" ")[1];
				var tempbYMD = jQuery.text([b]).split(" ")[0];
				var tempbHMS = jQuery.text([b]).split(" ")[1];
				if(tempaYMD > tempbYMD){
					return inverse ? -1 : 1;
				}
				else{
					if(tempaYMD == tempbYMD){
						return tempaHMS > tempbHMS ?inverse ? -1 : 1: inverse ? 1 : -1;
					}
					else{
						return inverse ? 1 : -1;
					}
				}
			}, function(){
				return this.parentNode; 
			});
			inverse = !inverse;
		});
	});
});