jQuery(document).ready(function(){
	jQuery( "#workflow-plan-start-date" ).datepicker({
		autoSize: true,
		dateFormat: owf_workflow_create_vars.editDateFormat,			
		onSelect: function(dateText, inst) {
			//jQuery(this).css("background-color", "white");
			//var workflow_plan_effort = jQuery( "#workflow-plan-effort" ).val();
			var workflow_plan_effort = jQuery( "#workflow-plan-effort" ).html();
			var workflow_plan_end_date = plan_end_date_calculation_substract_weekend(dateText,workflow_plan_effort);
			jQuery( "#workflow-plan-end-date" ).val(workflow_plan_end_date);
			//var workflow_id =jQuery("#workflow-select-in-setup").val();
			var process_table = document.getElementById("process-list-table");
			for(var i=1;i < process_table.rows.length;i ++){			
				var actual_effort =Number(process_table.rows[i].cells[7].innerHTML);
				var effort = Number(process_table.rows[i].cells[4].getElementsByTagName('INPUT')[0].value);				
			    each_update_start_date = plan_end_date_calculation_substract_weekend(dateText,actual_effort);
			    each_update_end_date = plan_end_date_calculation_substract_weekend(each_update_start_date,effort);
				process_table.rows[i].cells[5].getElementsByTagName('INPUT')[0].value = each_update_start_date;
				process_table.rows[i].cells[6].getElementsByTagName('INPUT')[0].value = each_update_end_date;
			}
			
			var adj_list = get_graph_adj_list(processConnJsonObjArr,processJsonObjArr);
			var cri_path_obj= get_critical_path(adj_list);
			show_critical_path(cri_path_obj.critical_path_list);	
			jQuery("#workflow-plan-start-date").css("border-color", "green");	
			
			//save all table data to history
			save_all_table_data_from_page_to_history();
		}
	});	
	

	jQuery("body").delegate(".process-plan-start-date", "focusin", function(){ 
		var first_process = get_first_process(processJsonObjArr);
		var rowindex = parseInt(jQuery(this).attr("id").split("-")[1]);
		var process_table = document.getElementById("process-list-table");
		var process_id= Number(process_table.rows[rowindex].cells[1].innerHTML);
		var tempdate = process_table.rows[rowindex].cells[5].getElementsByTagName('INPUT')[0].value;
		
		jQuery(this).datepicker({
			autoSize: false,
			dateFormat: owf_workflow_create_vars.editDateFormat,			
			onSelect: function(dateText, inst) {
			//jQuery(this).css("background-color", "white");
			//alert("date pick");
			//alert(jQuery(this).attr("id"));
			//alert("dateText"+dateText);
			//alert("inst"+inst);
			var first_process_start_date ;
			for(var j=1;j < process_table.rows.length;j ++){
				var each_process_id =  Number(process_table.rows[j].cells[1].innerHTML);
				if(each_process_id==first_process.ID){
					first_process_start_date =  process_table.rows[j].cells[5].getElementsByTagName('INPUT')[0].value;
				}
			}			
			if(first_process.ID==process_id){
				for(var i=1;i < process_table.rows.length;i ++){
					var workflow_start_date =first_process_start_date;
					var workflow_end_date;
					var workflow_effort = jQuery( "#workflow-plan-effort" ).html();
					workflow_end_date = plan_end_date_calculation_substract_weekend(workflow_start_date,workflow_effort);				
					jQuery("#workflow-plan-start-date").val(workflow_start_date);	
					jQuery( "#workflow-plan-effort" ).html(workflow_effort);
					jQuery("#workflow-plan-end-date").val(workflow_end_date);
					
					var actual_effort =Number(process_table.rows[i].cells[7].innerHTML);
					var effort = Number(process_table.rows[i].cells[4].getElementsByTagName('INPUT')[0].value);				
					each_update_start_date = plan_end_date_calculation_substract_weekend(dateText,actual_effort);
					each_update_end_date = plan_end_date_calculation_substract_weekend(each_update_start_date,effort);
						
					process_table.rows[i].cells[5].getElementsByTagName('INPUT')[0].value = each_update_start_date;
					process_table.rows[i].cells[6].getElementsByTagName('INPUT')[0].value = each_update_end_date;
				}		
				var adj_list = get_graph_adj_list(processConnJsonObjArr,processJsonObjArr);
				var cri_path_obj= get_critical_path(adj_list);
				show_critical_path(cri_path_obj.critical_path_list);				
			}
			else{
				//verify the date
				var odate1 =new Date(dateText);
				var odate2= new Date(tempdate);
				if(odate1.getTime()>odate2.getTime()){//re-calculate the cricical path;				
					//insert the vitual process into processConnJsonObjArr
					var effort = getWorkDays(tempdate,dateText)-1;
					process_insert(processConnJsonObjArr,processJsonObjArr,process_id,effort);
					var adj_list = get_graph_adj_list(processConnJsonObjArr,processJsonObjArr);
					var cri_path_obj= get_critical_path(adj_list);
					
					var workflow_start_date =first_process_start_date;
					var workflow_end_date;
					var workflow_effort=0;
					for(var a in cri_path_obj.critical_path_list[0]){
						workflow_effort += Number(cri_path_obj.critical_path_list[0][a].Effort);
					}				
					workflow_end_date = plan_end_date_calculation_substract_weekend(workflow_start_date,workflow_effort);				
					jQuery("#workflow-plan-start-date").val(workflow_start_date);	
					jQuery( "#workflow-plan-effort" ).html(workflow_effort);
					jQuery("#workflow-plan-end-date").val(workflow_end_date);
					
					for(var j=1;j < process_table.rows.length;j++){
						var each_process_id =  Number(process_table.rows[j].cells[1].innerHTML);
						for(var k in adj_list){
							if(adj_list[k].ID==each_process_id){
								var actual_effort =Number(adj_list[k].Etv-adj_list[k].Effort+1);
								var effort = Number(adj_list[k].Effort);				
								each_update_start_date = plan_end_date_calculation_substract_weekend(first_process_start_date,actual_effort);
								each_update_end_date = plan_end_date_calculation_substract_weekend(each_update_start_date,effort);
								process_table.rows[j].cells[5].getElementsByTagName('INPUT')[0].value = each_update_start_date;
								process_table.rows[j].cells[6].getElementsByTagName('INPUT')[0].value = each_update_end_date;
								process_table.rows[j].cells[7].innerHTML = actual_effort;
								break;
							}
						}
					}
					show_critical_path(cri_path_obj.critical_path_list);
				}
				else{
					process_table.rows[rowindex].cells[5].getElementsByTagName('INPUT')[0].value = tempdate;
				}
			}		
		    jQuery(this).css("border-color", "green");

			//save all table data to history
			save_all_table_data_from_page_to_history();
		}
		});
	}); 
	
	
	jQuery("body").delegate(".process-plan-effort", "focusin", function(){ 
		
		//alert('plan effort is changing!');
	});
	
	jQuery("body").delegate(".process-plan-effort", "focusout", function(){ 	
		//alert('plan effort changed!');
		var rowindex = parseInt(jQuery(this).attr("id").split("-")[1]);
		var process_table = document.getElementById("process-list-table");	
		var process_id= Number(process_table.rows[rowindex].cells[1].innerHTML);
		var preEffort =0;
		var index = 0;
		for(var i in processJsonObjArr){
			if(processJsonObjArr[i].ID == process_id){
				preEffort = processJsonObjArr[i].PlanEffort;
				index = i;
				break;
			}
		}
		//verify the input is positive number;	
		var inputEffort = process_table.rows[rowindex].cells[4].getElementsByTagName('INPUT')[0].value;
		if(preEffort==inputEffort){	
			
		}
		else{
			var IsPosNum=0;
			var reg= /^\d+$/;
			if((reg.test(inputEffort)) && inputEffort>0 &&inputEffort!=""){
				//alert('positive number');
				IsPosNum = 1;
			}
			
			if(IsPosNum){
				var first_process_start_date="";
				var first_process = get_first_process(processJsonObjArr);			
				for(var k=1;k < process_table.rows.length;k++){
					var each_process_id =  Number(process_table.rows[k].cells[1].innerHTML);
					if(each_process_id==first_process.ID){
						first_process_start_date =  process_table.rows[k].cells[5].getElementsByTagName('INPUT')[0].value;
					}
				}
				
				processJsonObjArr[index].PlanEffort = inputEffort;
				var adj_list = get_graph_adj_list(processConnJsonObjArr,processJsonObjArr);
				var cri_path_obj= get_critical_path(adj_list);
				
				var workflow_start_date =first_process_start_date;
				var workflow_end_date;
				var workflow_effort=0;
				for(var a in cri_path_obj.critical_path_list[0]){
					workflow_effort += Number(cri_path_obj.critical_path_list[0][a].Effort);
				}				
				workflow_end_date = plan_end_date_calculation_substract_weekend(workflow_start_date,workflow_effort);				
				jQuery("#workflow-plan-start-date").val(workflow_start_date);	
				jQuery( "#workflow-plan-effort" ).html(workflow_effort);
				jQuery("#workflow-plan-end-date").val(workflow_end_date);
				
				for(var j=1;j < process_table.rows.length;j++){
					var each_process_id =  Number(process_table.rows[j].cells[1].innerHTML);
					for(var k in adj_list){
						if(adj_list[k].ID==each_process_id){
							var actual_effort =Number(adj_list[k].Etv-adj_list[k].Effort+1);
							var effort = Number(adj_list[k].Effort);				
							each_update_start_date = plan_end_date_calculation_substract_weekend(first_process_start_date,actual_effort);
							each_update_end_date = plan_end_date_calculation_substract_weekend(each_update_start_date,effort);
							process_table.rows[j].cells[5].getElementsByTagName('INPUT')[0].value = each_update_start_date;
							process_table.rows[j].cells[6].getElementsByTagName('INPUT')[0].value = each_update_end_date;
							process_table.rows[j].cells[7].innerHTML = actual_effort;
							break;
						}
					}
				}
				jQuery(this).css("border-color", "green");		
				show_critical_path(cri_path_obj.critical_path_list);
				
				//save all table data to history
				save_all_table_data_from_page_to_history();
			}
			else{
				process_table.rows[rowindex].cells[4].getElementsByTagName('INPUT')[0].value = preEffort;
			}
		}		
	});
	
	jQuery("body").delegate(".assignee-select", "change", function(){ 
		 jQuery(this).css("border-color", "green");	
		//save all table data to history
		save_all_table_data_from_page_to_history();		 
	});
	
	function groups_in_selected_workflow(workflow_id){
		//alert("Group select");
		deleteTableData("group-list-table");
		var groups=[];
		data = {
			action: 'get_groups_in_workflow_fine2',
			workflowid: workflow_id
		}
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){	
				var result={};
				if(response){
					//alert("group response="+response);
					result = JSON.parse(response) ;
					var groupCount = result.length;
					//alert("groupCount="+groupCount);
					for(var i=0;i< groupCount;i++){
						//alert("groupname="+result[i]["GroupName"]);
						groups.push(result[i]["GroupName"]);
					}
					
					for(var i=0; i< groups.length; i++){
					    var groupName = groups[i];
						//alert("groups[i]="+groups[i]);
						var userList = users_get(groups[i]);						
						var usersAppendOption="<option selected='selected' value=''>";
						for(var j=0;j < userList.length;j++){
								usersAppendOption += "<option value='" + userList[j]["ID"] + "'>"+ userList[j]["Name"]+"</option>";
						}
						jQuery("#group-list-table").append("<tr>"
																   +"<td>" + groupName + "</td>"
																   +"<td class='assignee_All'>"+
																		"<select class='group-assignee-select' id='" + groupName +"' name='assignee-select' style='width:150px' real='step-loading-span'>"+
																		usersAppendOption +"</select>"+
																	 "</td>"
															       +"</tr>");
					}
				}
			}		
		});		
	}
	
    //group-list part: assign one group's all process to one assignee
	jQuery(".group-assignee-select").live("change",function(){
		//alert("group assignee changed="+ jQuery(this).attr("id"));
		var groupindex = jQuery(this).attr("id");
		var assignee = jQuery(this).val();
		//alert("groupindex="+groupindex);
		jQuery("#process-list-table ."+groupindex + "assignee-select").val(assignee);
		jQuery("#process-list-table ."+groupindex + "assignee-select").css("border-color", "green");
		
		//save all table data to history
		save_all_table_data_from_page_to_history();
	});

	function first_process_get(workflow_id){
		var first_process_start_date="";
		data={
			action: 'get_first_process_fine2',
			workflowid: workflow_id
		};
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){
				var result={};
				if(response){
					//alert("GroupName respnse="+response);
					result = JSON.parse(response);
					if(result.length!=1){
						alert(" more than one first process");
					}
					if(result.length==1){
						//alert("GroupName length 1");
						result = JSON.parse(response) ;
						//alert("GroupName="+result[0]["GroupName"]);
						if(result[0]["PlanStartDate"]!=null){
							first_process_start_date = result[0]["PlanStartDate"].split(" ")[0];
						}
						else{

							//alert("empty paln startDate="+ result[i]["PlanStartDate"]);
							var now = new Date();
							now = now.getFullYear()+"-"+((now.getMonth()+1)<10?"0":"")+(now.getMonth()+1)+"-"+(now.getDate()<10?"0":"")+now.getDate();					
							first_process_start_date = now;
						}
					}
				}
			}
		});
		return first_process_start_date;
	}
	
	function users_get(group_name){
		//alert("pre ajax users_get");
		var users=[];
		data={
			action: 'get_users_by_group_fine2',
			groupname: group_name
		};
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){	
				var result={};
				//alert("get_users_by_group response="+response);
				if(response){
					result = JSON.parse(response) ;
					var userCount = result.length;
					for(var i=0;i< userCount;i++){
						//alert("user="+result[i]["ID"]);
						var userObject={ID:result[i]["ID"],Name:result[i]["user_login"]};					
						users.push(userObject);
					}
				}
			}		
		});
		return users;
	}
	
	function processlist_get(workflow_id){
		//alert("pre get process");
		deleteTableData("process-list-table");
		//jQuery("#process-list-table").addClass("loading");
		if(workflow_id){
			data={
				action : 'get_process_list_in_workflow_fine2',
				workflowid : workflow_id
			};
			var cri_path_obj;
			jQuery.ajax({
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					var result=[];
					if(response){				
						//alert("process="+response);
						result = JSON.parse(response) ;
						processJsonObjArr = result;					
						processConnJsonObjArr=process_connections_get(workflow_id);		
						var adj_list = get_graph_adj_list(processConnJsonObjArr,processJsonObjArr);
						cri_path_obj= get_critical_path(adj_list);

						var workflowStartDate = workflowDates_get(workflow_id);									
						//alert("result="+result);
						var processCount = result.length;				
						for(var i = 0; i< processCount; i++){

							var groupName = result[i]["GroupName"];
							//alert("groupName="+groupName);
							var userList = users_get(groupName);
							var usersAppendOption="";						
							for(var j=0;j < userList.length;j++){
								if(result[i]["AssigneeID"]!=userList[j]["ID"]){
									usersAppendOption += "<option value='" + userList[j]["ID"] + "'>"+ userList[j]["Name"]+"</option>";
								}
								else{
									usersAppendOption+="<option selected='selected' value='" + userList[j]["ID"] + "'>"+ userList[j]["Name"]+"</option>";
								}
							}
							
							var acutal_effort;
							result[i]["PlanStartDate"] = result[i]["PlanStartDate"].split(" ")[0];
							for(var k in adj_list){
								if(result[i]["ID"]==adj_list[k].ID){
									if(result[i]["IsFirstStep"]=="Yes"){
										result[i]["PlanEndDate"]= result[i]["PlanStartDate"];
										acutal_effort =0;
									}
									else{
										result[i]["PlanEndDate"] = plan_end_date_calculation_substract_weekend(workflowStartDate,adj_list[k].Etv);
										if(result[i]["ID"]==cri_path_obj.decID){
											result[i]["PlanStartDate"] = result[i]["PlanEndDate"];
											acutal_effort = adj_list[k].Etv;
										}
										else{										
											acutal_effort = adj_list[k].Etv-adj_list[k].Effort+1;
											
										}
									}																		
									break;
								}
							}
							//alert("usersAppendOption="+usersAppendOption);
							var index = parseInt(i)+1;
							var userStr="";
							var startdateStr="";
							var planeffortStr="";
							var enddateStr="";
							if(result[i]["ID"]==cri_path_obj.srcID||result[i]["ID"]==cri_path_obj.decID){
								userStr = "<select id ='assignee-select-"+ index +"' class='"+ groupName +"assignee-select assignee-select' name='assignee-select' style='width:150px' real='step-loading-span'>"+ usersAppendOption +"</select>";
								startdateStr = "<input id='processstart-"+ index +"' name='process-plan-start-date' class='process-plan-start-date date_input' type='text' real='publish-date-loading-span' disabled value='"+ result[i]["PlanStartDate"] + "'/>";
								planeffortStr = "<input id='processeffort-"+ index +"' name='process-plan-effort' class='process-plan-effort date_input' type='text' real='publish-date-loading-span' disabled value='"+ result[i]["PlanEffort"] + "'/>"
								
							}
							else{
								userStr = "<select id ='assignee-select-"+ index +"' class='"+ groupName +"assignee-select assignee-select' name='assignee-select' style='width:150px' real='step-loading-span'>"+ usersAppendOption +"</select>";
								startdateStr = "<input id='processstart-"+ index +"' name='process-plan-start-date' class='process-plan-start-date date_input' type='text' real='publish-date-loading-span' readonly value='"+ result[i]["PlanStartDate"] + "'/>";
								planeffortStr = "<input id='processeffort-"+ index +"' name='process-plan-effort' class='process-plan-effort date_input' type='text' real='publish-date-loading-span' value='"+ result[i]["PlanEffort"] + "'/>"
							}
							jQuery("#process-list-table").append("<tr>" 
																   +"<td>" + result[i]["Name"] + "</td>"
																   +"<td style='display:none'>" + result[i]["ID"] + "</td>"
																   +"<td>" + groupName + "</td>"
																   +"<td>"+ userStr + "</td>"
																   +"<td>"+ planeffortStr + "</td>"
																   +"<td>" + startdateStr + "</td>"
																   +"<td>" + 
																	  "<input id='processend-"+ index +"' name='process-plan-end-date' class='process-plan-end-date date_input' type='text' real='publish-date-loading-span' disabled value='"+ 
																	   result[i]["PlanEndDate"]  + "'/></td>"
																   + "<td style='display:none'>"+acutal_effort+"</td>"
															+"</tr>");							
						}
						
					}
				}
			});
			show_critical_path(cri_path_obj.critical_path_list);
		}
		//jQuery("#process-list-table").removeClass("loading");
	}
	
	
		
	var constprocessConnJsonObjArr;
	var processConnJsonObjArr;
	var processJsonObjArr;
	function process_connections_get(workflow_id){
		data={
			action: 'get_process_connections_fine2',
			workflowid: workflow_id
		};
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){
				if(response){
					//alert("processConnectionJasonString="+response);
					processConnJsonObjArr = JSON.parse(response);
					//alert("processConnectionJasonObj="+processConnJsonObjArr[0].ID);
				}
			}
		});
		if(processConnJsonObjArr.length==0){
			return ;
		}
		else{
			return processConnJsonObjArr;
		}
	}
	
	
	function get_process_effort(prsJsonObjArr,process_id){
		var p_effort;
		for(var key in prsJsonObjArr){
			if(prsJsonObjArr[key].ID==process_id){
				p_effort = prsJsonObjArr[key].PlanEffort;
				break;
			}
		}
		return p_effort;
	}
	
	function get_first_process(prsJsonObjArr){
		var first_process =new Object();
		for(var key in prsJsonObjArr){
			if(prsJsonObjArr[key].IsFirstStep=="Yes"){
				first_process = prsJsonObjArr[key];
				break;
			}
		}
		return first_process;
	}
	
	function pre_processes_get(prsConnJsonObjArr,prsJsonObjArr,process_id){
		var processIDs=[];
		var pre_processes = [];
		for(var key in prsConnJsonObjArr){
			if(prsConnJsonObjArr[key].UseProcessID==process_id){
				processIDs.push(prsConnJsonObjArr[key].CreateProcessID);
			}				
		}
		for(var ikey in processIDs){
			for(var jkey in prsJsonObjArr){
				if(processIDs[ikey]==prsJsonObjArr[jkey].ID){
					pre_processes.push(prsJsonObjArr[jkey]);
					break;
				}
			}
		}	
		return pre_processes;
	}

    function next_processes_get(prsConnJsonObjArr,prsJsonObjArr,process_id){
		var processIDs=[];
		var next_processes = [];
		for(var key in prsConnJsonObjArr){
			if(prsConnJsonObjArr[key].CreateProcessID==process_id){
				processIDs.push(prsConnJsonObjArr[key].UseProcessID);
			}				
		}
		for(var ikey in processIDs){
			for(var jkey in prsJsonObjArr){
				if(processIDs[ikey]==prsJsonObjArr[jkey].ID){
					next_processes.push(prsJsonObjArr[jkey]);
					break;
				}
			}
		}	
		return next_processes;
	}	
	
	function max_date(date1,date2){
		var odate1 =new Date(date1);
		var odate2= new Date(date2);
		var maxdate;
		if(odate1.getTime()>odate2.getTime()){
			maxdate = date1;
		}
		else{
			maxdate = date2;
		}
		return maxdate;
	}
	
	
	function process_insert(prsConnJsonObjArr,prsJsonObjArr,process_id,effort){
		//judge the pre-process whether Idle or not
		var IsIdle=0;
		var pre_process = pre_processes_get(prsConnJsonObjArr,prsJsonObjArr,process_id);
		for(var m in pre_process){
			if(pre_process[m].Name=="Idle"){
				IsIdle=1;
				pre_process[m].PlanEffort = effort;
				break;
			}
		}
		
		if(IsIdle){
			
		}
		else{
			//new a process:find the max_id in prsJsonObjArr,then max_id +=1;
			var new_id=0;
			var workflowSchemeID = prsConnJsonObjArr[0].WorkflowSchemeID;
			for(var k in prsJsonObjArr){
				if(Number(prsJsonObjArr[k].ID) > Number(new_id)){
					new_id = Number(prsJsonObjArr[k].ID);
				}
			}
			new_id+=1;
			var new_process = {ID:new_id,Name:"Idle",WorkflowSchemeID:prsJsonObjArr[0].WorkflowSchemeID,GroupName:prsJsonObjArr[0].GroupName,IsFirstStep:"No",PlanEffort:effort};
			prsJsonObjArr.push(new_process);
			
			var new_conn_id=0;
			for(var l in prsConnJsonObjArr){
				if(Number(prsConnJsonObjArr[l].ID) > Number(new_conn_id)){
					new_conn_id = Number(prsConnJsonObjArr[l].ID);
				}
			}
			var pre_process = pre_processes_get(prsConnJsonObjArr,prsJsonObjArr,process_id);
			//remove the oonn : pre_process->process_id from the  prsConnJsonObjArr
			for(var j in prsConnJsonObjArr){
				if(prsConnJsonObjArr[j].UseProcessID==process_id){
					prsConnJsonObjArr.splice(j,1);
				}
			}
			//create conn for the new process
			for(var i in pre_process){
				new_conn_id++;
				var tempPrsConn ={ID:new_conn_id,WorkflowSchemeID:workflowSchemeID,CreateProcessID:pre_process[i].ID,UseProcessID:new_id};
				prsConnJsonObjArr.push(tempPrsConn);
			}
			new_conn_id +=1;
			var temPrsConn = {ID:new_conn_id,WorkflowSchemeID:workflowSchemeID,CreateProcessID:new_id,UseProcessID:process_id};
			prsConnJsonObjArr.push(temPrsConn);	
		}		
	}
	
	function get_graph_adj_list(prsConnJsonObjArr,prsJsonObjArr){
		var adj_list=[];
		for(var key in prsJsonObjArr){
			var id = prsJsonObjArr[key].ID;
			var next_pro = next_processes_get(prsConnJsonObjArr,prsJsonObjArr,id);
			var pre_pro = pre_processes_get(prsConnJsonObjArr,prsJsonObjArr,id);
			var in_degree = pre_pro.length;
			var tempObj={ID:id,Name:prsJsonObjArr[key].Name,Indegree:in_degree,Effort:prsJsonObjArr[key].PlanEffort,Ete:0,Lte:0,Etv:0,Ltv:1000,NextProcess:next_pro};			
			adj_list.push(tempObj);
		}	
		return adj_list;
	}
	
	function get_topological_sort(graph_adj_list){
		var top = [];//top sort
		var stack = [];
		var countnum=0;
		for(var k in graph_adj_list){
			if(graph_adj_list[k].Indegree==0){
				stack.push(k);
			}
		}
		
		while(stack.length!=0){
			var j = stack.pop();
			top.push(j);
			countnum++;		
			for(var i in graph_adj_list[j].NextProcess){
				var id = graph_adj_list[j].NextProcess[i].ID;
				var effort = graph_adj_list[j].NextProcess[i].PlanEffort;
				var adjList_index;
				for(var a in graph_adj_list){
					if(id == graph_adj_list[a].ID){
						adjList_index = a;
					}
				}
				if(--graph_adj_list[adjList_index].Indegree==0){
					stack.push(adjList_index);
				}
				var tempnum = Number(graph_adj_list[j].Etv)+Number(effort);
				if(tempnum>graph_adj_list[adjList_index].Etv){
					graph_adj_list[adjList_index].Etv = tempnum;// calculate the earilist occur time of event
				}
			}
		}
		if(countnum< graph_adj_list.length){
			return;
		}
		else{	
			return top;
		}
	}
	
	function get_critical_path(graph_adj_list){	
		var critical_edge = [];
		var T = get_topological_sort(graph_adj_list);
		var t = T.pop();
		T.push(t);
		graph_adj_list[t].Ltv = graph_adj_list[t].Etv;//calculate the latest occur time of event
		while(T.length!=0){
			var j = T.pop();
			for(var i in graph_adj_list[j].NextProcess){
				var id = graph_adj_list[j].NextProcess[i].ID;
				var effort = graph_adj_list[j].NextProcess[i].PlanEffort;
				var adjList_index;
				for(var a in graph_adj_list){
					if(id == graph_adj_list[a].ID){
						adjList_index = a;
					}
				}
				if(graph_adj_list[adjList_index].Ltv-effort < graph_adj_list[j].Ltv){
					graph_adj_list[j].Ltv = graph_adj_list[adjList_index].Ltv-effort;
				}									
			}
		}
		
		for(var j in graph_adj_list){
			for(var i in graph_adj_list[j].NextProcess){
				var id = graph_adj_list[j].NextProcess[i].ID;
				var effort = graph_adj_list[j].NextProcess[i].PlanEffort;
				var adjList_index;
				for(var a in graph_adj_list){
					if(id == graph_adj_list[a].ID){
						adjList_index = a;
					}
				}
				graph_adj_list[j].Ete = graph_adj_list[j].Etv;
				graph_adj_list[j].Lte = graph_adj_list[adjList_index].Ltv-effort;
				if(graph_adj_list[j].Ete == graph_adj_list[j].Lte){
					var temp = {Name:graph_adj_list[adjList_index].Name,FromID:graph_adj_list[j].ID,ToID:graph_adj_list[adjList_index].ID,Effort:effort};
					critical_edge.push(temp);
				}
			}
		}
		
		var vertexObj=getVertexIDArrFromCriEdge(critical_edge);
		var vertexIDArr=vertexObj.vertexIDArr;
		var srcID = vertexObj.srcID;
		var decID =vertexObj.decID;
		var adjmatrix = CreateAdjMatrix(critical_edge,vertexIDArr);	
		var srcIDIndex;
		var desIDIndex;
		for(var d in vertexIDArr){
			if(vertexIDArr[d]==srcID){
				srcIDIndex=d;
			}
			if(vertexIDArr[d]==decID){
				desIDIndex = d;
			}
		}
		
		var visited=[];
		for(var k in vertexIDArr){
			visited[k]=0;
		}
		var index_path=new Array();
		index_path_list=[];
		SearchAllPath(adjmatrix,index_path,visited,srcIDIndex,desIDIndex,1);	
		
		var critical_path_list=[];
		for(var l in index_path_list){
			var cri_path=[];
			for(var m in index_path_list[l]){
				for(var n in critical_edge){
					var tempM =Number(m) + Number(1);
					if((vertexIDArr[index_path_list[l][m]]==critical_edge[n].FromID) && (vertexIDArr[index_path_list[l][tempM]]==critical_edge[n].ToID)){
						cri_path.push(critical_edge[n]);
					}
				}
			}
			critical_path_list.push(cri_path);
		}
		
		var critical_path_list_obj={critical_path_list:critical_path_list,srcID:srcID,decID:decID};
		
		return critical_path_list_obj;		
	}
	
	function deleteTableData(tableID){
		var tableObj = document.getElementById(tableID);
		var rownum = tableObj.rows.length;
		for(var i=rownum-1;i >0;i--){
			tableObj.deleteRow(i);
		}
	}
	
	function show_critical_path(cri_path_list){
		//delete tr first
		deleteTableData("critical-path-table");
		
		for(var i in cri_path_list){
			var pathindex =Number(i)+Number(1);
			var rowNum = cri_path_list[i].length;
			//var critical_path_info = "<tr><td rowspan='"+ rowNum +"'>"+ pathindex+"</td></tr>";
			var critical_path_info = "";
			for(var j in cri_path_list[i]){
				var process_table = document.getElementById("process-list-table");
				var p_start_date="";
				
				for(var k=1;k < process_table.rows.length;k ++){
					var process_id = process_table.rows[k].cells[1].innerHTML;					
					if(process_id==cri_path_list[i][j].ToID){
						p_start_date = process_table.rows[k].cells[5].getElementsByTagName('INPUT')[0].value;
					}
				}

				if(cri_path_list[i][j].Effort!=0){
					var tempPathStr="";
					if(j!=0){
						tempPathStr = "<td style='visibility:hidden'>"+ pathindex +"</td>";
					}
					else{
						tempPathStr = "<td>"+ pathindex +"</td>";
					}
					critical_path_info+="<tr>"
										+ tempPathStr			
									   +"<td>" + cri_path_list[i][j].Name + "</td>"
									   +"<td style='display:none'>" + cri_path_list[i][j].ToID + "</td>"
									   +"<td>"+cri_path_list[i][j].Effort+"</td>"	
									   +"<td>"+p_start_date+"</td>"															     																	   
									 +"</tr>"
				}				
			}
			//critical_path_info +="<tr style='height:1px;border-color:#ddd'><td colspan='4'></td></tr>";
			jQuery("#critical-path-table").append(critical_path_info);
			
		}
	}
	
	function getVertexIDArrFromCriEdge(critical_edge){
		var vertexIDArr=[];
		if(!Array.indexOf){
            Array.prototype.indexOf = function(obj){
                for(var i=0; i<this.length; i++){
                    if(this[i]==obj){
                        return i;
                    }
                }
                return -1;
            }
        }
		var srcID = get_first_process(processJsonObjArr).ID;	
		vertexIDArr.push(srcID);
		for(var key in critical_edge){
			if(vertexIDArr.indexOf(critical_edge[key].ToID)==-1){
				vertexIDArr.push(critical_edge[key].ToID);
			}
		}
		var decID;
		for(var i in vertexIDArr){
			var isflag=0;
			for(var j in critical_edge){
				if(vertexIDArr[i]==critical_edge[j].FromID){
					isflag=1;
					break;
				}
			}
			if(isflag==0){
				decID = vertexIDArr[i];
				break;
			}		
		}
		var vertexObj={vertexIDArr:vertexIDArr,srcID:srcID,decID:decID};
		return vertexObj;
	}
	
	function CreateAdjMatrix(critical_edge,vertexIDArr){
		var adjmatrix=[];
		for(var i in vertexIDArr){
			adjmatrix[i]=[];
			for(var j in vertexIDArr){
				adjmatrix[i][j]=0;
				for(var k in critical_edge){
					if(critical_edge[k].FromID==vertexIDArr[i]&&critical_edge[k].ToID==vertexIDArr[j]){
						adjmatrix[i][j]=1;
						break;
					}
				}
			}
		}
		return adjmatrix;
	}
	
	var index_path_list=[];
	function SearchAllPath(adjMatrix, path, visited, v, des, length) {
		if (visited[v]) 
			return;
		path[length-1] = v;
		if (v == des) {
			//PrintPath(path, length);
			var temp = new Array();
			for(var j in path){
				temp.push(path[j]);
			}
			index_path_list.push(temp);
		} 
		else {
			visited[v] = 1;
			for (var i = 0; i < visited.length; i++){ 
				if (adjMatrix[v][i] != 0 && !visited[i]) {                
					SearchAllPath(adjMatrix, path, visited, i, des, length+1);
				}

			}
			visited[v] = 0;
		}
	}
	
	function getWorkDays(start_date,end_date){
		var tempDate;
		tempDate = start_date.split("-");
	   var startDate = new Date(tempDate[1]+'-'+tempDate[2]+'-'+tempDate[0]);  
	   tempDate = end_date.split("-");
	   var endDate = new Date(tempDate[1]+'-'+tempDate[2]+'-'+tempDate[0]); 
	   var diffDays = (endDate - startDate)/(1000*60*60*24) + 1;
	   var remainDay = diffDays % 7;
	   var weeks = Math.floor(diffDays / 7);
	   var weekends = 2 * weeks;
	   var weekDay = startDate.getDay();
	   for(var i = 0;i < remainDay;i++){
			if(((weekDay + i)==6)||((weekDay + i)==0)||((weekDay + i)==7)){
				weekends = weekends + 1;
			}
	    }
		var workdays = diffDays-weekends;
		return workdays;
	}
	
	function  DateDiff(sDate1,  sDate2){    
       var  aDate,  oDate1,  oDate2,  iDays ; 
       aDate  =  sDate1.split("-") ; 
       oDate1  =  new  Date(aDate[1]  +  '-'  +  aDate[2]  +  '-'  +  aDate[0]) ;   
       aDate  =  sDate2.split("-") ; 
       oDate2  =  new  Date(aDate[1]  +  '-'  +  aDate[2]  +  '-'  +  aDate[0]);  
       //iDays  =  parseInt(Math.abs(oDate1  -  oDate2)  /  1000  /  60  /  60  /24) ; 
	   iDays  =  parseInt((oDate1  -  oDate2)  /  1000  /  60  /  60  /24) +1; 
	   //alert("iDays="+iDays)
	   return  iDays;
	}	   
     
	
	function plan_end_date_calculation(dateTemp, days) {
		if(days==0){
			days+=1;
		}
	   var startdateYMD = dateTemp.split(" ")[0];
	   //var startdateHMS = dateTemp.split(" ")[1]
	   var startdateYMD = startdateYMD.split("-");  
	   var nDate = new Date(startdateYMD[0]+'-'+startdateYMD[1] + '-' + startdateYMD[2] );
	   var millSeconds = Math.abs(nDate) + ((days-1) * 24 * 60 * 60 * 1000);
	   var rDate = new Date(millSeconds);  
	   var year = rDate.getFullYear();  
	   var month = rDate.getMonth() + 1;  
	   if (month < 10){
			month = "0" + month; 
	   }		
	   var date = rDate.getDate();  
	   if (date < 10){ 
			date = "0" + date;  
	    }
	   //jQuery("#workflow-plan-end-date").val(year + "-" + month + "-" + date );
	   return (year + "-" + month + "-" + date);
	}

	function plan_end_date_calculation_substract_weekend(start_date, days) {
		if(days==0){
			var actualDays =0;	
			return plan_end_date_calculation(start_date,actualDays);
		}
		else{
			var start_date_temp = start_date;
			start_date = start_date.split(" ")[0];
			start_date = start_date.split("-"); 
			start_date = new Date(start_date[0]+'-'+start_date[1]+'-'+start_date[2] );
			
			var weekday =start_date.getDay();		
			var weeks ,remainDay;
			var actualDays =0;	
			var tempday =  Number(weekday) +Number(days);				
			if(weekday!=6 && weekday!=0){
				if(tempday>6){
					var remainday_in_first_week = 5 - weekday +1;
					judgeday = days - remainday_in_first_week;
					if(judgeday<5){
						actualDays=Number(days)+Number(2);
					}
					else{
						actualDays +=2;
						weeks = parseInt(judgeday/5);
						remainDay = (judgeday)%5;
						actualDays += (weeks*7 + remainDay);
						actualDays += remainday_in_first_week;
						if(remainDay==0){
							actualDays -=2;
						}					
					}							
				}
				else{
					actualDays = days;
				}
			}
			else{
				if(weekday == 6){
					actualDays += 2;
					weeks = parseInt(days/5);
					remainDay = (days)%5;
					if(remainDay==0){
						actualDays -= 2;
					}
					actualDays += (weeks*7 + remainDay);
				}
				if(weekday == 0){
					actualDays += 1;
					weeks = parseInt(days/5);
					remainDay = (days)%5;
					actualDays += (weeks*7 + remainDay);
					if(remainDay==0){
						actualDays -= 2;
					}					
				}	
			}
			return plan_end_date_calculation(start_date_temp,actualDays);
		}				
	}   
	
	function workflow_effort_get_by_criticalpath(workflow_id){
		var workflow_effort="";
		data={
			action: 'get_workflow_effort_by_criticalpath_fine2',
			workflowid: workflow_id
		};
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){
				if(response){
					workflow_effort = response;
					//alert("workflow_effort="+workflow_effort);
				}
			}
		});
		return workflow_effort;
	}
	
	function workflowDates_get(workflow_id){
		var workflow_start_date="";
		data={
			action: 'get_selected_workflow_fine2',
			workflowid: workflow_id
		};
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){
				if(response){
					result = JSON.parse(response) ;	
					workflow_start_date = result[0]["PlanStartDate"].split(" ")[0];
					var workflow_effort = result[0]["PlanEffort"];
					var workflow_end_date = plan_end_date_calculation_substract_weekend(workflow_start_date,workflow_effort);
					jQuery("#workflow-plan-start-date").val(workflow_start_date);	
					jQuery( "#workflow-plan-effort" ).html(workflow_effort);
					jQuery("#workflow-plan-end-date").val(workflow_end_date);
				}
			}
		});
		return workflow_start_date;
		
	}
	
	function workflow_select(workflow_id){
		processConnJsonObjArr =[];
		processJsonObjArr =[];
		index_path_list= [];
		constprocessConnJsonObjArr=[];
		//alert("critical PlanEffort="+workflow_effort_get_by_criticalpath(workflow_id));
		if(workflow_id){
			jQuery("#workflow-select-in-setup").css("border-color", "#ddd");	
			processlist_get(workflow_id);
			groups_in_selected_workflow(workflow_id);
			//getCriticalPath(workflow_id);
			constprocessConnJsonObjArr = process_connections_get(workflow_id);			
			//var adj_list = get_graph_adj_list(processConnJsonObjArr,processJsonObjArr);
			//var cri_path_obj= get_critical_path(adj_list);
			//show_critical_path(cri_path_obj.critical_path_list);
			//save_all_table_data_from_page_to_history();
		}
		else
		{
			//save_all_table_data_from_page_to_history();
			//alert("chose no workflow");
			deleteTableData("process-list-table");
			deleteTableData("group-list-table");		
			deleteTableData("critical-path-table");
			jQuery("#workflow-plan-start-date").val("");
			jQuery("#workflow-plan-end-date").val("");
			jQuery( "#workflow-plan-effort" ).html("");
		}

		//save all table data to history
		save_all_table_data_from_page_to_history();
	}
	
	jQuery("#workflow-select-in-setup").change(function(){
       //alert("workflow-select ="+ jQuery(this).val());
		workflow_select(jQuery(this).val());
	});
	
	function workflow_setup_save(){		
		var workflow_scheme_ID = jQuery("#workflow-select-in-setup").val();
		var workflow_name = jQuery( "#workflow-select-in-setup option:selected" ).text();
		var workflow_plan_start_date = jQuery( "#workflow-plan-start-date" ).val();
		var workflow_plan_end_date = jQuery( "#workflow-plan-end-date" ).val();
		var workflow_plan_effort = jQuery( "#workflow-plan-effort" ).html();
		var now = new Date();								
		var workflow_setup_date = now.getFullYear()+"-"+((now.getMonth()+1)<10?"0":"")+(now.getMonth()+1)+"-"+(now.getDate()<10?"0":"")+now.getDate();
		var workflow_status;
		if(workflow_setup_date==workflow_plan_start_date){
			workflow_status = "Green";
		}
		else{
			workflow_status = "Gray";
		}
		
		var workflow_update = {ID:workflow_scheme_ID,name: workflow_name, plan_start_date: workflow_plan_start_date,plan_end_date: workflow_plan_end_date,plan_effort: workflow_plan_effort,setup_date:workflow_status,status:workflow_status};
		
		var processUpdate = [];
		var process_table = document.getElementById("process-list-table");
		for(var i=1;i< process_table.rows.length;i++){
			var process_name = process_table.rows[i].cells[0].innerHTML;
			var process_ID = process_table.rows[i].cells[1].innerHTML;
			var process_assignee = process_table.rows[i].cells[3].getElementsByTagName('select')[0].value;
			var each_plan_effort = process_table.rows[i].cells[4].getElementsByTagName('INPUT')[0].value;
			var each_plan_start_date = process_table.rows[i].cells[5].getElementsByTagName('INPUT')[0].value;
			var each_plan_end_date = process_table.rows[i].cells[6].getElementsByTagName('INPUT')[0].value;
			var group_name =  process_table.rows[i].cells[2].innerHTML;
			var process_status;
			var is_first;
			if(each_plan_start_date==workflow_plan_start_date){
				process_status = workflow_status;
				if (each_plan_effort==0){
					is_first = "Yes";
				}
				else{
					is_first = "No";
				}
			}
			else{
				process_status = "Gray";
				is_first = "No";
			}
			
			var processObject={ID:process_ID,name:process_name,assignee:process_assignee,groupName: group_name,plan_start_date: each_plan_start_date, plan_end_date:each_plan_end_date,plan_effort: each_plan_effort,status:process_status,isfirst:is_first};					
			processUpdate.push(processObject);
		}
		//alert(processUpdate.length);		
		//alert("workflow_update="+workflow_update);
		data={
			action: 'save_workflow_fine2',
			workflow: workflow_update,
			processes: processUpdate,
			processCnn: constprocessConnJsonObjArr
		};
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){	
				//alert("workflow_setup_save response="+response);
				if(response){
					window.location.href = "admin.php?page=oasiswf-monitor";
				}
			}		
		});				
	};
	
	function assigneeNullNum(){	
		var nullNum=0;
		var tableObj = document.getElementById("process-list-table"); 
		for(var i =1;i <tableObj.rows.length;i++){
			if(tableObj.rows[i].cells[3].getElementsByTagName('select')[0].value==" "){
				nullNum += 1;
				document.getElementById("assignee-select-"+i).style.borderColor = "red";
			}
		}
		return nullNum;
	}
	
	jQuery("#submit-workflow-setup").click(function(){
		if(jQuery("#workflow-select-in-setup").val()==""){
			//alert("Please select a workflow!");
			jQuery("#workflow-select-in-setup").css("border-color", "red");
		}
		else{
			var num = assigneeNullNum();
			if(num){
				
			}
			else{
				workflow_setup_save();
			}
		}
	});
	
	jQuery("#reset-workflow-setup").click(function(){
		if(jQuery("#workflow-select-in-setup").val()==""){
			//alert("Please select a workflow!");
			jQuery("#workflow-select-in-setup").css("border-color", "red");
		}
		else{
			workflow_select(jQuery("#workflow-select-in-setup").val());
		}
	});
	
	//******sort table******//
	// group list table
	jQuery("#sort-groupname").each(function(){
		var th = jQuery(this),
			thIndex = th.index(),
			inverse = false;		
		th.click(function(){
			jQuery("#group-list-table").find('td').filter(function(){
				return jQuery(this).index() === thIndex;
			}).sortElements(function(a, b){
				return jQuery.text([a]) > jQuery.text([b]) ?
					inverse ? -1 : 1
					: inverse ? 1 : -1;
			}, function(){
				return this.parentNode; 
			});
			inverse = !inverse;
		});
	});
	
	jQuery("#sort-group-assignee").each(function(){
		var th = jQuery(this),
			thIndex = th.index(),
			inverse = false;		
		th.click(function(){
			jQuery("#group-list-table").find('td').filter(function(){
				return jQuery(this).index() === thIndex;
			}).sortElements(function(a, b){
				var aindex = a.getElementsByTagName('select')[0].selectedIndex;
				var bindex = b.getElementsByTagName('select')[0].selectedIndex;
				var atext = a.getElementsByTagName('select')[0].item(aindex).text;
				var btext = b.getElementsByTagName('select')[0].item(bindex).text;
				return atext > btext ?
					inverse ? -1 : 1
					: inverse ? 1 : -1;
			}, function(){
				return this.parentNode; 
			});
			inverse = !inverse;
		});
	});
	
	//process list table
	jQuery("#sort-process-name,#sort-process-groupname,#sort-process-assignee").each(function(){
		var th = jQuery(this),
			thIndex = th.index(),
			inverse = false;		
		th.click(function(){
			jQuery("#process-list-table").find('td').filter(function(){
				return jQuery(this).index() === thIndex;
			}).sortElements(function(a, b){
				return jQuery.text([a]) > jQuery.text([b]) ?
					inverse ? -1 : 1
					: inverse ? 1 : -1;
			}, function(){
				return this.parentNode; 
			});
			inverse = !inverse;
		});
	});
	
	jQuery("#sort-plan-effort,#sort-plan-start,#sort-plan-end").each(function(){
		var th = jQuery(this),
			thIndex = th.index(),
			inverse = false;		
		th.click(function(){
			jQuery("#process-list-table").find('td').filter(function(){
				return jQuery(this).index() === thIndex;
			}).sortElements(function(a, b){
				var atext = a.getElementsByTagName('INPUT')[0].value;
				var btext = b.getElementsByTagName('INPUT')[0].value;
				return atext > btext ?
					inverse ? -1 : 1
					: inverse ? 1 : -1;
			}, function(){
				return this.parentNode; 
			});
			inverse = !inverse;
		});
	});
	
	/*jQuery("#sort-path-process-id,#sort-path-plan-effort,#sort-path-plan-start").each(function(){
		var th = jQuery(this),
			thIndex = th.index(),
			inverse = false;
		
		th.click(function(){
			jQuery("#critical-path-table").find('td').filter(function(){
				return jQuery(this).index() === thIndex;
			}).sortElements(function(a, b){
				return jQuery.text([a]) > jQuery.text([b]) ?
					inverse ? -1 : 1
					: inverse ? 1 : -1;
			}, function(){
				return this.parentNode; 
			});
			inverse = !inverse;
		});
	});*/
	//*****sort end******//
	
	//*****undo and redo function
	var historyIndex=-1;
	var workflowDateHistory =new Array();
	var groupTableHistory =new Array();
	var processTableHistory =new Array();
	var criPathHistory =new Array();
	var processConnJsonObjArrHistory = new Array();
	var processJsonObjArrHistory =new Array();
	
	function get_workflowDate_data_from_page(){	
		var workflow_select = document.getElementById("workflow-select-in-setup");
		var selIndex = workflow_select.selectedIndex;
		//var name = workflow_select.getElementsByTagName('select')[0].item(selectedIndex).text;
		
		var workflowDate_table = document.getElementById("date-list-table");	
		var startDate =workflowDate_table.rows[1].cells[0].getElementsByTagName('INPUT')[0].value ;
		var endDate =workflowDate_table.rows[1].cells[1].getElementsByTagName('INPUT')[0].value ;
		var effort = workflowDate_table.rows[1].cells[2].innerHTML;	
		var tempWorkflowObj={WorflowSelectedIndex:selIndex,Effort:effort,StartDate:startDate,EndDate:endDate};

		workflowDateHistory.push(tempWorkflowObj);

		processConnJsonObjArrHistory.push(processConnJsonObjArr);
		processJsonObjArrHistory.push(processJsonObjArr);
	}
	
	function get_process_table_data_from_page(){
		var process_table = document.getElementById("process-list-table");
		var tempProObjArr=[];
		for(var i=1;i < process_table.rows.length;i ++){
			var name = process_table.rows[i].cells[0].innerHTML;
			var id = Number(process_table.rows[i].cells[1].innerHTML);
			var groupName = process_table.rows[i].cells[2].innerHTML;
				var selectedIndex = process_table.rows[i].cells[3].getElementsByTagName('select')[0].selectedIndex;
			var assigneeID = process_table.rows[i].cells[3].getElementsByTagName('select')[0].value;	
			var assignee = process_table.rows[i].cells[3].getElementsByTagName('select')[0].item(selectedIndex).text;		
			var effort = Number(process_table.rows[i].cells[4].getElementsByTagName('INPUT')[0].value);	
			var startDate =process_table.rows[i].cells[5].getElementsByTagName('INPUT')[0].value ;
			var endDate =process_table.rows[i].cells[6].getElementsByTagName('INPUT')[0].value;
			var criEffort =Number(process_table.rows[i].cells[7].innerHTML);
			var tempProObj={Name:name,ID:id,GroupName:groupName,AssigneeID:assigneeID,Assignee:assignee,AssigneeSelectedIndex:selectedIndex,PlanEffort:effort,PlanStartDate:startDate,PlanEndDate:endDate,CriEffort:criEffort};
			tempProObjArr.push(tempProObj);
		}
		processTableHistory.push(tempProObjArr);
	}
	
	function get_group_table_data_from_page(){
		var group_table = document.getElementById("group-list-table");
		var tempGroupObjArr=[];
		for(var i=1;i < group_table.rows.length;i ++){			
			var groupName = group_table.rows[i].cells[0].innerHTML;
			var selectedIndex = group_table.rows[i].cells[1].getElementsByTagName('select')[0].selectedIndex;
			var assigneeID = group_table.rows[i].cells[1].getElementsByTagName('select')[0].value;
			//var assignee = group_table.rows[i].cells[1].getElementsByTagName('select')[0].item(selectedIndex).text;		
			var tempGroupObj={GroupName:groupName,AssigneeID:assigneeID,AssigneeSelectedIndex:selectedIndex};
			tempGroupObjArr.push(tempGroupObj);
		}
		groupTableHistory.push(tempGroupObjArr);
	}
	
	function get_CriPath_table_data_from_page(){
		var criPath_table = document.getElementById("critical-path-table");
		var tempProObjArr=[];
		for(var i=1;i < criPath_table.rows.length;i ++){
			var pathIndex = criPath_table.rows[i].cells[0].innerHTML;
			var name = criPath_table.rows[i].cells[1].innerHTML;
			var id = Number(criPath_table.rows[i].cells[2].innerHTML);		
			var effort = criPath_table.rows[i].cells[3].innerHTML;	
			var startDate =criPath_table.rows[i].cells[4].innerHTML ;
			var tempProObj={PathIndex:pathIndex,ID:id,Name:name,Effort:effort,StartDate:startDate};
			tempProObjArr.push(tempProObj);
		}
		criPathHistory.push(tempProObjArr);
	}
	
	function save_all_table_data_from_page_to_history(){
		get_workflowDate_data_from_page();
		get_group_table_data_from_page();
		get_process_table_data_from_page();
		get_CriPath_table_data_from_page();
		historyIndex+=1;	
	}
	
	function show_process_table(result,adj_list,cri_path_obj){
		//alert("result="+result);
		var processCount = result.length;				
		for(var i = 0; i< processCount; i++){
			var groupName = result[i]["GroupName"];
			//alert("groupName="+groupName);
			var userList = users_get(groupName);
			var usersAppendOption="<option value =' '></option>";						
			for(var j=0;j < userList.length;j++){
				if(result[i]["AssigneeID"]!=userList[j]["ID"]){
					usersAppendOption += "<option value='" + userList[j]["ID"] + "'>"+ userList[j]["Name"]+"</option>";
				}
				else{
					usersAppendOption += "<option selected='selected' value='" + userList[j]["ID"] + "'>"+ userList[j]["Name"]+"</option>";
				}
			}							
			//alert("usersAppendOption="+usersAppendOption);
			var index = parseInt(i)+1;
			var userStr="";
			var startdateStr="";
			var planeffortStr="";
			var enddateStr="";
			if(result[i]["ID"]==cri_path_obj.srcID||result[i]["ID"]==cri_path_obj.decID){
				userStr = "<select id ='assignee-select-"+ index +"' class='"+ groupName +"assignee-select assignee-select' name='assignee-select' style='width:150px' real='step-loading-span'>"+ usersAppendOption +"</select>";
				startdateStr = "<input id='processstart-"+ index +"' name='process-plan-start-date' class='process-plan-start-date date_input' type='text' real='publish-date-loading-span' disabled value='"+ result[i]["PlanStartDate"] + "'/>";
				planeffortStr = "<input id='processeffort-"+ index +"' name='process-plan-effort' class='process-plan-effort date_input' type='text' real='publish-date-loading-span' disabled value='"+ result[i]["PlanEffort"] + "'/>"				
			}
			else{
				userStr = "<select id ='assignee-select-"+ index +"' class='"+ groupName +"assignee-select assignee-select' name='assignee-select' style='width:150px' real='step-loading-span'>"+ usersAppendOption +"</select>";
				startdateStr = "<input id='processstart-"+ index +"' name='process-plan-start-date' class='process-plan-start-date date_input' type='text' real='publish-date-loading-span' readonly value='"+ result[i]["PlanStartDate"] + "'/>";
				planeffortStr = "<input id='processeffort-"+ index +"' name='process-plan-effort' class='process-plan-effort date_input' type='text' real='publish-date-loading-span' value='"+ result[i]["PlanEffort"] + "'/>"
			}
			jQuery("#process-list-table").append("<tr>" 
												   +"<td>" + result[i]["Name"] + "</td>"
												   +"<td style='display:none'>" + result[i]["ID"] + "</td>"
												   +"<td>" + groupName + "</td>"
												   +"<td>"+ userStr + "</td>"
												   +"<td>"+ planeffortStr + "</td>"
												   +"<td>" + startdateStr + "</td>"
												   +"<td>" + 
													  "<input id='processend-"+ index +"' name='process-plan-end-date' class='process-plan-end-date date_input' type='text' real='publish-date-loading-span' disabled value='"+ 
													   result[i]["PlanEndDate"]  + "'/></td>"
												   + "<td style='display:none'>"+result[i]["CriEffort"]+"</td>"
											+"</tr>");							
		}
	}
	
	function reshow_group_table(groups){
		for(var i=0; i< groups.length; i++){
			var groupName = groups[i]["GroupName"];
			var userList = users_get(groupName);						
			var usersAppendOption="<option value =' '></option>";;
			for(var j=0;j < userList.length;j++){
				if(groups[i]["AssigneeID"]!=userList[j]["ID"]){
					usersAppendOption += "<option value='" + userList[j]["ID"] + "'>"+ userList[j]["Name"]+"</option>";
				}
				else{
					usersAppendOption += "<option selected='selected' value='" + userList[j]["ID"] + "'>"+ userList[j]["Name"]+"</option>";
				}
			}
			jQuery("#group-list-table").append("<tr>"
													   +"<td>" + groupName + "</td>"
													   +"<td class='assignee_All'>"+
															"<select class='group-assignee-select' id='" + groupName +"' name='assignee-select' style='width:150px' real='step-loading-span'>"+
															usersAppendOption +"</select>"+
														 "</td>"
													   +"</tr>");
		}	
	}
	
	function reshow_critical_path(cripathTable){
		//delete tr first
		deleteTableData("critical-path-table");
		var critical_path_info="";
		for(var j in cripathTable){
			if(j!=0){
				tempPathStr = "<td style='visibility:hidden'>"+ cripathTable[j].PathIndex +"</td>";
			}
			else{
				tempPathStr = "<td>"+ cripathTable[j].PathIndex +"</td>";
			}
			critical_path_info+="<tr>"
								+ tempPathStr			
							   +"<td>" + cripathTable[j].Name + "</td>"
							   +"<td style='display:none'>" + cripathTable[j].ID + "</td>"
							   +"<td>"+cripathTable[j].Effort+"</td>"	
							   +"<td>"+cripathTable[j].StartDate+"</td>"															     																	   
							 +"</tr>"	
									
		}
		jQuery("#critical-path-table").append(critical_path_info);		
	}
	
	function reShow_tables(historyIndex){
		processConnJsonObjArr = processConnJsonObjArrHistory[historyIndex];
		processJsonObjArr = processJsonObjArrHistory[historyIndex];
		
		var workflow_select = document.getElementById("workflow-select-in-setup");
	    workflow_select.selectedIndex = workflowDateHistory[historyIndex].WorflowSelectedIndex;
		//reshow workflow date
		var workflowDate_table = document.getElementById("date-list-table");		
		workflowDate_table.rows[1].cells[0].getElementsByTagName('INPUT')[0].value = workflowDateHistory[historyIndex].StartDate;
		workflowDate_table.rows[1].cells[1].getElementsByTagName('INPUT')[0].value = workflowDateHistory[historyIndex].EndDate;
		workflowDate_table.rows[1].cells[2].innerHTML = workflowDateHistory[historyIndex].Effort;

		//reshow group table
		var group_table = document.getElementById("group-list-table");
		var groupRowNum = group_table.rows.length;
		if(groupRowNum==1){
			//use groupTableHistory[historyIndex] to append the group table
			reshow_group_table(groupTableHistory[historyIndex]);
		}
		else{
			if(groupTableHistory[historyIndex].length!=0){
				for(var i=1; i< group_table.rows.length;i++){
					for(var j=0; j< groupTableHistory[historyIndex].length; j++){
						if(group_table.rows[i].cells[0].innerHTML == groupTableHistory[historyIndex][j].GroupName){
							group_table.rows[i].cells[0].innerHTML = groupTableHistory[historyIndex][j].GroupName;
							group_table.rows[i].cells[1].getElementsByTagName('select')[0].selectedIndex = groupTableHistory[historyIndex][j].AssigneeSelectedIndex;
						}
					}
				}
			}
			else{
				deleteTableData("group-list-table");
			}
		}
		
		//reshow process table
		var process_table = document.getElementById("process-list-table");
		var processRowNum = process_table.rows.length;
		if(processRowNum==1){
			//use processTableHistory[historyIndex] to append the process table
			var adj_list = get_graph_adj_list(processConnJsonObjArrHistory[historyIndex],processJsonObjArrHistory[historyIndex]);
			cri_path_obj= get_critical_path(adj_list);
			show_process_table(processTableHistory[historyIndex],adj_list,cri_path_obj);
		}
		else{
			if(processTableHistory[historyIndex].length!=0){
				for(var i=1; i< process_table.rows.length;i++){
					for(var j=0; j< processTableHistory[historyIndex].length; j++){
						if(process_table.rows[i].cells[1].innerHTML == processTableHistory[historyIndex][j].ID){
							//process_table.rows[i].cells[0].innerHTML = processTableHistory[historyIndex][j].Name;
							//process_table.rows[i].cells[1].innerHTML = processTableHistory[historyIndex][j].ID;
							//process_table.rows[i].cells[2].innerHTML = processTableHistory[historyIndex][j].GroupName;
							process_table.rows[i].cells[3].getElementsByTagName('select')[0].selectedIndex = processTableHistory[historyIndex][j].AssigneeSelectedIndex;
							process_table.rows[i].cells[4].getElementsByTagName('INPUT')[0].value = processTableHistory[historyIndex][j].PlanEffort;	
							process_table.rows[i].cells[5].getElementsByTagName('INPUT')[0].value = processTableHistory[historyIndex][j].PlanStartDate;
							process_table.rows[i].cells[6].getElementsByTagName('INPUT')[0].value = processTableHistory[historyIndex][j].PlanEndDate;
							//process_table.rows[i].cells[7].innerHTML = processTableHistory[historyIndex][j].CriEffort;
						}
					}
				}
			}
			else{
				deleteTableData("process-list-table");
			}
		}
		
		//reshow cripath table
		reshow_critical_path(criPathHistory[historyIndex]);
	
	}
	
	jQuery("#undo-workflow-setup").click(function(){

		if(historyIndex>0){
			historyIndex -=1;
			reShow_tables(historyIndex);
		}
		else{
			if(historyIndex==0){
				reShow_tables(historyIndex);
			}
		}
	});		
	
	jQuery("#redo-workflow-setup").click(function(){
		if(historyIndex<workflowDateHistory.length-1){
			historyIndex+=1;
			reShow_tables(historyIndex);
		}
		//alert("redo");
	});	
	
});