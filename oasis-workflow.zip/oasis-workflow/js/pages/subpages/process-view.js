jQuery(document).ready(function() {	
	jQuery( document ).on( "click", "#btnSubmit", function(){
		data = {
				action: 'update_process',
				processid: jQuery.trim( jQuery(document).find("#process_id").val().escapeSpecialChars()), 
				workflowid: jQuery.trim( jQuery(document).find("#workflow_id").val().escapeSpecialChars()),
				status: jQuery("#step-status-set-list").val()
			   };
		jQuery.post(ajaxurl, data, function( response ) {
			if(response)
			{
				jQuery.modal.close();
				parent.location.reload();
			}
			else
			{
				alert("Fail to submit, please try again!");
			}
		});
	});
	jQuery( document ).on( "click", "#appealSubmit", function(){
		data = {
				action: 'appealSubmission',
				processid: jQuery.trim( jQuery(document).find("#process_id").val().escapeSpecialChars()), 
				workflowid: jQuery.trim( jQuery(document).find("#workflow_id").val().escapeSpecialChars()),
				//status: jQuery("#step-status-set-list").val(),
				comment: jQuery("#appealComments").val()
			   };
		jQuery.post(ajaxurl, data, function( response ) {
			if(response)
			{
				jQuery.modal.close();
				parent.location.reload();
			}
			else
			{
				alert("Fail to appeal, please try again!");
			}
		});
	});
});