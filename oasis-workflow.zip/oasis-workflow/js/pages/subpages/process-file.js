jQuery(document).ready(function() {	
	jQuery( document ).on( "click", ".quick_download", function(){
		data = {
				action: 'download_dnt_file',
				fileid: jQuery(this).attr("fileid"),
				parent_page: "process-file"
			  };

		jQuery.get(ajaxurl, data, function( response ) {
			if(response="success")
			{
				parent.location.href="../wp-content/plugins/oasis-workflow/includes/download.php";
			}
		});
		
	});
	
	jQuery( document ).on( "click", "#btnAdd", function(){
		data = {
				action: 'add_variable',
				processid: jQuery(this).attr('processid'),
				variable_name: jQuery('#vname').val(),
				variable_value: jQuery('#vvalue').val(),
				parent_page: 'process-file'
			  };
		jQuery.get(ajaxurl, data, function( response ) {
			if(response)
			{
				jQuery("#tr_output_variable").css("display","none");
				var jsonRes=eval("("+response+")");
				tr='<tr>';
				tr+='<td>'+jsonRes.Name+'</td>';
				tr+='<td>'+jsonRes.Content+'</td>';
				tr+='<td>'+jsonRes.Updatetime+'</td>';
				tr+='</tr>';
				jQuery('#ovtable').find('tbody').append(tr);
			}
		});
	});
});