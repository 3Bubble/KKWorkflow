jQuery(document).ready(function() {	
	jQuery( document ).on( "click", "#importBtn", function(){
		var filepath=document.getElementById("txtPath").value;
		if(filepath=="")
		{
			alert("No file selected!");
			return;
		}
		var re = /(\\+)/g; 
		var filename=filepath.replace(re,"#");
		var one=filename.split("#");
		var two=one[one.length-1];
		var three=two.split(".");
		var last=three[three.length-1];
		var tp ="xls,xlsx";
		var rs=tp.indexOf(last);
		if(rs<0)
		{
			alert("Invalid file!");
			return;
		}
	});	
});