jQuery(document).ready(function(){
	
	function max_date(date1,date2){
		var odate1 =new Date(date1);
		var odate2= new Date(date2);
		var maxdate;
		if(odate1.getTime()>odate2.getTime()){
			maxdate = date1;
		}
		else{
			maxdate = date2;
		}
		return maxdate;
	}
	
	function deleteTableData(tableID){
		var tableObj = document.getElementById(tableID);
		var rownum = tableObj.rows.length;
		for(var i=rownum-1;i >0;i--){
			tableObj.deleteRow(i);
		}
	}
	
	function getWorkDays(start_date,end_date){
		var tempDate;
		tempDate = start_date.split(" ");
	   var startDate = new Date(Date.parse(tempDate[0].replace(/-/g,  "/")));       
	   tempDate = end_date.split(" ");
	   var endDate = new Date(Date.parse(tempDate[0].replace(/-/g,  "/"))); 
	   var diffDays = (endDate - startDate)/(1000*60*60*24)+1;
	   var remainDay = diffDays % 7;
	   var weeks = Math.floor(diffDays / 7);
	   var weekends = 2 * weeks;
	   var weekDay = startDate.getDay();
	   for(var i = 0;i < remainDay;i++){
			if(((weekDay + i)==6)||((weekDay + i)==0)||((weekDay + i)==7)){
				weekends = weekends + 1;
			}
	    }
		var workdays = diffDays-weekends;
		return workdays;
	}
	
	function  DateDiff(sDate1,  sDate2){    
       var  aDate,  oDate1,  oDate2,  iDays ; 
       aDate  =  sDate1.split("-") ; 
       oDate1  =  new  Date(aDate[1]  +  '-'  +  aDate[2]  +  '-'  +  aDate[0]) ;   
       aDate  =  sDate2.split("-") ; 
       oDate2  =  new  Date(aDate[1]  +  '-'  +  aDate[2]  +  '-'  +  aDate[0]);  
       //iDays  =  parseInt(Math.abs(oDate1  -  oDate2)  /  1000  /  60  /  60  /24) ; 
	   iDays  =  parseInt((oDate1  -  oDate2)  /  1000  /  60  /  60  /24) +1; 
	   //alert("iDays="+iDays)
	   return  iDays;
	}   	
     
	
	function plan_end_date_calculation(dateTemp, days) {
		if(days==0){
			days+=1;
		}
	   var startdateYMD = dateTemp.split(" ")[0];
	   //var startdateHMS = dateTemp.split(" ")[1]
	   var startdateYMD = startdateYMD.split("-");  
	   var nDate = new Date(startdateYMD[0]+'-'+startdateYMD[1] + '-' + startdateYMD[2] );
	   var millSeconds = Math.abs(nDate) + ((days-1) * 24 * 60 * 60 * 1000);
	   var rDate = new Date(millSeconds);  
	   var year = rDate.getFullYear();  
	   var month = rDate.getMonth() + 1;  
	   if (month < 10){
			month = "0" + month; 
	   }		
	   var date = rDate.getDate();  
	   if (date < 10){ 
			date = "0" + date;  
	    }
	   //jQuery("#workflow-plan-end-date").val(year + "-" + month + "-" + date );
	   return (year + "-" + month + "-" + date);
	}

	function plan_end_date_calculation_substract_weekend(start_date, days) {
		if(days==0){
			var actualDays =0;	
			return plan_end_date_calculation(start_date,actualDays);
		}
		else{
			var start_date_temp = start_date;
			start_date = start_date.split(" ")[0];
			start_date = start_date.split("-"); 
			start_date = new Date(start_date[0]+'-'+start_date[1]+'-'+start_date[2] );
			
			var weekday =start_date.getDay();		
			var weeks ,remainDay;
			var actualDays =0;	
			var tempday =  Number(weekday) +Number(days);				
			if(weekday!=6 && weekday!=0){
				if(tempday>6){
					var remainday_in_first_week = 5 - weekday +1;
					judgeday = days - remainday_in_first_week;
					if(judgeday<5){
						actualDays=Number(days)+Number(2);
					}
					else{
						actualDays +=2;
						weeks = parseInt(judgeday/5);
						remainDay = (judgeday)%5;
						actualDays += (weeks*7 + remainDay);
						actualDays += remainday_in_first_week;
						if(remainDay==0){
							actualDays -=2;
						}					
					}							
				}
				else{
					actualDays = days;
				}
			}
			else{
				if(weekday == 6){
					actualDays += 2;
					weeks = parseInt(days/5);
					remainDay = (days)%5;
					if(remainDay==0){
						actualDays -= 2;
					}
					actualDays += (weeks*7 + remainDay);
				}
				if(weekday == 0){
					actualDays += 1;
					weeks = parseInt(days/5);
					remainDay = (days)%5;
					actualDays += (weeks*7 + remainDay);
					if(remainDay==0){
						actualDays -= 2;
					}					
				}	
			}
			return plan_end_date_calculation(start_date_temp,actualDays);
		}				
	}   
	
	function remove_all_option(select_id)
	{
		var select_obj = document.getElementById(select_id);
		select_obj.options.length = 0;
	}
	
	function add_option(select_id,text,value)
	{
		var select_obj = document.getElementById(select_id);
		select_obj.options.add(new Option(text,value));
	}
	
	function update_workflow_dropdownlist_by_status(workflow_status)
	{
		data={
				action : 'get_workflow_dropdownlist_by_status',
				workflowstatus : workflow_status
			};
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){
				if(response){	
					remove_all_option("workflow-select-by-status");//remove the workflow-status-select
					result = JSON.parse(response) ;
					add_option("workflow-select-by-status","All Workflow","All");
					for(var i=0;i< result.length;i++){
						add_option("workflow-select-by-status",result[i]["Name"],result[i]["ID"]);
					}				
				}
			}
		});
	}
	
	function update_user_dropdownlist_by_workflow(worflow_status,workflow_id)
	{
		data={
				action : 'get_user_dropdownlist_by_workflow',
				worflowstatus:worflow_status,
				workflowid : workflow_id
			};
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){
				if(response){	
					remove_all_option("user-select-in-workflow");//remove the workflow-status-select
					result = JSON.parse(response) ;
					add_option("user-select-in-workflow","All User","All");
					for(var i=0;i< result.length;i++){
						add_option("user-select-in-workflow",result[i]["user_login"],result[i]["ID"]);
					}				
				}
			}
		});
	}
	
	jQuery("#workflow-select-by-status").change(function(){
		document.getElementById('workflow-status-select').value = jQuery(this).val();
		update_monitor_data_by_filters('All',jQuery("#workflow-select-by-status").val(),jQuery("#user-select-in-workflow").val());
	});
	
	jQuery("#workflow-status-select").change(function(){
		update_workflow_dropdownlist_by_status(jQuery(this).val());
		update_user_dropdownlist_by_workflow(jQuery(this).val(),"All");
	});
	jQuery("#user-select-in-workflow").change(function(){
		document.getElementById('user-select-in-workflow').value = jQuery(this).val();
		update_monitor_data_by_filters('All',jQuery("#workflow-select-by-status").val(),jQuery("#user-select-in-workflow").val());
	});
	
	
	function createTableData(tableID){
		var tableObj = document.getElementById(tableID);
		var rownum = tableObj.rows.length;
		for(var i=rownum-1;i >0;i--){
			
		}
	}
	
	
	function update_monitor_data_by_filters(worflow_status,workflow_id,user_id)
	{
		data={
				action : 'get_monitor_datas_by_filters_workflow',
				worflowstatus: worflow_status,
				workflowid : workflow_id,
				userid: user_id
			};
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){
				if(response){	
					deleteTableData("notstart-process-list-table-in-monitor");
					deleteTableData("inprogress-process-list-table-in-monitor");
					deleteTableData("delay-process-list-table-in-monitor");
					deleteTableData("complete-process-list-table-in-monitor");
					//alert("response="+response);
					result = JSON.parse(response) ;
					var now = new Date();
					now = now.getFullYear()+"-"+((now.getMonth()+1)<10?"0":"")+(now.getMonth()+1)+"-"+(now.getDate()<10?"0":"")+now.getDate();	
					for(var i=0;i< result.length;i++){					
						switch(result[i]["Status"])
						{
							case "Gray":
								var worked_effort=0;
								jQuery("#notstart-process-list-table-in-monitor").append("<tr>" 
																   //+"<td></td>"
																    +"<td>" + result[i]["wfName"] +"_"+result[i]["WorkflowID"]+"</td>"
																   +"<td>" + result[i]["Name"] + "</td>"
																   +"<td>" + result[i]["user_login"] + "</td>"
																   +"<td>"+ worked_effort + "</td>"
																   +"<td>"+ result[i]["PlanEffort"] + "</td>"
																   +"<td>"+ result[i]["CommitDate"] + "</td>"
															+"</tr>");	
								break;
							case "Green":
								var worked_effort=getWorkDays(result[i]["ActualStartDate"],now);
								jQuery("#inprogress-process-list-table-in-monitor").append("<tr>" 
																   //+"<td></td>"
																    +"<td>" + result[i]["wfName"] + "_"+result[i]["WorkflowID"]+"</td>"
																   +"<td>" + result[i]["Name"] + "</td>"
																   +"<td>" + result[i]["user_login"] + "</td>"
																   +"<td>"+ worked_effort + "</td>"
																   +"<td>"+ result[i]["PlanEffort"] + "</td>"
																   +"<td>"+ result[i]["CommitDate"] + "</td>"
															+"</tr>");	
								break;
							case "Red":
								var worked_effort=getWorkDays(result[i]["ActualStartDate"],now);
								jQuery("#delay-process-list-table-in-monitor").append("<tr>" 
																   //+"<td></td>"
																    +"<td>" + result[i]["wfName"] + "_"+result[i]["WorkflowID"]+"</td>"
																   +"<td>" + result[i]["Name"] + "</td>"
																   +"<td>" + result[i]["user_login"] + "</td>"
																   +"<td>"+ worked_effort + "</td>"
																   +"<td>"+ result[i]["PlanEffort"] + "</td>"
																   +"<td>"+ result[i]["CommitDate"] + "</td>"
															+"</tr>");	
								break;
							case "Black":
								var worked_effort=getWorkDays(result[i]["ActualStartDate"],result[i]["CommitDate"]);
								jQuery("#complete-process-list-table-in-monitor").append("<tr>" 
																   //+"<td></td>"
																    +"<td>" + result[i]["wfName"] + "_"+result[i]["WorkflowID"]+"</td>"
																   +"<td>" + result[i]["Name"] + "</td>"
																   +"<td>" + result[i]["user_login"] + "</td>"
																   +"<td>"+ worked_effort + "</td>"
																   +"<td>"+ result[i]["PlanEffort"] + "</td>"
																   +"<td>"+ result[i]["CommitDate"] + "</td>"
															+"</tr>");	
								break;
						}
					}
				}
			}
		});
	}
	
	jQuery("#filter-button-in-monitor").click(function(){
		//alert("workflow-status-select="+jQuery("#workflow-status-select").val());
		update_monitor_data_by_filters(jQuery("#workflow-status-select").val(),jQuery("#workflow-select-by-status").val(),jQuery("#user-select-in-workflow").val());	
	});
	
	jQuery("table.wp-list-table").DataTable({"searching":false, "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]} );
	
});