
jQuery(document).ready(function() {	
	var inbox_obj = "" ;
	
	jQuery( document ).on( "click", ".quick_input", function(){
		inbox_obj = this ;
		data = {
				action: 'get_process_input_content',
				processid: jQuery(this).attr("processid"),
				parent_page: "process"
			   };
		jQuery(this).parent().parent().children(".loading").show();
		jQuery.get(ajaxurl, data, function( response ) {
			var content = jQuery.parseJSON( response.trim() );
			jQuery("#step_submit_content").html( content );
			setTimeout("call_modal()", 100);			
		});
		call_modal = function(){
			jQuery(inbox_obj).parent().parent().children(".loading").hide();
			jQuery("#input-output-div").owfmodal({
			    onShow: function (dlg) {
			        jQuery.modal.update();
			    }					
			});
		}
	});
	
	jQuery( document ).on( "click", ".quick_output", function(){
		inbox_obj = this ;
		data = {
				action: 'get_process_output_content',
				processid: jQuery(this).attr("processid"),
				parent_page: "process"
			   };
		jQuery(this).parent().parent().children(".loading").show();
		jQuery.get(ajaxurl, data, function( response ) {
			var content = jQuery.parseJSON( response.trim() );
			jQuery("#step_submit_content").html( content );
			setTimeout("call_modal()", 100);			
		});
		call_modal = function(){
			jQuery(inbox_obj).parent().parent().children(".loading").hide();
			jQuery("#input-output-div").owfmodal({
			    onShow: function (dlg) {
			        jQuery.modal.update();
			    }					
			});
		}
	});
	
	jQuery( document ).on( "change", ".file_input", function(){
		this.form.submit();
		/*data = {
				action: 'upload_dnt_file',
				processid: jQuery(this).attr("processid"),
				parent_page: "process"
			   };
		//jQuery(this).parent().children(".loading").show();
		jQuery.get(ajaxurl, data, function( response ) {
			alert(response);		
		});*/
	});
	
	jQuery( document ).on( "click", ".quick_view", function(){
		inbox_obj = this ;
		data = {
				action: 'get_process_view_content',
				processid: jQuery(this).attr("processid"),
				parent_page: "process"
			   };
		jQuery(this).parent().parent().children(".loading").show();
		jQuery.get(ajaxurl, data, function( response ) {
			var content = jQuery.parseJSON( response.trim() );
			jQuery("#step_submit_content").html( content );
			setTimeout("call_modal()", 100);			
		});
		call_modal = function(){
			jQuery(inbox_obj).parent().parent().children(".loading").hide();
			jQuery("#input-output-div").owfmodal({
			    onShow: function (dlg) {
			    	jQuery("#simplemodal-container").css("max-height","80%");
			        jQuery(dlg.wrap).css('overflow', 'auto'); // or try ;
			        jQuery.modal.update();
			    }					
			});
		}
	});
	jQuery( document ).on( "click", ".quick_reject", function(){
		inbox_obj = this ;
		data = {
				action: 'get_process_reject_content',
				processid: jQuery(this).attr("processid"),
				parent_page: "process"
			   };
		jQuery(this).parent().parent().children(".loading").show();
		jQuery.get(ajaxurl, data, function( response ) {
			var content = jQuery.parseJSON( response.trim() );
			jQuery("#step_submit_content").html( content );
			setTimeout("call_modal()", 100);			
		});
		call_modal = function(){
			jQuery(inbox_obj).parent().parent().children(".loading").hide();
			jQuery("#input-output-div").owfmodal({
			    onShow: function (dlg) {
			    	jQuery("#simplemodal-container").css("max-height","80%");
			        jQuery(dlg.wrap).css('overflow', 'auto'); // or try ;
			        jQuery.modal.update();
			    }					
			});
		}
	});

});
